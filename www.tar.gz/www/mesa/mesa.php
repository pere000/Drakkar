<!DOCTYPE html>
<html>
<head>
<title>Records</title>
	<!--
	<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
	-->
<link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
<style>
body {
width:95%;background-color:#83580B;color: white;font-size: 12px;
font-family: "Verdana", sans-serif;
}
html *
{
   font-family: normal 12px sans-serif, Verdana, Arial; !important;

}
/*All tables, buttons, .boxes*/
table {width:99%;margin-left:auto;margin-right:auto;}
button{width:150px;font-size:12px;font-weight:bold;}
.box {display:flex;font-size:12px;}
textarea{font-size: 12px;}



.dvTarea, .buttonRecipeEnd, .buttonsEnd, .messageEnd {float:left;}
.messageEnd, #editableRecipe {width:100%;}
/*.messageEnd, .dvTarea {margin-left:20px;}*/
.dvTarea {width:100%;}

.buttonRecipeEnd[name='calcRcp'] {margin-bottom:20px;}
#editableRecipe{height:160px;padding:10px}

.form td {background-color:white;text-align:right;padding-right:5px;color:black;}
.whiteFont td {background-color:#83580B;color:white;font-weight:bold;}
.alignLeft td {background-color:#83580B;text-align:left;color:#FFEFA0;font-weight:bold;}
#f4 {background-color:#83580B;color:#FFEFA0;font-weight:bold;text-align:left;padding-left:5px;}
#search1234 {background-color:#83580B;width:150px;padding-right:10px;}

.menu{display:none;color:white;font-weight:bold;}
.step2{display:none;}
.stepX{display:none;color:white;font-weight:bold;}
.cursor {cursor:pointer}
.txtAlignLeft {text-align:left;color:#FFEFA0;}
.txtAlignCenter {text-align:center;color:#FFEFA0;font-weight:bold;padding-left:20px;}
.td11 {padding-top:2px;}
#step2 {color:#FFEFA0;}
#step3 {margin-top:12px;color:#FFEFA0;}
#step4 {margin-top:2px;color:#FFEFA0;}
#resultsMenu {color:white;}

.blink {
  animation: blink 2s infinite;color:#86E5FF;cursor:pointer;
}

@keyframes blink {
  0% {
    opacity: 1;
  }
  39% {
    opacity: 0;
    transform: scale(2);
  }
  40% {
    opacity: 0;
    transform: scale(0);
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}
</style>

<script>

function phrases(){
	var divContent = document.getElementById('phrases').innerHTML;
	var lines = divContent.split('|');
	var randomIndex = Math.floor(Math.random() * lines.length);
	var randomLine = lines[randomIndex];
	document.getElementById('phrases1').innerHTML = "<span style='color:white'>Free for Freedom Pot</span>: "+randomLine;
	}

function messageRefresh(){
	//document.getElementById('f2').innerHTML='([0-9]{1,2}:[a-z -]+)';
	//document.getElementById('f3').innerHTML='([a-z]+(-[a-z]+)?)';
	//document.getElementById('f25').innerHTML='[a-z]+';
	phrases()
	}

function exportRec(){
	const textarea = document.getElementById("editableRecipe");
	const linesArray = textarea.value.split("\n");

	var sendToPHPexport=''
	for (let i = 0; i < linesArray.length-1; i++)  {
	//alert(linesArray[i])
	timestamp=linesArray[i];
	timestamps=timestamp.split("|")
	//alert(timestamps[0])
		sendToPHPexport=timestamps[0]+","+sendToPHPexport
	//alert(sendToPHPexport)
	}
	ajaxToExport(sendToPHPexport)
	}

function ajaxToExport(sTe){
	let sendToExportScr=sTe.slice(0,-1)
	//alert(sendToExportScr)
	//exit
		//Create an XMLHttpRequest object
		var hr = new XMLHttpRequest();
		//Variable containing the url to get to the server side php script
		var url = "scripts/PHPtoExportScr.php";
		// variables containing the data on the client-side to send to some PHP script on the server-side
		//var fn = sendToExportScr;
			var forScrS1 = "forScrS1='"+sendToExportScr+"'";
	//alert('ok entra en ajax_post(group) '+group)
		hr.open("POST", url, true);
		//Set content type header information for sending url encoded variables in the request
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				//var return_data = hr.responseText;
				//document.getElementById("resultsMenu").innerHTML = return_data;
			}
		}
		//Execute the request adding the name_variable value pairs before 'status 200' is reached
		hr.send(forScrS1);
		//HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
		//document.getElementById("resultsMenu").innerHTML = "processing...";
	}


var base_url=window.location.origin;
var rest_url=window.location.pathname;
var varValGlobal='';
let arrayOfLines = new Array();
var arrayElemMatch=''
var areaLines=new Array();

function array(){
	//alert(arrayElemMatch+', '+document.getElementById('f23').innerHTML);
	if (document.getElementById('f24').innerHTML.length=='0'){alert('The \'Kc Total\' field cannot be blank. You can press the \'Calculate Meal\' button, if it is set to the far right of the row. Exit now.');exit;}
	if (document.getElementById('f23').innerHTML=='<br>'){alert('Quantity must have a numeric value. Exit now.');document.getElementById('f23').innerHTML='';exit;}
	if (document.getElementById('f23').innerHTML=='0'){alert('Quantity can not be zero. Exit now.');document.getElementById('f23').innerHTML='';exit;}
	if (document.getElementById('f23').innerHTML.length=='0'){alert('Quantity can not be blank. Exit now.');document.getElementById('f23').innerHTML='';exit;}
	if (document.getElementById('f23').innerHTML.match(/^[0-9]+$/)) {document.getElementById('calculatefood').style.visibility='hidden';}else{alert('Field Quantity is not valid. Exit now.');document.getElementById('f23').innerHTML='';exit}

	const string = document.getElementById('editableRecipe').value;
	const substring = document.getElementById('f1').innerHTML+'|'+document.getElementById('f2').innerHTML;

	//alert('editableRecipe value: '+document.getElementById('editableRecipe').value)
	//alert('string foo: '+string)
	//alert('substring oo: '+substring)
	//alert('true or false: '+string.includes(substring))
	if (string.includes(substring) == true){document.getElementById('calculatefood').style.visibility='hidden';document.getElementById('f23').innerHTML='';}else{txtarea=document.getElementById('editableRecipe').value.replace(/(^[ \t]*\n)/gm, "")+arrayElemMatch+'|'+document.getElementById('f23').innerHTML+'|'+document.getElementById('f24').innerHTML
	document.getElementById('editableRecipe').value =txtarea+'\n';document.getElementById('f23').innerHTML='';}
	}

function ShowHideMenu(varValue){

	alert('varValue: '+varValue)
	varValGlobal=varValue;
	document.getElementById('f1').innerHTML=''

	for(i=5;i<25;i++){document.getElementById('f'+i).innerHTML=''}
	document.getElementById('f5').innerHTML='</br>'
	document.getElementById('f12').innerHTML='</br>'
	document.getElementById('f2').innerHTML=varValue+':'

		for (let c=1; c< 20; c++){document.getElementById(c).style.display='none';}

		if (document.getElementById(varValue).style.display === 'none') {
				document.getElementById(varValue).style.display='block'
			}
		else
			{
				document.getElementById(varValue).style.display='none'
			}
	}

function showHide(varVal){
	if (document.getElementById(varVal).style.display === 'none') {
		    document.getElementById(varVal).style.display='block'
		}
	else
		{
			document.getElementById(varVal).style.display='none'
		}
	}

function copyLine(idLine){
	//alert('This line '+idLine+' will be copied to the form with the fragment '+idLine+'Plus');
	//alert(document.getElementById(idLine).innerHTML);
	//alert(document.getElementById(idLine+'Plus').innerHTML);
	}

function jsFunction(message){

	document.getElementById('message').innerHTML='';
	document.getElementById('message').innerHTML=message.trim();
	}

function loadDocument() {
	jsFunction('<br>Database updating...')
        var xmlHttpRequest = new XMLHttpRequest();
        xmlHttpRequest.onreadystatechange = function() {
            if (xmlHttpRequest.readyState == XMLHttpRequest.DONE) {

               if (xmlHttpRequest.status == 200) {
                   // on success get the response text and
                   // insert it into the ajax-example DIV id.

	jsFunction(xmlHttpRequest.responseText)
               }
               else if (xmlHttpRequest.status == 400) {
                   // unable to load the document
                  alert('Status 400 error - unable to load the document.');
               }
               else {
                   alert('Unexpected error!');
               }
            }
        };
        xmlHttpRequest.open("GET", "example.php", true);
        xmlHttpRequest.send();
    }

function cleanSubg(suId){
	document.getElementById('f2').innerHTML = ''
	document.getElementById('f2').innerHTML = varValGlobal + ':' + document.getElementById(suId).innerHTML.slice(0, -3).trim()
	alert('Ejecuta javascript function para enviar valor a PHP/bash: '+document.getElementById('f2').value)
	var group=document.getElementById('f2').innerHTML
	alert(group)
	ajax_post(group)
	}

function ajax_post(group){
    var hr = new XMLHttpRequest();
    var url = "scripts/ajax_post.php";
    var fn = group;
    var vars = "group="+fn;
    hr.open("POST", url, true);
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		    var return_data = hr.responseText;
			document.getElementById("resultsMenu").innerHTML = return_data;
	    }
    }
    hr.send(vars);
    document.getElementById("resultsMenu").innerHTML = "processing...";
	}

function ajax_madeOf(madeOfId){
	//alert('madeOf function')
	document.getElementById('f3').innerHTML = document.getElementById(madeOfId).innerHTML.slice(0, -2).trim()
	var reg=document.getElementById('f1').innerHTML.trim()
	var groupSubg=document.getElementById('f2').innerHTML.trim()
	var madeOf=document.getElementById('f3').innerHTML.trim()
	var plus=document.getElementById('f4').innerHTML.trim()

    //Create an XMLHttpRequest object
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/ajaxMadeOf.php";
    // variables containing the data on the client-side to send to some PHP script on the server-side
    //var ln = document.getElementById("last_name").value;
    	//var vars = "firstname="+fn+"&lastname="+ln;
    var fn = groupSubg;var ln = madeOf;
    	var vars = "group="+fn+"&madeOf="+ln;

    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    //Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
	    	//To be executed when the 'status 200' is reached
		    var return_data = hr.responseText;
			document.getElementById("regLines").innerHTML = return_data;

	    }
    }
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);
    //HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
    document.getElementById("regLines").innerHTML = "processing...";
	}

var data=''
var ctrl=1
function search1234(pipo){
	alert(document.getElementById("results").innerHTML)
	document.getElementById('f1').innerHTML=''
	document.getElementById('f25').innerHTML=''

	if (pipo == 4){alert('pipo=4, Closed Search cow click => ctrl=0, 1 es 1ª vez');ctrl=0}
	if (ctrl == 1){alert('Only if ctrl=1 ni pipo=4 o closed search cow click => crl=0 tambien, 1 es 1ª vez');ctrl=0;

	document.getElementById('f4').innerHTML="Select a food, load the nutrients, and add them to the 'Food List'. Read the tutorial on this page.";
	//document.getElementById('search1234').innerHTML='<button style="width:110px;" onclick="clearForm()">Set Source</button>';
	document.getElementById('calculatefood').style.visibility='visible';
	}

	document.getElementById('calculatefood').style.visibility='visible';

	var reg=document.getElementById('f1').innerHTML.trim()+'@'+document.getElementById('f2').innerHTML.trim()+'@'+document.getElementById('f3').innerHTML.trim()+'@'+document.getElementById('f25').innerHTML.trim()

    //Create an XMLHttpRequest object
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/ajaxSearchMesa.php";
    	var vars="group="+reg;		//"group="+fn+"&madeOf="+ln;

    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    //Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
	    	//To be executed when the 'status 200' is reached
			var return_data=hr.responseText
	data=return_data
	//alert('search1234 return: '+return_data)
		//		document.getElementById("regLines").innerHTML = return_data;
	arrayreg1234(data)


	    }
	}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
	//alert('search1234 inmediatamente antes de enviar vars: '+vars)
    hr.send(vars);
    //HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
    //document.getElementById("regLines").innerHTML = "processing...";
	}

var nm=0
function arrayreg1234(data){
  var linesArrnm = [];
  var displayIn = '';

  if (data.trim() !== '') {
    linesArrnm = data.split("<br>");
  }

  // Reset nm if it exceeds the array length
  if (nm >= linesArrnm.length) {nm = 0;}

  // Calculate currentLength based on available lines
  var currentLength = Math.min(nm + 10, linesArrnm.length);

  // Build the displayIn string
  for (;nm < currentLength; nm++) {
    displayIn = displayIn + '<br>' + linesArrnm[nm];
  }

  // Update the HTML content
  var resultsDiv = document.getElementById("regLines");
  resultsDiv.innerHTML = '<div id="abc" style="font-weight:bold;margin:10px 0 0 10px;cursor:pointer;text-shadow: 2px 2px 4px rgba(0, 0, 255, 0.8);" onclick="arrayreg1234(data)">Free Search+</div>' + displayIn;

  // Reset the text content of the paragraph
  var paragraph = document.getElementById('abc');
  paragraph.textContent = 'Menu Display+';
  if (currentLength === linesArrnm.length) {nm = 0;}
	}

ctrldb='0'
function loadRegisters(yourId){

	document.getElementById('f1').innerHTML=''
	document.getElementById('f25').innerHTML=''

	if (yourId.substring(0,2) === 'IR'){
	alert('substring = IR')
	ffBlack=document.getElementById('ir'+yourId.substring(2)).innerHTML
	document.getElementById('ff').innerHTML=ffBlack.replace(/\|\|/g, '|0|').replace(/\|\|/g, '|0|');
	registry=document.getElementById('IR'+yourId.substring(2)).innerHTML;
	registry=registry.replace(/\|\|/g, '|0|').replace(/\|\|/g, '|0|')
		document.getElementById('borrame2').innerHTML=document.getElementById('db').innerHTML;
		alert('registry IR: '+registry)
	}

	if (yourId.substring(0,2) === 'ID'){
	alert('substring = ID')
	document.getElementById("results").innerHTML=''
	ffBlack=document.getElementById('id'+yourId.substring(2)).innerHTML
	ffBlack = ffBlack.replace(/\|\|/g, '|0|').replace(/\|\|/g, '|0|')
	document.getElementById('ff').innerHTML=ffBlack;

		document.getElementById('borrame1').innerHTML="default.csv";
		document.getElementById('chooseSource').innerHTML="Choose Source";
		document.getElementById('borrame2').innerHTML=document.getElementById('db').innerHTML;
		registry=document.getElementById(yourId).innerHTML;
		registry=registry.replace(/\|\|/g, '|0|').replace(/\|\|/g, '|0|')
		alert('registry: '+registry)
		ctrldb=1
	}

	if (ctrldb === '0'){

	ctrldb='1';
    if (dbsource === ''){

    document.getElementById('borrame2').innerHTML=document.getElementById('db').innerHTML;
    alert('if-then=closeORfree? loadRegister ctrldb'+ctrldb+' free search made dbsource = db borrame1 = dbsource: '+dbsource)
    }
    else
    {
    //dbsource=document.getElementById('db').innerHTML

    alert('else=closeORfree loadRegister ctrldb'+ctrldb+' free search made dbsource = db borrame1 = dbsource: '+dbsource)
    }
	alert('fin loadRegister ctrldb'+ctrldb+' free search made dbsource = db borrame1 = dbsource: '+dbsource)
	//alert('loadRegister in '+dbsource)
	}

	var arrRegOneByOne=registry.split("|")
	//alert('Omega3 arrRegOneByOne[12]: '+arrRegOneByOne[12]+' Omega6[13] : '+arrRegOneByOne[13])
	if ( arrRegOneByOne[12] === ''){arrRegOneByOne[12]=0;}
	if ( arrRegOneByOne[13] === ''){arrRegOneByOne[13]=0;}

	var omegas=parseFloat(arrRegOneByOne[12]) + parseFloat(arrRegOneByOne[13])

	var vitB=parseFloat(arrRegOneByOne[15])+parseFloat(arrRegOneByOne[16])+parseFloat(arrRegOneByOne[17])+parseFloat(arrRegOneByOne[18])+parseFloat(arrRegOneByOne[19])+parseFloat(arrRegOneByOne[20])

	for (u=15;u < 21; u++) {
		if (arrRegOneByOne[i] === ''){arrRegOneByOne[i]=0;}
	}

	//alert(vitB.toFixed(2))
	document.getElementById('f1').innerHTML=arrRegOneByOne[0]
	document.getElementById('f2').innerHTML=arrRegOneByOne[1]
	document.getElementById('f3').innerHTML=arrRegOneByOne[2]
	document.getElementById('f25').innerHTML=arrRegOneByOne[3].substring(0, 42)+' ...';
		document.getElementById('f4').innerHTML=arrRegOneByOne[3];document.getElementById('f4bis').innerHTML=arrRegOneByOne[3];
	document.getElementById('f5').innerHTML=arrRegOneByOne[4];
	document.getElementById('f6').innerHTML=arrRegOneByOne[5];
	document.getElementById('f7').innerHTML=arrRegOneByOne[6];
	document.getElementById('f8').innerHTML=arrRegOneByOne[7];
	document.getElementById('f9').innerHTML=arrRegOneByOne[8];
	document.getElementById('f10').innerHTML=arrRegOneByOne[9];
	document.getElementById('f11').innerHTML=arrRegOneByOne[10];
	document.getElementById('f12').innerHTML=arrRegOneByOne[11];
	document.getElementById('f13').innerHTML=omegas.toFixed(2);				//omegas
	document.getElementById('f14').innerHTML=arrRegOneByOne[14];
	document.getElementById('f15').innerHTML=vitB.toFixed(2);	//vitB

	document.getElementById('f16').innerHTML=arrRegOneByOne[21];	//0
	document.getElementById('f17').innerHTML=arrRegOneByOne[22];	//2.4
	document.getElementById('f18').innerHTML=arrRegOneByOne[23];	//4.6
	document.getElementById('f19').innerHTML=arrRegOneByOne[24];	//61
	document.getElementById('f20').innerHTML=arrRegOneByOne[25];
	document.getElementById('f21').innerHTML=arrRegOneByOne[26];
	document.getElementById('f22').innerHTML=arrRegOneByOne[27];
	}

function loadXMLDoc() {
	let xhr = new XMLHttpRequest();

	xhr.open('GET', 'bd/menu/ajaxMadeOf.tmp', false);

	try {
		xhr.send();
		if (xhr.status != 200) {
			alert(`Error ${xhr.status}: ${xhr.statusText}`);
		} else {
			arrayOfLines = xhr.response.split("\n");
	//alert('loadXMLDoc ajaxMadeOf.tmp para variable name arrayOfLines\n\n '+arrayOfLines)
		}
		}
			catch(err) {alert("Request failed");}
	}

function clearForm(){
	ctrl=1;emptyfields();
	alert('Work Mode')

	document.getElementById('f4').innerHTML="Reg. No.: Use Group:Subgroup to specify a subgroup. Mark one or more in 'Food Menu'.";
	//document.getElementById('addtodatabase').style.visibility='hidden';
	document.getElementById('calculatefood').style.visibility='visible';

	document.getElementById('resultsMenu').innerHTML = ''
	document.getElementById('regLines').innerHTML = ''
	}

function textLinesToArray(myarray){
	//alert('function textLinesToArray(myarray)\n\n'+myarray)
	document.getElementById('search1234').innerHTML='<button style="width:110px;" onclick="clearForm()">Set Source</button>'

	//document.getElementById('addtodatabase').style.visibility='visible';
	document.getElementById('calculatefood').style.visibility='visible';
	//process the array lines
	//alert('arrayOfLines[0]: '+arrayOfLines[0])
	for (let c=0; c< arrayOfLines.length-1; c++)
	{
    var result = arrayOfLines[c].match(document.getElementById('f1').innerHTML+'\\|'+document.getElementById('f2').innerHTML+'\\|');

		if (arrayOfLines[c].match(document.getElementById('f1').innerHTML+'\\|'+document.getElementById('f2').innerHTML+'\\|'))
		{
			arrayElemMatch=arrayOfLines[c]; //llena el array arrayElemMatch
			//alert('el array que match\n\n'+arrayOfLines[c])
		}
	}

	//carga los valores del array fieldsElemeMatch con el string del array arrayElemMatch
	fieldsElemMatch = arrayElemMatch.split('|');
	//alert('fieldsElemMatch[3]: '+fieldsElemMatch[3])

	for (let c=1; c< 23; c++){

	document.getElementById('f'+c).innerHTML=fieldsElemMatch[c-1]
	messageEnd = messageEnd + '_'+fieldsElemMatch[c-1]
	}

	let failed=Number('0'+document.getElementById('f13').innerHTML)/2;
	document.getElementById('f13').innerHTML=failed.toFixed(2);
	document.getElementById('f15').innerHTML=Number(document.getElementById('f15').innerHTML).toFixed(2);

	document.getElementById('f25').innerHTML = fieldsElemMatch[3].substring(0,29)+' ...';
	document.getElementById('messageEnd').innerHTML='';
	//document.getElementById('messageEnd').innerHTML=messageEnd;
	}

//global
    function handleClick(event) {
        event.preventDefault();
        // Opens the URL in a new tab
        window.open('scripts/manager/tutorial/1722228906681200_FoodList.html', '_blank');
    }
sourceStrip='';getbackSource=''
function calculate(){


/*chooseSource = document.getElementById("chooseSource").textContent.trim();
chooseTarget = document.getElementById("db").textContent.trim();
union = chooseSource + chooseTarget;
//document.getElementById("impExpMess").innerHTML = ""
var regex = /^[a-zA-Z0-9_-]+\.((txt)|(csv))$/;
		if (union.includes('Choose') || !chooseSource.includes('.csv') || !regex.test(chooseTarget) ) {
    document.getElementById("impExpMess").innerHTML = "<span style='color:red'><b>Calculate Alert: Source-target selection error. Read the rules at <a style='color:red;cursor:pointer;' href='#' onclick='handleClick(event)'>Import/Export</a>. Exit.</b></span>";
    //document.getElementById("tb1").style.display='none';document.getElementById("tb2").style.display='block';
}
    else
	{
	 document.getElementById("impExpMess").innerHTML = "";
}
*/

	document.getElementById('f23').innerHTML=Math.round (document.getElementById('f23').innerHTML*100) / 100; /*.toFixed(2);*/

	//Filter F23
	if (document.getElementById('f23').innerHTML=='<br>'){alert('Quantity must have a numeric value. Exit now.');document.getElementById('f23').innerHTML='';exit;}
	if (document.getElementById('f23').innerHTML=='0'){alert('Quantity can not be zero. Exit now.');document.getElementById('f23').innerHTML='';exit;}
	if (document.getElementById('f23').innerHTML.length=='0'){alert('Quantity can not be blank. Exit now.');document.getElementById('f23').innerHTML='';exit;}
	if (document.getElementById('f23').innerHTML.match(/^[0-9.]+$/)) {document.getElementById('calculatefood').style.visibility='visible';}else{alert('Field Quantity is not valid. Exit now.');document.getElementById('f23').innerHTML='';exit}

	////////////////////////////////////////////
	var k0 = '0';
	var arri = []; // You need to initialize the array

	for (var i = 0; i < 24; i++) {
		var id = i + 1;
		arri[i] = document.getElementById('f'+id).innerHTML;
	}
	strip=arri[0]+'|'+arri[1]+'|'+arri[2]+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+arri[3]+'|'+k0+'|'+arri[21]+'|'+arri[6]+'|'+arri[7]+'|'+k0+'|'+arri[12]+'|'+k0+'|'+arri[8]+'|'+arri[5]+'|'+k0+'|'+k0+'|'+k0+'|'+arri[11]+'|'+arri[4]+'|'+arri[9]+'|'+arri[10]+'|'+arri[13]+'|'+k0+'|'+k0+'|'+arri[16]+'|'+arri[17]+'|'+arri[14]+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+arri[15]+'|'+arri[18]+'|'+arri[19]+'|'+k0+'|'+arri[20]+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0

	///////////////////////////////
	sourceStrip=document.getElementById('ff').innerHTML
	quantity=document.getElementById('f23').innerHTML
	// Replace the first occurrence of '|0|0|0|' with '|0|quantity|0|'
	var sourceStrip = sourceStrip.replace(/(\|0\|0\|0\|)/, "|"+quantity+"|0|0|");
	document.getElementById('ff').innerHTML=sourceStrip
	//alert('replaced '+sourceStrip)
	getbackSource=getbackSource+'#'+sourceStrip
	///////////////////////////////////
	if (document.getElementById('borrame1').innerHTML === document.getElementById('borrame2').innerHTML){
	document.getElementById('f4').innerHTML='<span style="background-color:white;color:blue;"><b>Both files are the same. Not allowed in the export list.</b></span>'
	}
	else
	{
	document.getElementById('expt').value=document.getElementById('expt').value+document.getElementById('borrame1').innerHTML+'#'+document.getElementById('borrame2').innerHTML+'#'+document.getElementById('ff').innerHTML+'_'
	alert('ahora: '+document.getElementById('expt').value)

	}

	////////////////////
	//###Kc Total### (f22 kc 100 gr, 23 Q, 24 kc total)
	kcTotal=document.getElementById('f22').innerHTML * document.getElementById('f23').innerHTML/100;
		document.getElementById('f24').innerHTML=kcTotal.toFixed(2)

	if (document.getElementById('editableRecipe').value.endsWith("\n")) {}else{document.getElementById('editableRecipe').value=document.getElementById('editableRecipe').value+'\n';}

	//Calc all nutrients
	for (let z=5; z<22; z++){
	var a=document.getElementById('f'+z).innerHTML;
	var b=document.getElementById('f23').innerHTML;
	var numT=a*b/100;
	document.getElementById('f'+z).innerHTML=numT.toFixed(2)
	}

	foodToArea=''

	for (let z=2; z<22; z++){
	var a=document.getElementById('f'+z).innerHTML;
	var b=document.getElementById('f23').innerHTML;
	var numT=a*b/100;
	foodToArea=foodToArea+'|'+document.getElementById('f'+z).innerHTML
	}
	arrayElemMatch=document.getElementById('f1').innerHTML+foodToArea+'|'+document.getElementById('f22').innerHTML+'|'+document.getElementById('f23').innerHTML+'|'+document.getElementById('f24').innerHTML

	const string = document.getElementById('editableRecipe').value;
	const substring = document.getElementById('f1').innerHTML+'|'+document.getElementById('f2').innerHTML;

	if (string.includes(substring) == true){
	//document.getElementById('calculatefood').style.visibility='visible';
	document.getElementById('f23').innerHTML='';//quantity reset
	}
	else
	{
	txtarea=document.getElementById('editableRecipe').value.replace(/(^[ \t]*\n)/gm, "")+arrayElemMatch+'|'+document.getElementById('f23').innerHTML+'|'+document.getElementById('f24').innerHTML
	document.getElementById('editableRecipe').value =txtarea+'\n';document.getElementById('f23').innerHTML='';
	}
	}

var mn = 0;

function search123mn(date) {
	document.getElementById("results").innerHTML=''
	var linesArrmn = [];
	var displayIn = '';
	if (date.trim() !== '') {
		linesArrmn = date.split("<br>");
	}
	//alert('mn: '+mn+', lenght: '+linesArrmn.length)
	// Reset mn if it exceeds the array length
	if (mn >= linesArrmn.length) {mn = 0;}

	// Calculate currentLength based on available lines
	var currentLength = Math.min(mn + 10, linesArrmn.length);

	// Build the displayIn string
	for (; mn < currentLength; mn++) {
		displayIn = displayIn + '<br>' + linesArrmn[mn];
	}

	// Update the HTML content
	var resultsDiv = document.getElementById("results");
	resultsDiv.innerHTML = '<div id="abc" style="font-weight:bold;margin:10px 0 0 10px;cursor:pointer;text-shadow: 2px 2px 4px rgba(0, 0, 255, 0.8);" onclick="search123mn(date)">Free Display+</div>' + displayIn;

	// Reset the text content of the paragraph
	var paragraph = document.getElementById('abc');
	paragraph.textContent = 'Closed Display+';
	if (currentLength === linesArrmn.length) {mn = 0;}
	}


function emptyfields(){
	let vf25=document.getElementById('f25').innerHTML
	for (i=5;i<26;i++){document.getElementById('f'+i).innerHTML=''}
	document.getElementById('f25').innerHTML=vf25
	}

data=''
function dataSend(){

		data_=data.replace(/pls/g, '+');//data_=data_.replace(/#/g, '|');
alert('db is f7: '+data)
exit
		var hr = new XMLHttpRequest();
		//Variable containing the url to get to the server side php script
		var url = "scripts/searchdb.php";
		var fn = data;
	alert('dataSend fn: '+data)
			var vars = "group="+'\''+fn+'\'';
	//alert('vars: '+vars)
		hr.open("POST", url, true);
		//Set content type header information for sending url encoded variables in the request
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
			hr.onreadystatechange = function() {
				if(hr.readyState == 4 && hr.status == 200) {
					//To be executed when the 'status 200' is reached
					return_data = hr.responseText;

						currentLine = 0;
		date=return_data
		search123mn(date);


				} //fin if onready
			} //fin function function
		//Execute the request adding the name_variable value pairs before 'status 200' is reached
		hr.send(vars);
		//HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
		document.getElementById("results").innerHTML = "processing...";
	exit
	}

var data=''
var db=''
var dbsource=''

function searchdb(toscr){

	alert('ini1 '+document.getElementById('borrame1').innerHTML)

	if (db === 'default.csv' || db === 'work.csv' || db === 'in.bor'){db=''};
	if (dbsource === 'default.csv'){dbsource=''};
	alert('db: '+db+'  dbsource: '+dbsource)

	kwrd=document.getElementById('kw_1').innerHTML
	if (kwrd == 'Key Word') {kwrd=''}

	if (document.getElementById('andor').checked == true){andor='and'}else{andor=''}
	//fin if andor
			var checkboxes = document.getElementsByName('group');
			var serieT=''

			for (var i = 0; i < checkboxes.length; i++)
			{
				if (checkboxes[i].checked) {serie=checkboxes[i].id;arrserie=serie.split('_');serieT=serieT+','+arrserie[1];}
				//fin if checkboxes for serieT
			} //fin for
			var arrSerieT = serieT.substring(1).split(',');
			arrSerieT.sort(function(a, b) {
  			return a - b;
			});
			serieT=serieT.slice(1)

	//document.getElementById('f4').innerHTML='';
	if (document.getElementById('f25').innerHTML == ''){document.getElementById('f25').innerHTML == '[a-z]+'}
	//if (ctrl == '0'){alert("Change to Search MODE. Click on 'Recipe MODE'");exit;}

	first=document.getElementById('f1').innerHTML;first=first.trim()
	second=document.getElementById('f2').innerHTML;second=second.trim();
	third=document.getElementById('f3').innerHTML;third=third.replace(/\|+$/g, '');third=third.trim();
	fourth=document.getElementById('f4bis').innerHTML;fourth=fourth.replace(/\|+$/g, '');fourth=fourth.trim()

	//filter f1
	alert('ini2: id must be empty ')
	var regex = /^\d+|^$/;
	if (!regex.test(first)){
		document.getElementById('f1').innerHTML=''
		document.getElementById('f4').innerHTML='Reg. No. policy: Content not permitted. Read the Manual for allowed keywords. Exit.';return;
	}//fin filter f1
	alert('ini3: group '+second)
	//complete or empty


	var regex = /^([0-9]{1,2}:[a-z]+)$|^\(\[0-9\]\{1,2\}:\[a-z\]+\)$|^$/; //\(\[0-9\]{1,2}:[a-z \-]+\)
	if (!regex.test(second) && second !== '([0-9]{1,2}:[a-z]+)' ){
		document.getElementById('f2').innerHTML="([0-9]{1,2}:[a-z -]+)"
		document.getElementById('f4').innerHTML="General message (Group:Subgroup): Only one empty cell, pattern structure, or compatible pattern is allowed. This regex structure, ([0-9]{1,2}:[a-z -]+), will match any allowed value pair, such as num:word. Exit.";return
	}//end filter f1

	//filter f25
	//document.getElementById('f4bis').innerHTML='[a-z]+'
	alert(document.getElementById('f4bis').innerHTML)
	if ( document.getElementById('f4bis').innerHTML == ''){document.getElementById('f4').innerHTML="The 'plus-words field' is not allowed to be empty. It is full on all registers. Exit.";
	document.getElementById('f4bis').innerHTML='[a-z]+'
	return;}

	second=second.replace(/\+/g, 'pls');third=third.replace(/\+/g, 'pls');fourth=fourth.replace(/\+/g, 'pls');
	second=second.replace(/\|/g, '#');third=third.replace(/\|/g, '#');fourth=fourth.replace(/\|/g, '#');
	second=second.replace(/&amp;/g, '.*');third=third.replace(/&amp;/g, '.*');fourth=fourth.replace(/&amp;/g, '.*');

	alert('replace 758')

	if ( toscr === 'replace'){	//
	alert('db and dbsource: '+document.getElementById('borrame2').innerHTML+' '+document.getElementById('borrame1').innerHTML)
	//in javascript this does not work. Why?

	var regex = /^[0-9]+$/
	if (!regex.test(first)) {
	document.getElementById('f4').innerHTML="Replace in DB: Reg No. is required. Exit."
	return
	} //fin pattern
	alert('db and dbsource: '+db+' '+dbsource)
	if ( fourth === 'Deleted'){
	document.getElementById('f4').innerHTML="Replace in DB (Plus-words): Use 'Delete in database' instead. Read the Manual (recovery is cumbersome)."
	return
	}//end filter
	alert('db and dbsource: '+db+' '+dbsource)

	var regex = /^([0-9]{1,2}:[a-z -]+)$|^$/;
	if (!regex.test(second)){
	document.getElementById('f2').innerHTML=''
		document.getElementById('f4').innerHTML="Replace in DB (Group:Subgroup): its data should match its pattern. Empty cell is not allowed. Read the Manual. Exit";
	return
	}
	else
	{
 		if (second == ''){
		document.getElementById('f4').innerHTML="Replace in DB (Group:Subgroup): All empty fields should be progressively filled. Read the Manual. Exit.";
		return
		}
	}//end filter

	alert('1111db and dbsource: '+db+' '+dbsource)
	var regex = /^([a-zA-Z]+(-[a-zA-Z]+)?(#[a-zA-Z]+(-[a-zA-Z]+)?)?)+$|^$/;
	if (!regex.test(third)){
	document.getElementById('f3').innerHTML=''
		document.getElementById('f4').innerHTML="Replace in DB: the 'Madeof cell' data must match its pattern, and can not be empty. Read the Manual. Exit";
	return
	}
	else
	{
 		if (third == ''){
		document.getElementById('f4').innerHTML="Replace in DB (Madeof): All empty fields should be progressively filled. Read the Manual. Exit.";
		return
		}
	}//end filter
	alert('db and dbsource: '+db+' '+dbsource)

	//filter f25 => also needed f2 and f3
	const allowedCharacters = /[a-zA-Z0-9 ,;@%\.-]*/;
	const input =document.getElementById('f4bis').innerHTML;
	const matches = input.match(allowedCharacters);

		if (matches && matches[0] === input) {//
	alert('hey '+db+' '+dbsource+' '+document.getElementById("db").innerHTML)
		data=andor+'|replace|'+first+'|'+second+'|'+third+'|'+fourth+'|'+document.getElementById('borrame1').innerHTML+'|'+document.getElementById('borrame2').innerHTML
	alert('hey db: '+db+' dbsource: '+dbsource+' '+document.getElementById("db").innerHTML)
			if ( db !== dbsource ){alert('DIFF');document.getElementById('f4').innerHTML='Different source and target DBs. Sent data: '+data+' Read the log.txt file in the Internet browser.';}
			else {
			document.getElementById('f4').innerHTML='Replace in DB: Sent '+data
			}//end

		} else {
		//document.getElementById('f25').innerHTML=''
		document.getElementById('f4').innerHTML='Replace in DB (Plus-words): The Plus-words should match its pattern. Its cell can never be empty: you can use periods, letters, digits, commas, semicolons, @, -, and %. Exit.'
		return
		}//end if matches
	dataSend()
	alert('3')
	return
	}//fin if replace

alert('predelete')
if ( toscr == 'delete'){

		pattern= /^\d+$/
		if (!pattern.test(document.getElementById('f1').innerHTML)) {

			if ( !serieT == ''){
				document.getElementById('f4').innerHTML="Delete: Reg No. required. Also uncheck Groups in the 'Food Menu'. Exit."
				}else{
				document.getElementById('f4').innerHTML="Delete: Reg No. required. Exit."}
		return
		} //fin pattern
	//.replace(/&amp;/g, '.*');data_=data.replace(/pls/g, '+');data_=data_.replace(/#/g, '|');
			data="|delete|"+first+"#|"+second+"|"+third+"|"+fourth
	alert('frefind4 '+data)

			document.getElementById('f4').innerHTML='Delete in DB (Warning: Read the Manual): Data sent: '+data
	} //fin delete
//


if ( toscr == 'expImp'){
	alert('expImp')
	alert(document.getElementById('expt').value)

	exportTextArea=document.getElementById('expt').value.slice(0, -1)
	alert('ExportTextArea: '+exportTextArea)
		arrExportTextArea = exportTextArea.split('_');
	alert('arrExportTextArea.length: '+arrExportTextArea.length)

	if (arrExportTextArea.length > 1){
	alert(arrExportTextArea.length)

		dataCollect=''
		const length = arrExportTextArea.length;
			for (let i = 0; i < length; i++) {
			  alert(arrExportTextArea[i]);

			arrayDB=arrExportTextArea[i].split('#')
			arrayF=arrayDB[1].split('|')
			data='|export|'+arrayF[0]+'|'+arrayF[6]+'|'+arrayF[7]+'|'+arrayF[8]+'|'+dbsource+'|'+arrayDB[0]
			dataCollect=data+'#'+dataCollect
			alert('|export|'+arrayF[0]+'|'+arrayF[6]+'|'+arrayF[7]+'|'+arrayF[8]+'||'+arrayDB[0])
			}
			data=dataCollect.slice(0, -1)
			alert('send data 1: '+data)	//alert('db: '+db+'  dbsource: '+dbsource)
	}else{
	alert(arrExportTextArea[0])
		arrayDB=arrExportTextArea[0].split('#')
	alert(arrayDB[2])
		arrayF=arrayDB[2].split('|')
		data='|export|'+arrayF[0]+'|'+arrayF[1]+'|'+arrayF[2]+'|'+arrayF[3]+'|'+arrayF[4]+'|'+arrayF[5]+'|'+arrayF[6]+'|'+arrayF[7]+'|'+arrayF[8]+'|'+arrayF[9]+'|'+document.getElementById('borrame1').innerHTML+'|'+document.getElementById('borrame2').innerHTML
		alert('send data 2: '+data);
		};
	return
	dataSend()
	return
	}



if ( toscr == 'find'){
//document.getElementById('f4').innerHTML=document.getElementById('f4bis').innerHTML
	ctrldb='0'
	alert('entra en find: '+toscr)
	alert('data1 '+data)
	pattern= /^\d+$/
	if (pattern.test(document.getElementById('f1').innerHTML)) {

	//data=andor+'|find|'+first+'#'+db+'#'+kwrd+'|||'+fourth
	data=andor+'|find|'+first+'|'+second+'|'+third+'|'+fourth+'|'+document.getElementById('borrame1').innerHTML
	alert('data2 '+data)
	data_=data.replace(/pls/g, '+');//data_=data_.replace(/#/g, '|');
	document.getElementById('f4').innerHTML="Data sent: <span style='color:white'>"+data_+'</span>'

	} //fin pattern
	else
	{
	//the litteral search, the formula regex search
	var regex = /(^$)|^(?:[a-zA-Z]+([a-zA-Z]+)?#)*[a-zA-Z]+([a-zA-Z]+)?$|^[a-zA-Z.*?#&^$@+\-()[\]\\]+$|[_:]/;
		if (!regex.test(third)){
			third="error";
		if (third == 'error'){document.getElementById('f4').innerHTML="Made of: Not allowed. Exit.";return}
		}//end filter f3^(?:[a-zA-Z]+([a-zA-Z]+)?#)*[a-zA-Z]+([a-zA-Z]+)?$
		//(^$)|^(?:[a-zA-Z]+([a-zA-Z]+)?#)*[a-zA-Z]+([a-zA-Z]+)?$|^\[(.*?#&^$@-+[]()|\)?[a-zA-Z]$

	//the litteral search, the formula regex search
	var regex = /^(?:[a-zA-Z]+([a-zA-Z]+)?#)*[a-zA-Z]+([a-zA-Z]+)?$|^[a-zA-Z., *?#&^$@+\-()[\]\\]+$|^\[a-z\]\+$|[_:]/;


		if (!regex.test(fourth)){
			third="error";
		if (third == 'error'){document.getElementById('f4').innerHTML="Plus-words: Not allowed. Exit.";return}
		}//end filter f3^(?:[a-zA-Z]+([a-zA-Z]+)?#)*[a-zA-Z]+([a-zA-Z]+)?$

						//var regex = /^([0-9]{1,2}:[a-z -]+)$|^$/;
						if (!serieT == ''){
							//document.getElementById('f2').innerHTML=""
							second=''
						}//end filter f1

					  //first => '',not_, etc. if serieT full => second ''
					  db=document.getElementById('db').innerHTML
	data=andor+'|find|'+first+'#'+db+'#'+kwrd+'|'+second+''+arrSerieT+'|'+third+'|'+fourth
	alert(document.getElementById('borrame2').innerHTML)
	alert(document.getElementById('db').innerHTML)
	data_=data.replace(/pls/g, '+');//data_=data_.replace(/#/g, '|');
	document.getElementById('f4').innerHTML="Data sent: <span style='color:white'>"+data_+'</span>'
	alert('data3 '+data)
	} //fin pattern
alert('fin pattern'+data)
	} //fin find
alert('fin find'+data)
	var groupgrid=document.getElementById('f2').innerHTML;
	pattern = /.*/ 			///^(?:[1-9]|1[0-8]):[a-zA-Z0-9]+( [a-zA-Z0-9]+)?$/;

    //Create an XMLHttpRequest object
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/searchdb.php";
    var fn = data;

    	var vars = "group="+'\''+fn+'\'';
	//alert('vars: '+vars)
		hr.open("POST", url, true);
		//Set content type header information for sending url encoded variables in the request
		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
			hr.onreadystatechange = function() {
				if(hr.readyState == 4 && hr.status == 200) {
					//To be executed when the 'status 200' is reached
					return_data = hr.responseText;
						currentLine = 0;
	date=return_data
	search123mn(date);
					//displayNextLines(date)

				} //fin if onready
			} //fin function function
		//Execute the request adding the name_variable value pairs before 'status 200' is reached
		hr.send(vars);
		//HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
		document.getElementById("results").innerHTML = "processing...";
	} //fin ajax

function addToDataBase(){
	a = document.getElementById('f1').innerHTML
	b = document.getElementById('f2').innerHTML
	c = document.getElementById('f3').innerHTML
	d = document.getElementById('f25').innerHTML

	if ( a == '' || b == '' || c == '' || d == '' ){alert('No allowed. Fields 1, 2, 3, 4 can not be empty.\n\nExit.');document.getElementById('f1').innerHTML = fieldsElemMatch[0];exit;}

	if (a.match(/([aA-zZ])/)){alert('Not allowed.\n\nThis method requires only digits, the \'New\' checkbox unchecked—always replaced by a new timestamp if checked—and obviously great care in replacing records.\n\nExit.');	document.getElementById('f1').innerHTML = fieldsElemMatch[0];exit;}

	const arrayForm = ['f1','f2','f3','f25','f22','f7','f8','f13','f9','f6','f12','f5','f10','f11','f14','f17','f18','f15','f16','f19','f20','f21'];
	var strForm=''
	for (const element of arrayForm) {
		strForm=strForm+'|'+document.getElementById(element).innerHTML
	}
	//sendstrForm
	strForm=document.getElementById('replaceCheck').checked+strForm;

    //Create an XMLHttpRequest object
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/regFormToScr.php";

    var fn = strForm;
    	var vars = "group="+'\''+fn+'\'';
    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				var return_data = hr.responseText;
				document.getElementById("message").innerHTML = return_data;
				document.getElementById('replaceCheck').checked = 'true'
	document.getElementById("message").classList.add('blink');
	//alert('addToDataBase: '+return_data)
			}
		}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);
    //HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
    document.getElementById("message").innerHTML = "processing...";
	}


function calcRecipe(){
	alert('calcRecipe')
	//////////////////////////////////////
	var k0 = '0';
	var arri = []; // You need to initialize the array

	for (var i = 0; i < 24; i++) {
		var id = i + 1;
		arri[i] = document.getElementById('f'+id).innerHTML;
	}
	strip=arri[0]+'|'+arri[1]+'|'+arri[2]+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+arri[3]+'|'+k0+'|'+arri[23]+'|'+arri[6]+'|'+arri[7]+'|'+k0+'|'+arri[12]+'|'+k0+'|'+arri[8]+'|'+arri[5]+'|'+k0+'|'+k0+'|'+k0+'|'+arri[11]+'|'+arri[4]+'|'+arri[9]+'|'+arri[10]+'|'+arri[13]+'|'+k0+'|'+k0+'|'+arri[16]+'|'+arri[17]+'|'+arri[14]+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+arri[15]+'|'+arri[18]+'|'+arri[19]+'|'+k0+'|'+arri[20]+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0+'|'+k0


	//exit
	var lineFields=new Array();
	var lineFieldsT=new Array();

	areaLines=document.getElementById('editableRecipe').value.split('\n');

	i=4
	forT=0
	for(var i=4;i< 24;i++){
		for(var j = 0;j < areaLines.length-1;j++){

				spliter1=areaLines[j].split('|')
				forT=parseFloat(forT)+parseFloat(spliter1[i])

				lineFieldsT[i]=parseFloat(forT)
		}
	forT=0
	}

	var stripToExport=''
	for(var t=5;t< 25;t++){
	document.getElementById('f'+t).innerHTML=parseFloat(lineFieldsT[t-1]).toFixed(2)

	stripToExport=stripToExport+'|'+parseFloat(lineFieldsT[t-1]).toFixed(2)

	}
	Kc100=parseFloat(document.getElementById('f24').innerHTML)*100/parseFloat(document.getElementById('f23').innerHTML)
	document.getElementById('f22').innerHTML =  Kc100.toFixed(2)

		alert('stripToExport: '+stripToExport)
	//alert('A \'for loop\' is needed to display the totals in the form : '+parseFloat(lineFieldsT[4]))
	document.getElementById('f1').innerHTML=''
	document.getElementById('f2').innerHTML=''
	document.getElementById('f3').innerHTML=''
	document.getElementById('f4bis').innerHTML='[a-z]+'
	document.getElementById('f4').innerHTML=''
	document.getElementById('regLines').innerHTML=''

	areaLines=[];lineFields=[];lineFieldsT=[]
	}

function saveRecipe(){
	alert('1 saveRecipe()')
	if (document.getElementById('recipeTitle').innerHTML.length=='0'){alert('Recipe Title can not be blank. Exit now.');exit;}
	if (document.getElementById('mainFoods').innerHTML.length=='0'){alert('Collection (.db) can not be blank. Exit now.');exit;}
	alert('2')

	//make the HTML Share file name
	recipeName=document.getElementById('recipeTitle').innerHTML

	recipeName=recipeName.replace(/\./g, "")
	alert(recipeName+'.'+Math.round(Date.now() / 1000))
	document.getElementById('recipeFilename').innerHTML=recipeName+'.'+Math.round(Date.now() / 1000)
	alert(recipeName+'.'+Math.round(Date.now() / 1000))
	//save recipeTitle|mainFoods
	var saveRec=document.getElementById('recipeFilename').innerHTML.replace(/^(?:&nbsp;|\s)+|(?:&nbsp;|\s)+$/ig,'')+"|"+document.getElementById('mainFoods').innerHTML.replace(/^(?:&nbsp;|\s)+|(?:&nbsp;|\s)+$/ig,'')+"#"

	//collect nutrients regs
	var Qlines=document.getElementById('editableRecipe').value.trim().replace(/\n/g, "_")

	saveRec=saveRec+Qlines.trim()+'#'

	// for de f1 a f24
	var saveLoop=''
	for(var i=1;i< 25;i++){
		saveLoop=saveLoop+"|"+document.getElementById('f'+i).innerHTML
		//saveLoop=saveLoop.replace(/\|/g, "'|'")
	}
	alert("saveloop: "+saveLoop)
	saveRec=saveRec+''+saveLoop
	saveRec=saveRec.replace(/&lt;/g, "<")
	saveRec=saveRec+'@'+getbackSource+'@'+document.getElementById('expt').value
	document.getElementById('messageEnd').innerHTML=saveRec

	alert('5')

    //Create an XMLHttpRequest object
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/ajaxSaveRecipe.php";

    //saveRecipe data on the client-side is sent to ajaxSaveRecipe.php PHP script on the server-side
    var fn = saveRec;

    	var vars = "group="+'"'+fn+'"';
	alert(vars)

    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				var return_data = hr.responseText;
				//document.getElementById("saveMessage").innerHTML = return_data;
			}
		}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);

	base_urla=base_url+'/mesa/recipes/recipes.php?filename=theTableOfTheDamascenaRose.1674960280'
	alert(base_url)

	window.open(base_url+'/mesa/recipes/recipes.php')
	document.getElementById('editableRecipe').value='';document.getElementById('expt').value='';sourceStrip='';getbackSource=''
	}

function ifCheck(){
	document.getElementById("message").classList.add('blink');
	if (document.getElementById('replaceCheck').checked == true){
		document.getElementById('message').innerHTML = '<i>To save</i>'

	//alert('Added a new timestamp in f1: '+document.getElementById('f1').innerHTML)
	}else{
		document.getElementById('message').innerHTML = '<i>To replace</i>'
	}
	}

</script>

</head>
<body id='grid'>
<?php echo exec("./scripts/menu.scr"); ?>

<div style='width:100%;font-family:satisfy;text-align:center;font-size:40px;text-shadow: 1px 1px 2px gold, 0 0 1em gold, 0 0 0.2em yellow;padding-left:5%;cursor:pointer;' translate="no"><span style='color:lightblue;text-shadow:1px 3px 2px #FFEFA0;'>༺ </span>  <span onclick="messageRefresh()">Drakkar Records</span>  <span style='color:lightblue;text-shadow:1px 3px 2px #FFEFA0;'> ༻</span> <span style='font-family:normal;font-size:12px;color:white;'> <i>... share Freedom, release Rights</i></span></div>
<div style='width:100%;font-family:satisfy;text-align:center;font-size:14px;text-shadow: 1px 1px 2px green, 0 0 1em blue, 0 0 0.2em green;'>Records Manager</div><br>

<span style='margin-left:10px;color:lightgray'>Source: </span><span style='color:lightgray' id='borrame1'>default.csv</span>
<span style='margin-left:5px;color:lightgray'>Target: </span><span style='color:lightgray' id='borrame2'> offside.txt</span>
<script>
document.getElementById('borrame1').innerHTML="defualt.csv"
document.getElementById('borrame2').innerHTML=" offside.txt"
</script>
<div style='text-align:center;color:lightblue;margin-bottom:5px;' translate="no"><b>_Nutrients Grid_</b></div>
<div id="regNum" style='display:none;'>Unique number. Identifies the nutrient content of a specific food. In the DB, one number pero row is placed in column 1.</div>
<div id="g-sg" style='display:none;'>Groups are numbered 1-18 next to their shortest description in 'Step 1'. Their subgroup keys are shown in 'Step 2'. In the DB both are split by a colon in column 2.</div>
<div id="madeof" style='display:none;'>Input a meaningfull keyword and click the 'Search in DB' button) or create ('Replace in DB' button) a food subgroup. You can input a term and click <span style='color:white'>Ⓖ</span> to retrieve info from internet.</div>

<div id="plus-words" style='display:none;'>'Search in DB' for a word in the descriptive field of records (read the <span style='color:white'>Manual</span> for multiple words), or input whatever you want and click <span style='color:white'>Ⓖ</span> to search the Internet for <span style='color:white'>info</span>.</div>

<table class='form'>
	<tr>
		<td id='search1234' style='background-color:#83580B;text-align:center;font-size:12px;color:yellow;font-weight:bold;cursor:pointer;'><div id='chooseSource' style='' onclick="destinity=0;kW1_()" onmouseout="document.getElementById('borrame1').innerHTML=document.getElementById(this.id).innerHTML;" contenteditable='true'>Choose Source</div></td>
		<td id='f4' colspan='8' contenteditable='true' style="border: 1px solid white;" oninput="document.getElementById('f4bis').innerHTML=document.getElementById('f4').innerHTML;"><span style='color:white;font-weight:bold;'>Remember</span>: You must write in this row to fill the cell 4 content. The content of this top row is sent to Bash. The content of the '4 Plus-words' cell is merely indicative
		</td>

	</tr>

	<tr class='alignLeft'><td style='width:8%;text-align:center;font-size:12px;color:yellow;cursor:pointer;'><button type='button' style='width:110px;margin-right:7px;color:blue;;background-color:yellow' onclick="searchdb('find')">Free Search</button></td><td id='regNum' style='width:8%;cursor:pointer;'><span onclick="alternateInfo('regNum|f1')">1 Reg. No.</span> <span style='color:white;margin-left:6px;cursor:pointer;font-size:12px;' onclick="window.open('https://www.mattilsynet.no/', '_blank')">Ⓝ</span></td><td style='width:10%;cursor:pointer;'><span onclick="alternateInfo('g-sg|f2')">2 Group:Subg.</span><span style='margin-left:6px;color:white;' onclick="window.open('https://www.google.com/search?q=grouping+food+classification&oq=grouping+food+classification', '_blank')">Ⓖ</span></td><td style='width:9%;cursor:pointer;'><span onclick="alternateInfo('madeof|f3')">3 Made of</span><span style='color:white;margin-left:6px;cursor:pointer;' onclick="alternateInfo('goog|f3')"> Ⓖ </span></td><td><span style='margin-right:8px;font-size:10px;color:white;cursor:pointer;'>AND/OR<input type='checkbox' id='andor' checked></span><span style='cursor:pointer;' onclick="alternateInfo('plus-words|f4')">4 <u>Plus-words</u></span><span style='color:white;cursor:pointer;margin-left:8px;' onclick="alternateInfo('goog|f25')">Ⓖ</span></td><td style='color:#FFEFA0;font-weight:bold;width:8%'>23 Quantity g<span style='margin-left:6px;color:white;cursor:pointer;' onclick="window.open('https://www.fao.org/4/u5900t/u5900t03.htm', '_blank')">Ⓖ</span></td><td style='width:7%'>24 Kc Total</td><td style='width:9%;'>22 Kc 100 g</td><td style='text-align:left;width:7%;color:yellow;'>19 Ca (mg)</td><td id='calculatefood' style='text-align:left;visibility:visible;'><button type='button' style='width:114px;margin-right:7px;color:blue;;background-color:yellow' onclick='calculate()'>Add to Food List</button></td>
	</tr>

<span id='kw1' style='display:none;'><?php echo exec("echo $(cat bd/menu/keywords.txt)"); ?></span>
<span id='kw2' style='display:none;'><?php echo exec("echo $(cat bd/menu/dbfiles.txt)"); ?></span>
<script>
kwords=''
function dbkeys(){

	kwords=''
	kwords=document.getElementById('kw1').innerHTML
	arrkwords=kwords.split(',')
	total=''
		for (i=0;i<arrkwords.length;i++) {
			total=total+'<span id="i'+i+'" style="cursor:pointer;" onclick="kW2(this.id)">'+arrkwords[i]+'</span>, '
		}
	document.getElementById('kw1').innerHTML=total

	kwords=document.getElementById('kw2').innerHTML
	arrkwords=kwords.split(':')

	total_=''

		for (j=0;j<arrkwords.length;j++) {
			total_=total_+'<span id="j'+j+'" style="cursor:pointer;" onclick="kW2_(this.id)"> '+arrkwords[j]+' </span>'
		}
	document.getElementById('kw2').innerHTML=total_
	}
dbkeys()

function alternateInfo(dId){goog=dId.split('|');if (goog[0] === 'goog'){window.open('https://www.google.com/search?q=' + encodeURIComponent(document.getElementById(goog[1]).innerHTML) + '&newwindow=1', '_blank');}else{document.getElementById('f4').innerHTML=document.getElementById(goog[0]).innerHTML;}}

function kW1(){
	document.getElementById('f4').innerHTML=total
	}
function kW2(keyw){
	document.getElementById('kw_1').innerHTML=document.getElementById(keyw).innerHTML
	messageRefresh()
	}
function kW1_(){
	document.getElementById('f4').innerHTML=total_
	}
function kW2_(keyw_){
	if (destinity === 0){
	document.getElementById('borrame1').innerHTML=document.getElementById(keyw_).innerHTML;
	document.getElementById('chooseSource').innerHTML=document.getElementById(keyw_).innerHTML;
	document.getElementById('f4').innerHTML='';
	}else{
	document.getElementById('db').innerHTML=document.getElementById(keyw_).innerHTML.trim()
	document.getElementById('borrame2').innerHTML=document.getElementById(keyw_).innerHTML.trim()
	document.getElementById('f4').innerHTML='';
	}
	messageRefresh()
}
</script>
<span id='f4bis' style='display:none'>[a-z]+</span>
	<tr>
		<td id='db' style='background-color:#83580B;text-align:center;font-size:12px;color:yellow;font-weight:bold;cursor:pointer;' contenteditable='true' onclick="destinity=1;kW1_()" onmouseout="document.getElementById('borrame2').innerHTML=document.getElementById(this.id).innerHTML;">Choose Target</td>


		<td id='f1' style='text-align:left;background-color:blue;color:yellow;' onclick='document.getElementById(this.id).innerHTML=""' contenteditable='true'><span style='color:white;font-weight:bold;'>Hello World!</span></td>
		<td id='f2' style='text-align:left;background-color:yellow' contenteditable='true' style='width:12%'>([0-9]{1,2}:[a-z]+)</td>
		<td id='f3' style='text-align:left;background-color:yellow' contenteditable='true'>([a-z]+(-[a-z]+)?)</td>
		<td id='f25' style='text-align:left;background-color:yellow;white-space:nowrap;overflow: hidden;' contenteditable='true' onclick="document.getElementById('f4').innerHTML=document.getElementById('f4bis').innerHTML;document.getElementById('f25').innerHTML=document.getElementById('f4bis').innerHTML;">[a-z]+</td>
		<td id='f23' onclick='document.getElementById(this.id).innerHTML=""' contenteditable=true>100</td>
		<td id='f24'>1600-3000</td>
		<td id='f22'></td>
		<td id='f19'>1300</td>
		<td style='background-color:#83580B;color:#FFEFA0;text-align:left;'></td>
	</tr>
<!--  onclick="document.getElementById('f4').innerHTML=document.getElementById(this.id).innerHTML;"-->
<script>
  // Get references to the input and output elements
  const outputCell = document.getElementById('f25');
  const inputCell = document.getElementById('f4');

  // Add an input event listener to the input cell
  inputCell.addEventListener('input', function () {
    // Update the content of the output cell with the input value
    outputCell.textContent = inputCell.textContent.slice(0, 46)+'...';
  });
</script>

	<tr class='alignLeft'>
	<td id='kw_1' style='text-align:center;font-size:12px;color:yellow;cursor:pointer' onclick="kW1()">Key Word</td><td><span style='cursor:pointer' onclick="window.open('https://www.nutrition.org.uk/healthy-sustainable-diets/protein/', '_blank')">5 Proteins (g)</span></td><td><span style='cursor:pointer' onclick="window.open('https://www.healthline.com/nutrition/12-healthy-high-carb-foods#TOC_TITLE_HDR_11', '_blank')">6 Carbo (g)</span></td><td><span style='cursor:pointer' onclick="window.open('https://www.helpguide.org/articles/healthy-eating/choosing-healthy-fats.htm', '_blank')">7 Fat (mg)</span></td><td style='color:#EC7063;'><span style='cursor:pointer' onclick="window.open('https://www.betterhealth.vic.gov.au/health/healthyliving/fats-and-oils', '_blank')">8 SatFat (mg)</span></td><td style='color:#EC7063;'><span style='cursor:pointer' onclick="window.open('https://hgic.clemson.edu/factsheet/food-labels-fat-cholesterol/', '_blank')">9 Cholest. (mg)</span></td><td style='color:#EC7063;'>10 ClNa (g)</td><td style='color:#EC7063;'>11 Alcohol (g)</td><td style='color:yellow;'>20 Fe (mg)</td>
	<td><!--<button type='button' style='width:110px;margin-right:7px;color:blue;;background-color:yellow' onclick="searchdb('delete')">Delete in DB</button>--></td></tr>
	<tr>
	<td style='background-color:#83580B;text-align:center;color:white;'></td>
	<td id='f5'>50 (10-35% kc)</td>
	<td id='f6'>275 g (45-65% Kc)</td>
	<td id='f7'>78 g (<30% Kc)</td>
	<td id='f8'>20 g/24H (sat+trans <11% Kc)</td>
	<td id='f9'>300</td>
	<td id='f10'><5</td>
	<td id='f11'>0</td>
	<td id='f20'>18</td>
	<td style='background-color:#83580B;text-align:left;color:white;text-align:left;'></td>
	</tr>
	<tr class='alignLeft'>
	<td style='text-align:center;cursor:pointer;'></td><td>12 Fiber (g)</td><td>13 Omegas (g)</td><td>14 Vit A (RAE)</td><td>15 Vit B (mg)</td><td>16 Vit C (mg)</td><td>17 Vit D (µg)</td><td>18 Vit E (alfa-TE) </td><td style='color:yellow;'>21 K (mg)</td><td style='font-size:12px;'><button type='button' style='width:130px;color:blue;;background-color:yellow' onclick="searchdb('replace')">Replace/OffSide</button></td>
	</tr>
	<tr>
	<td style='background-color:#83580B;text-align:center;'></td>
	<td id='f12'>28-35</td>
	<td id='f13'>0.25-0.5</td>
	<td id='f14'>900</td>
	<td id='f15'>15</td>
	<td id='f16'>90</td>
	<td id='f17'>20</td>
	<td id='f18'>15</td>
	<td id='f21'>not <4700</td>
	<td style='background-color:#83580B;text-align:left;'></td>
	</tr>
	<tr>
	<td id='freeLoad' style='background-color:navy;text-align:justify;color:white;' colspan='9' onclick="toClipboard(this.id)" contenteditable='true'>Free Load (Raw Record)</td>
	</tr>
	<tr>
	<td id='ff' style='background-color:black;text-align:justify;color:white;' colspan='9'>Reg No|Group:Subgroup|Made of|dbname|url|dev team|source owner|sort num|source id|Plus-words10|Water|Energy12|Fat13|SatFa14|TransFa|Ome-3_16|Ome-617|Chol18|HC|Starch|Mono+Di|Sugar|Fib23|Prot24|Salt25|Alcohol26|A27|Retinol|B-carotene|D30|E31|B1|B2|Niacin|B6|Folate|B12|C38|Ca39|Fe40|Na41|K42|Mg|Zn|Se|Cu|P|I</td>
	</tr>
</table>
<script>
function toClipboard(freeId){
	navigator.clipboard.readText()
	.then(function (clipboardContent){
	document.getElementById(freeId).innerHTML = clipboardContent;
	//clipBoardContent must have n '|'
	var pipeOccurrences = clipboardContent.split('|').length;

	if (pipeOccurrences !== 48){alert('The strip is malformed: '+pipeOccurrences+ '. Not 48 fields.');return;}

	arrRegOneByOne=clipboardContent.split('|')
	document.getElementById('f1').innerHTML=arrRegOneByOne[0];//reg
	document.getElementById('f2').innerHTML=arrRegOneByOne[1];//gs
	document.getElementById('f3').innerHTML=arrRegOneByOne[2];//made
	document.getElementById('f25').innerHTML=arrRegOneByOne[9].substring(0, 42)+' ...';
		document.getElementById('f4').innerHTML=arrRegOneByOne[9];document.getElementById('f4bis').innerHTML=arrRegOneByOne[9];//description
	document.getElementById('f5').innerHTML=arrRegOneByOne[23];//proteins
	document.getElementById('f6').innerHTML=arrRegOneByOne[18];//carbo
	document.getElementById('f7').innerHTML=arrRegOneByOne[12];//fat
	document.getElementById('f8').innerHTML=arrRegOneByOne[13];//satfat
	document.getElementById('f9').innerHTML=arrRegOneByOne[17];//cholesterol
	document.getElementById('f10').innerHTML=arrRegOneByOne[24];//salt
	document.getElementById('f11').innerHTML=arrRegOneByOne[25];//alcohol
	document.getElementById('f12').innerHTML=arrRegOneByOne[22];//fiber

	if (arrRegOneByOne[15] === ''){arrRegOneByOne[15]=0}
	if (arrRegOneByOne[16] === ''){arrRegOneByOne[16]=0}
	omegas=arrRegOneByOne[15]*1 + arrRegOneByOne[16]*1
	document.getElementById('f13').innerHTML=omegas.toFixed(2);//omegas

	document.getElementById('f14').innerHTML=arrRegOneByOne[26];//Vit A

	if (arrRegOneByOne[31] === ''){arrRegOneByOne[31]=0}
	if (arrRegOneByOne[32] === ''){arrRegOneByOne[32]=0}
	if (arrRegOneByOne[33] === ''){arrRegOneByOne[33]=0}
	if (arrRegOneByOne[34] === ''){arrRegOneByOne[34]=0}
	if (arrRegOneByOne[35] === ''){arrRegOneByOne[35]=0}
	if (arrRegOneByOne[36] === ''){arrRegOneByOne[36]=0}
	vitB=arrRegOneByOne[31]*1 + arrRegOneByOne[32]*1 + arrRegOneByOne[33]*1 + arrRegOneByOne[34]*1 + arrRegOneByOne[35]*1 + arrRegOneByOne[36]*1
	document.getElementById('f15').innerHTML=vitB.toFixed(2);//vitB

	document.getElementById('f16').innerHTML=arrRegOneByOne[37];//VitC
	document.getElementById('f17').innerHTML=arrRegOneByOne[29];//VitD
	document.getElementById('f18').innerHTML=arrRegOneByOne[30];//VitE
	document.getElementById('f19').innerHTML=arrRegOneByOne[38];//Ca
	document.getElementById('f20').innerHTML=arrRegOneByOne[39];//Fe
	document.getElementById('f21').innerHTML=arrRegOneByOne[41];//K
	document.getElementById('f22').innerHTML=arrRegOneByOne[11];//Kc
	});
	}
</script>
	<div id='ff' style='margin:0 30px 0 8px;background-color:black;color:white;text-align:left;font-size:11px;'></div>
	<div id='phrases1' style='width:89.8%;margin:0 30px 0 8px;background-color:white;color:blue;text-align:left;font-size:11px;'>Messages</div>



<label id='menu'></label>
<table style='font-weight:bold;'>
	<tr><td class='txtAlignCenter' colspan='7' style='padding-right:25px;color:lightblue;'><br>__Food Menu__</i><br></td></tr>
	<tr><td class='txtAlignLeft' colspan='7'><br>Step 1: <span style='color:white;'><i>Click on one below</i></span><br></td></tr>
	<tr><td id='t1'><span class='cursor' onclick="ShowHideMenu('1');">1:Dairy&Analogues</span><input type='checkbox' name='group' id='g_1'></td><td id='t4'><span class='cursor' onclick="ShowHideMenu('4')">4:Dry grains</span><input type='checkbox' name='group' id='g_4'></td><td id='t7'><span class='cursor' onclick="ShowHideMenu('7')">7:Flours&Pasta</span><input type='checkbox' name='group' id='g_7'></td><td id='t10'><span class='cursor' onclick="ShowHideMenu('10')">10:Finfish</span><input type='checkbox' name='group' id='g_10'></td><td id='t13'><span class='cursor' onclick="ShowHideMenu('13')">13:Seeds&Nuts</span><input type='checkbox' name='group' id='g_13'></td><td id='t16'><span class='cursor' onclick="ShowHideMenu('16')">16:Viscera&Sausages</span><input type='checkbox' name='group' id='g_16'></td><td id='t19'><span class='cursor' onclick="ShowHideMenu('19')">19:Pendings</span><input type='checkbox' name='group' id='g_19'></td></tr>

	<tr><td id='t2'><span class='cursor' onclick="ShowHideMenu('2')">2:Eggs</span><input type='checkbox' name='group' id='g_2'></td><td id='t5'><span class='cursor' onclick="ShowHideMenu('5')">5:Vegetables&Mushrooms</span><input type='checkbox' name='group' id='g_5'></td><td id='t8'><span class='cursor' onclick="ShowHideMenu('8')">8:Meat</span><input type='checkbox' name='group' id='g_8'></td><td id='t11'><span class='cursor' onclick="ShowHideMenu('11')">11:Shellfish</span><input type='checkbox' name='group' id='g_11'></td><td id='t14'><span class='cursor' onclick="ShowHideMenu('14')">14:Water&Drinks</span><input type='checkbox' name='group' id='g_14'></td><td id='t17'><span class='cursor' onclick="ShowHideMenu('17')">17:Soups&Sauces</span><input type='checkbox' name='group' id='g_17'></td><td id='t20'></span></td></tr>
	<tr><td id='t3'><span class='cursor' onclick="ShowHideMenu('3')">3:Fruits</span><input type='checkbox' name='group' id='g_3'></td><td id='t6'><span class='cursor' onclick="ShowHideMenu('6')">6:Starchy roots&Tubers</span><input type='checkbox' name='group' id='g_6'></td><td id='t9'><span class='cursor' onclick="ShowHideMenu('9')">9:Poultry</span><input type='checkbox' name='group' id='g_9'></td><td id='t12'><span class='cursor' onclick="ShowHideMenu('12')">12:Oil&Fats</span><input type='checkbox' name='group' id='g_12'></td><td id='t15'><span class='cursor' onclick="ShowHideMenu('15')">15:Spices&Herbs</span><input type='checkbox' name='group' id='g_15'></td><td id='t18'><span class='cursor' onclick="ShowHideMenu('18')">18:Baby&Formula</span><input type='checkbox' name='group' id='g_18'></td><td id='t21'><span class='cursor'></span></td></tr>
	<tr>
		<td id='step2' colspan='11'>Step 2: <i style='color:white'>Click on one below</i>
		<div class='menu' id='1'> <?php echo exec("echo $(cat bd/menu/menu1)"); ?></div>
		<div class='step2' id='2'> <?php echo exec("echo $(cat bd/menu/menu2)"); ?> </div>
		<div class='stepX' id='3'> <?php echo exec("echo $(cat bd/menu/menu3)"); ?> </div>
		<div class='stepX' id='4'> <?php echo exec("echo $(cat bd/menu/menu4)"); ?> </div>
		<div class='stepX' id='5'> <?php echo exec("echo $(cat bd/menu/menu5)"); ?> </div>
		<div class='stepX' id='6'> <?php echo exec("echo $(cat bd/menu/menu6)"); ?> </div>
		<div class='stepX' id='7'> <?php echo exec("echo $(cat bd/menu/menu7)"); ?> </div>
		<div class='stepX' id='8'> <?php echo exec("echo $(cat bd/menu/menu8)"); ?> </div>
		<div class='stepX' id='9'> <?php echo exec("echo $(cat bd/menu/menu9)"); ?> </div>
		<div class='stepX' id='10'> <?php echo exec("echo $(cat bd/menu/menu10)"); ?> </div>
		<div class='stepX' id='11'> <?php echo exec("echo $(cat bd/menu/menu11)"); ?> </div>
		<div class='stepX' id='12'> <?php echo exec("echo $(cat bd/menu/menu12)"); ?> </div>
		<div class='stepX' id='13'> <?php echo exec("echo $(cat bd/menu/menu13)"); ?> </div>
		<div class='stepX' id='14'> <?php echo exec("echo $(cat bd/menu/menu14)"); ?> </div>
		<div class='stepX' id='15'> <?php echo exec("echo $(cat bd/menu/menu15)"); ?> </div>
		<div class='stepX' id='16'> <?php echo exec("echo $(cat bd/menu/menu16)"); ?> </div>
		<div class='stepX' id='17'> <?php echo exec("echo $(cat bd/menu/menu17)"); ?> </div>
		<div class='stepX' id='18'> <?php echo exec("echo $(cat bd/menu/menu18)"); ?> </div>
		<div class='stepX' id='19'> <?php echo exec("echo $(cat bd/menu/menu19)"); ?> </div>
		</td>
	</tr>
	<tr>
	<td class='td11' colspan='11'>
	<div id='step3'>Step 3: <span style='color:white'><i>Click on one below</i></span></div>
	<div id='resultsMenu'></div>
	<div id='regLines'></div>
	</td>
	</tr>
	<tr>
	<td class='td11' colspan='11'>
	<div id='step4'>Step 4: <span style='color:white'><i>Click a highlighted registration number (in yellow) from 'Step 3' above to add your data to the 'Nutrient Grid.' Click 'Add to Food List.' Before 'Calculate Totals,' complete all ingredients once. Refer to the tutorial on this page.</div>
	</td>
	</tr>
</table>


<div id='bSearch' style='font-weight:bold;margin:10px 0 0 20px;display:none;cursor:pointer;text-shadow: 2px 2px 4px rgba(0, 0, 255, 0.8);' onclick="displayNextLines(return_data)">Menu: Display+</span></div>
<div id='results' style='margin:10px 0px 10px 10px;width:100%;'></div>

<label id='list'/>
<div style='width:98%;padding-right:55px;text-align:center;color:lightblue;font-weight:bold;margin-top:10px;'>__Food List__</div>
</label>

<script>
function tb1Tb2(){
	if (document.getElementById('tb1').style.display == 'none'){
	document.getElementById('tb1').style.display='block';document.getElementById('tb2').style.display='none';

	}else{document.getElementById('tb1').style.display='none';document.getElementById('tb2').style.display='block';}
	}
</script>

<div style='margin:0 0 5px 5px;'><span style='cursor:pointer;font-size:12px;color:yellow;border-style: solid;border-color:white;border-width: 0.21px;border-radius: 5px;padding: 1px 5px 1px 5px;text-align:center;' onclick="tb1Tb2()">Switch to show Create-Recipe/Export-Inport</span><a style="margin:0 0 10px 10px;color:gold;cursor:pointer;font-size:12px;color:yellow;border-style: solid;border-color:white;border-width: 0.21px;border-radius: 5px;padding: 1px 5px 1px 5px;text-align:center;margin-right:10px;" href="bd/bdFiles.txt" target="_blank" >DB Files</a><span style='background-color:white;color:black;width:10px' id='impExpMess'></span></div>

<div id="tb1" style='width:100%;display:block;margin-left:5px;display:block;'  >
	<table style='width:100%;background-color:blue;'>
		<tr style='width:100%;'>
			<td style='width:25%;padding:4px 0 4px 0;bachground-color:red;'>Recipe title (Create Recipe)</td>
			<td style='width:25%;'>Collection (.db) -F3 (Create Recipe)</td>
			<td style='width:50%;'><span style='width:250px;margin-left:20px;cursor:pointer;font-size:12px;color:yellow;border-style: solid;border-color:white;border-width: 0.21px;border-radius: 5px;padding: 1px 5px 1px 5px;text-align:center;' onclick="document.getElementById('editableRecipe').value='';document.getElementById('expt').value='';">Reset Textareas</span></td>
		</tr>
		<tr style='color:olive;'>
			<td style='width:25%;background-color:white;padding:4px 0 4px 0;' id='recipeTitle' contenteditable='true'></td>
			<td style='width:25%;background-color:white;' id='mainFoods' contenteditable='true'></td>
			<td><span style='width:250px;margin-left:20px;cursor:pointer;font-size:12px;color:yellow;border-style: solid;border-color:white;border-width: 0.21px;border-radius: 5px;padding: 1px 5px 1px 5px;text-align:center;' onclick='calcRecipe()'>Calculate Recipe Totals</span><span style='color:white;margin:0 10px 0 10px;'>==></span><span style='width:250px;cursor:pointer;font-size:12px;color:yellow;border-style: solid;border-color:white;border-width: 0.21px;border-radius: 5px;padding: 1px 5px 1px 5px;margin-right:20px;text-align:center;' onclick="saveRecipe();document.getElementById('editableRecipe').value='';document.getElementById('expt').value='';">Create Recipe</span><span style='display:none;' id='recipeFilename'></span></td>
		</tr>
		<tr>
			<td colspan='3'>
				<textarea id='editableRecipe' style='width:98.2%'></textarea><span id='messageEnd'></span>
			</td>

		</tr>
	</table>
</div>


<div id="tb2" style='width:100%;margin-left:5px;text-align:left;display:none;background-color:red;display:none;'>

	<table style='width:100%;background-color:blue;'>
		<tr style='width:100%'>
			<td style='width:15%;cursor:pointer;padding-left:5px;'>Filename</td>
			<td style='width:85%;cursor:pointer;color:yellow;padding-left:5px;' colspan="2"><input type='checkbox' id='expImp' checked>Imp/Exp (<span style="color:white;">uncheck for exporting and deleting the "Filename" file set</span>)  </span></td>

		</tr>

		<tr style='width:100%;color:olive;'>
			<td style='width:15%;background-color:white;padding-left:5px;' id='impFile' onclick="document.getElementById(this.id).innerHTML='';" contenteditable='true'></td>
			<td style='' id=''><input type='button' style='color:olive;' onclick="imprtExprt();" value='Export-Import'></td>
			<td style=''></td>
		</tr>

			<tr>
				<td colspan='3'>
					<textarea id='expt' style='width:99%;height:180px;padding: 0px 0 0 10px;'></textarea>
				</td>
			</tr>
		</table>
</div>
<br>
<style>
  .table-container {
    text-align: left;
padding-left:5px;
width:100%;
  }
</style>
<div class="table-container">
<table align="left" style='width:100%;'>
<tr><td colspan='2'><div style='margin: 0px 0px 3px 0px;'>Bash Box: <span style='cursor:pointer;font-size:12px;color:yellow;border-style: solid;border-color:white;border-width: 0.21px;border-radius: 5px;padding: 1px 5px 1px 5px;margin-right:20px;' onclick='bashcom()'> Execute </span></div></td>
</tr>
<tr><td style="width:11%;background-color:black;">~/www/recetas/scripts =></td><td id='command' style='max-height:20px;overflow:hidden;background-color:black;font-size:14px;color:yellow;' contenteditable='true'> grep -Ei "(goat|sheep)" "../bd/work.csv"</td></tr>
</table>
</div>
<table style='width:100%'></table>
<script>
function decodeHtmlEntities(html) {
	var txt = document.createElement("textarea");
	txt.innerHTML = html;
	return txt.value;
	}

function bashcom(){
    var hr = new XMLHttpRequest();
    var url = "scripts/bashcom.php";
	command=document.getElementById('command').innerHTML
	var data = encodeURIComponent(command);

    var fn = "\'"+data+"\'";
    	var vars = "group="+fn;
	alert(vars)
    	hr.open("POST", url, true);
   		hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    	hr.onreadystatechange = function() {
	    	if(hr.readyState == 4 && hr.status == 200) {
		    var return_data = hr.responseText;
			document.getElementById("rBashcom").innerHTML = return_data;
	alert('return_data: '+return_data)
	    	}
    	}
    hr.send(vars);
	alert('vars waiting')
    document.getElementById("rBashcom").innerHTML = "processing...";
	}

function imprtExprt(){

	//send data 2: vale?:   wweia-2-AlcoholicBeverages.cvs#wweia-3-AlcoholicBeverages.txt#1262304073|1:cheese|cow|100|0|0|0|73|01.261|Cheese, blue mold, Gorgonzola|49|359|31.2|20.3|0.6|0.17|0.57|87|0.1|0|0.1|0|0|19.4|3.6|0|350|336|168|0|0|0.01|0.18|0.9|0.07|52|1.2|0|612|0.3|1450|138|18|2.5|7|0.02|356|12_wweia-2-AlcoholicBeverages.cvs#wweia-3-AlcoholicBeverages.txt#1262304073|1:cheese|cow|100|100|0|0|73|01.261|Cheese, blue mold, Gorgonzola|49|359|31.2|20.3|0.6|0.17|0.57|87|0.1|0|0.1|0|0|19.4|3.6|0|350|336|168|0|0|0.01|0.18|0.9|0.07|52|1.2|0|612|0.3|1450|138|18|2.5|7|0.02|356|12_
	data=''
	document.getElementById("impExpMess").innerHTML = ''
//get data items
	exportTextArea=document.getElementById('expt').value.slice(0, -1)
    expImp=document.getElementById('expImp').checked
	impFile=document.getElementById('impFile').innerHTML
	if (impFile.includes('*')){document.getElementById("impExpMess").innerHTML = "<span style='background-color:blue;color:white'><b>Arterisk is not allowed. Exit.</b></span>";return;}
	source=exportTextArea.split('#')[0].trim();
	target=exportTextArea.split('#')[1];
	chooseSource=document.getElementById("chooseSource").innerHTML.trim()
	chooseTarget = document.getElementById("db").textContent.trim();
	//union=chooseSource+chooseTarget


alert(expImp)
if ( expImp === true ){
				//Import => source=import.csv, target=
			document.getElementById('expt').value = ''
			document.getElementById("chooseSource").innerHTML='import.csv'
			document.getElementById('borrame1').innerHTML='import.csv'
			chooseSource='import.csv'
			if ( chooseTarget === 'shareDBset.csv' ){
			alert('Import to shareDBset.csv')
			}
			else
			{
			alert('Import: Target regexp')
				var regexT = /^[A-Za-z][A-Za-z0-9]+-[1-9]+-[A-Za-z0-9]+\.(csv|txt)$/;
				alert(chooseTarget+', '+chooseSource)
					if (!regexT.test(chooseTarget)) {alert('Import: Target file name must be the shareDBset.csv file or a collection DB file');exit}
			}
data=impFile+'#'+expImp+'#'+chooseSource+'#'+chooseTarget
alert(data)
}
else
{
alert(expImp)
alert('Export')
alert(data)
			document.getElementById('expt').value = ''
			document.getElementById("chooseSource").innerHTML='export.csv'
			document.getElementById('borrame1').innerHTML='export.csv'
			chooseSource='export.csv'
		//var regexS = /^[A-Za-z][A-Za-z0-9]+-[1-9]+-[A-Za-z0-9]+\.csv$/;
		var regexT = /^[A-Za-z][A-Za-z0-9]+-[1-9]+-[A-Za-z0-9]+\.(csv|txt)$/;

if (!regexT.test(chooseTarget)) {alert('Export: not ok');Exit}

	//export arreglar su FILTRO JAVASCRIPT if (!regexT.test(chooseTarget) || !regexS.test(chooseSource)) {alert('no es regexp');exit}
	alert(exportTextArea+','+source+','+target+',')
	let str = exportTextArea;
	str = str.slice(0, -1);
	const parts = str.split('_');

	// Define the regex pattern for matching the second element
	const regexPattern = /^[A-Za-z0-9]+-[1-9]+-[A-Za-z0-9]+\.(csv|txt)$/;

	for (let i = 0; i < parts.length; i++) {
		// Split each part by '#'
		const elements = parts[i].split('#');
//alert(elements[1])
			// Check if the second element matches the pattern or is 'import.csv'
			if (!regexPattern.test(elements[1]) && elements[1] !== 'import.csv')
			{
				if (elements[1] === undefined) {
					// Do something if 'undefined'
					alert('The variable is undefined');
				document.getElementById("impExpMess").innerHTML = "Export: Food List to export is empty. Exit."
				return; // Exit the loop
				}
				document.getElementById("impExpMess").innerHTML = "Export: Invalid format: '"+elements[1]+"' or empty field. Exit."
				return; // Exit the loop
			}
	}
data=impFile+'#'+expImp+'#'+exportTextArea

}

//if ( exportTextArea.trim() === '' ) {data=impFile+'#'+expImp+'#'+chooseSource+'#'+chooseTarget}else{data=impFile+'#'+expImp+'#'+exportTextArea}


    var hr = new XMLHttpRequest();var url = "scripts/imprtExprt.php";0
	//var data = impFile.innerHTML	//encodeURIComponent(impFile);
        var fn = "\'"+data+"\'";var vars = "group="+fn;
            hr.open("POST", url, true);
            hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            hr.onreadystatechange = function() {
                if(hr.readyState == 4 && hr.status == 200) {
                var return_data = hr.responseText;
                document.getElementById("impExpMess").innerHTML = return_data;
                }
            }
hr.send(vars);
document.getElementById("impExpMess").innerHTML = "processing...";
}


</script>
<div style="color:goldenrod;width:100%;margin:5px 0 5px 20px;">Thanks to the courtesy of Norwegian Directorate of Health and University of Oslo (Norwegian Food Safety Authority).<br>Warning!: Data is guaranteed only at <a href="http://www.mattilsynet.no" target="_blank" style="color:white">Norwegian Food Composition Database</a> view. <a href="https://www.matportalen.no/verktoy/the_norwegian_food_composition_table/the_norwegian_food_composition_table-1" target="_blank" style="color:white">DB Update</a> page)</div><br>
</div>
<div id='rBashcom'>gghj</div>
<br><br>
<div style='font-size:12px;color:#FFEFA0;cursor:pointer;' onclick="showHide('comenzar')">⇅ <b>Comenzar</b></div>
<div id='comenzar' style='width:100%;float:left;padding-left:20px;text-align:justify;display:none'><br>

To start a new recipe, click 'New Recipe' (mesa/mesa.php) and create a draft (draft new tab). The draft page includes measurement charts, translatable by Google Translate. Copy the 'Ingredients' and 'Preparation' steps from an internet recipe to save time. To calculate the nutrient composition of each food and the total dish, use the by-steps menu or the search utility (it only searchs for regs) on the 'mesa/mesa.php' page.<br><br>

The 'recipes/recipes.php' page provides food names in English when translated with Google Translate. Use the 'mesa/mesa.php' menu to find the food and click on its identification number (in yellow). Enter the amount in the 'Quantity g' box and click 'Calculate Food' in the upper right corner. Add all the foods to the 'Editable Recipe' box and click 'Calculate Totals' to calculate the full recipe. Results are displayed in the top form.<br><br>

To create a recipe, fill in 'Recipe Title' and 'Main Food', then click the 'HTML Recipe' button. Copy the 'Preparation' section from the draft that 'New Recipe' provided and paste it into the final page. Ensure it has at least 'Step 1' step—'... brevity is the soul of wit,...' (Shakespeare). Fill in the missing fields: 'Image', 'Url', 'Group', 'Subgroup', and 'Preparation (+pre_cooking)'. Click 'Share HTML' to generate a page that you can save or share;it can always load data in chef.php (recipes tab), read 'Tutorial' for helpful details. At this point, it is safe to close the draft page tab.<br><br>

To search for recipes, use the 'Clear to search' button and fill in all boxes except 'Preparation'. Press 'Search Recipe' to perform the search. Click on the 'id' of the registries to view the recipes. To return to the original situation, press 'Restart'. Use the 'Share HTML' button to copy a recipe to an HTML page and send it to the 'Pending Recipes' file. The 'Search Recipe' utility can be tricky, but the 'Tutorial' fixes this issue.<br><br>

To add a recipe to the database, click the 'Head Chef' button on the 'Share HTML' page. This loads the 'mesa/chef/chef.php' page with the recipe. Click the 'Save Rec-DB' button to add it to the database and validate it. Doing so removes the recipe from the 'Pending Recipes' list. 'Pending Recipes' lists the recipes awaiting validation and allows the chef to add or delete them from the database.<br><br>

To export registries from the 'mesa/bd/work.csv' database, click the 'Export Regs' button. First, display the registries in the 'Editable Recipe' using the menu (pending script implementation for search 1234), enter 100 (this is essential) as the quantity in the 'Quantity g' box, and press 'Calculate recipe' to each registry. Once all the desired records are in the 'Editable Recipe' box, press 'Export Records'. This triggers the exportRec() function in mesa.php, which passes the record IDs to the ajaxToExport(sendToExportScr) function and sends them to the PHPtoExportScr.php script for processing.<br><br>

The PHP script uses $_POST['forScrS1="sendToExportScr"'] to pass data to the bash script 'mesa/scripts/mesaSearch.scr'. The grep command matches the records in the work.csv database, adding them to the 'mesa/importExport/toExport' file if there is a match. The Chef (chef.php) can load these registries by clicking 'Load Lists', and they will appear in the 'To Export' header, where they can be modified or deleted.<br><br>

Refer to the 'Tutorial' located at 'tabla/tutorial/tutorial.html' for further information.
</div>
<br><br><br>

<span id='arrayElemMatch'></span><br>
<div style='font-size:12px;color:#FFEFA0;cursor:pointer;' onclick="showHide('temp')">⇅ <b>Temp</b></div>

<br><br>
<div id='temp' style='width:100%;float:left;display:none'><br><br>
resolution bash<br>
cat /sys/class/graphics/*/virtual_size|cut -d',' -f1
<br><br><br>
arrayElemMatch global variable contains the actual reg of the form<br>
<span id='arrayElemMatch'></span><br>
<br>

<!--The following commented is OK, results will be not echoed and shown by the page-->
<!--<?php echo exec("./scripts/menu.scr"); ?>-->

<button onclick="loadDocument()">DB Update</button>
<div style='color:#FFEFA0;font-weight:bold;padding-left:20px;' id='message'></div>
<div id='myDiv'></div>
<button onclick='array()'>Array</button>

<p style='text-align:center;color:#FFEFA0;padding-top:8px;'><br><b></b><br>https://www.healthline.com/health/balanced-diet#calories<br>https://www.ncbi.nlm.nih.gov/books/NBK56068/table/summarytables.t5/?report=objectonly<br>https://www.ncbi.nlm.nih.gov/books/NBK56068/table/summarytables.t4/?report=objectonly<br>https://www.ncbi.nlm.nih.gov/books/NBK56068/table/summarytables.t2/?report=objectonly<br>https://www.ncbi.nlm.nih.gov/books/NBK545442/table/appJ_tab3/?report=objectonly<br>tolerable vit https://www.ncbi.nlm.nih.gov/books/NBK56068/table/summarytables.t7/?report=objectonly<br>tolerable minerals https://www.ncbi.nlm.nih.gov/books/NBK545442/table/appJ_tab9/?report=objectonly<br>other https://www.myfooddata.com/articles/recommended-daily-intakes.php</p><br>


grep -i "|2:.*" work.csv | cut -d'|' -f2 | cut -d':' -f2 > menu/menu2<br>
tr -s [:space:] \\n < menu/menu2 | sort | uniq > menu/tmp<br>
cat menu/tmp | grep "\S" > menu/menu2<br>
grep -i "|2:.*" work.csv | cut -d'|' -f3 |grep "\S"  > menu/menu2_<br>
tr -s [:space:] \\n < menu/menu2_ | sort | uniq > menu/tmp<br>
cat menu/tmp | grep "\S" > menu/menu2_<br><br>

buscar<br>
#el primer campo es dado por menú<br>
#en el segundo campo inserta 'cow' y el comando busca en cualquier columna<br>
&nbsp&nbsp&nbsp	grep -i "1:cheese|.*cow" work.csv<br>
&nbsp&nbsp&nbsp	grep -i "1:cheese|.*goat" work.csv<br>
&nbsp&nbsp&nbsp	grep -i "1:cheese|.*milk" work.csv #sólo en el camp 10<br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp#especificar otro término en el tercer campo (no en orden de aparición)<br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp	grep -i "1:cheese|.*cow" work.csv | grep -i "goat"<br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp grep -i "1:cheese|.*" work.csv | grep -i "goat" #en caso de campo 3 vacío busca en el resto<br><br>
#no,2º,3º<br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp	grep -i "^.*|1:cheese|goat|" work.csv<br>
#no,2º,3º,10º y resto<br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp	grep -i "^.*|1:cheese|goat|*white*|" work.csv<br>
#si,no<br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp	grep -i "^15|" work.csv<br><br><br>
ORDENAR LOS CAMPOS del formulario para la base de datos<br>
si son iguales (match) o el campo Reg. No. es igual y no es timestamp debe hacerlo manualmente el usuario, en cualquier caso enviar mensaje (La aplicación no está autorizada por programación a sobreescribir registros de la base de datos si son originales). De lo contrario añadir al final con timestamp como nº reg.
<br>
Para mesa SAVE TO DATABASE y para recipes SAVE RECIPE<br>
(si grep match)<br>
con grep coger el nº linea que match => num=$(grep --line-number "ipsum" pru  | cut -f1 -d:) (si no match da vacío y añado al final del archivo)<br>
tomo el campo 1: <br>
si no es timestamp enviar mensaje<br>
si ES timestamp substituir con sed -i $num"s/$tobereplaced/$replacedby/" pru<br>
(si grep no match da vacío y añado al final del archivo)
<br><br>
para Search MOSTRAR RESULTADOS<br><br>
num=$(grep --line-number "ipsum" pru  | cut -f1 -d:);tobereplaced='ipsum';replacedby='repla';sed -i $num"s/$tobereplaced/$replacedby/" pru<br>
sed -i 's/search_string/replace_string/' filename<br><br>
# Check the command line argument value exists or not<br>
if [ $1 != "" ]; then<br>
  # Search all string containing digits and add $<br>
  sed -i 's/\b[0-9]\{5\}\b/$&/g' $1<br>
fi<br><br>
<br><br>
#Al pulsar sobre un 'subg.' 1. javascript completa el campo 'Group:subg.', toma el valor del campo 'Group:subg.', lo envía a PHP que 2. ejecuta el script bash que 3. busca en la columan 'Made of' (grep -i "4:pulses|.*" work.csv | cut -d'|' -f3 | sort | uniq | grep "\S" > tmp), y formatea para la página, 4. el PHP entrega a javascript el 'tmp' y muestra el resultado en la página.<br>
grep -i "4:pulses|.*" work.csv | cut -d'|' -f3 | sort | uniq | grep "\S"<br><br>
	<br><br>
	elimina letras [a-zA-Z]<br>
		MYVAR=ho02123ware38384you443d34o3434ingtod38384day;MYVAR=${MYVAR//[a-zA-Z]/" "};echo $MYVAR <br>
	elimina cifras [0-9]
		MYVAR=ho02123ware38384you443d34o3434ingtod38384day;MYVAR=${MYVAR//[0-9]/" "};echo $MYVAR<br>
	combina<br>
		varA='ho';varB='you';MYVAR=ho02123ware38384you443d34o3434ingtod38384day;echo $MYVAR | sed "s/$varA\|$varB\|[0-9]/ xxx /g"<br>
	varA='[,.?]\|with\|no added sugar\|hard\organic\|Norwegia\|Parmesan\|rich\|matured\|from\|and\|prepared\|low-fat\|instant\|powder\|wholemeal\|months\|Nestl\|Semper\|in\|jars\|replacement\|base\|gril\|sausage\|VegMe\|dairy\|reduced fat\|sugar\|content\|prote\|textured\|vegetarian\|home-made\|Flow\|Food\|vegan\|Go\|balls\|salad\|Plantego\|Santa\|Maria\|Maarud\|fat\|reduced\|fried\|roasted\|salted\|ttefabrikken\|lille\|Den\|Eldorado\|Polly\|oriental\|dishes\|extruded\|Piano\|flavour\|whole\|cube\|soup\|etc\|leek\|green\|out\|style\|Italian\|Mexican\|Oriental\|Pasta\|di\|Napol\|no\|meat\|shell\|dustrially\|made\|35\|vol-\|alcohol\|sweet\|21\|vol-\|alcohol\|40\|vol-\|alcohol\|40\|vol-\|alcohol60\|vol-\|alcohol\|spark\|sweet\|extra\|ready to\|k\|dr\|fol\|Sm\|[0-9]\|holle\|hippdishes\|mil\|Bergens\|Vitaplex\|Collett\|%\|El\|Paso\|Old\|Nycoplus\|Nycoplus\|ened\|mi\|stu\|SanasolFlora\|x\|canned\|lightcompressed\|active\|gre\|ents\|Naturli\|ets\|nced\|tah\|i\|man\|vegetar\|hjerte\|Vita\|Tarte\|Ratatouille\|compressed\|desiccated\|Flora\|Sanasol\|nerals\|Multi\|Vita\|Hoff\|air\|poppedcrowaved\|Lollipop\|g\|Size\|rone-is\|cone';cat bd.csv |cut -d'|' -f9 | sed -e "s/$varA/ /gI"<br><br>
	https://www.cs.odu.edu/~zeil/cs252/latest/Public/regexp/index.html
	<br>«»—<br><br>
	Nota: Cada vez que se exporta desde la Hoja de Cálculo a formato 'csv' LibreOffice introduce text 'raro'. Se corrige así: iconv -f latin1 -t utf8 bd.csv | tr '\r' '\n' > bd_mended.txt Luego se reescribe bd.csv así: cat bd_mended.txt > bd.csv<br><br><br>
	<div style='color:#FFEFA0;margin-bottom:10px;'>Step 1º: Select one Group</div>
	<div style='width:100%;'>
	<table style='width:100%;'>
	<tr><td>I Milk&Derivatives</td><td>IV Cereals&Legume Grains</td><td>VII Flours&Pasta</td><td>X Finfish</td><td>XIII Seeds&Nuts</td><td>XVI Viscera&Blood</td><td>XIX Magic Food</td></tr>
	<tr><td>II Eggs</td><td>V Vegetables&Mushrooms</td><td>VIII Meat</td><td>XI Shellfish</td><td>XIV Water&Drinks</td><td>XVII Soups&Sauces</td><td></td></tr>

	<tr><td>III Fruits</td><td>VI Starchy roots&Tubers</td><td onclick=''>IX Poultry</td><td>XII Oil&Fats</td><td>XV Spices&Herbs</td><td>XVIII  Baby&Formula</td><td></td></tr>
	<tr><td style='padding-top:10px;color:#FFEFA0;' colspan='6'>Step 2º: Select one Subgroup</td></tr>

	<tr><td style='padding-top:10px;' colspan='6'><span  onclick=''>Chicken</span>, <span  onclick=''>Hen</span>, Turkey, Duck, Goose, Other (1) ... After clicking on Poultry, it will look in field 1 of the database to return the values ​​of the subgroups here. After clicking on some value, it will fill the form and search database field 4 for non-repeating values.</td></tr>
	<tr><td style='padding-top:10px;color:#FFEFA0;' colspan='6'>Step 3º: Select one item for filling the form Food (4) field or write there your own one.</td></tr>
	<tr><td style='padding-top:10px;' colspan='6'><span  onclick=''>item 1</span>, <span  onclick=''>Item 2</span>, Item 3, etc. ...</td></tr>
	</table>
	<div style='padding-top:10px;color:#FFEFA0;' colspan='6'>Step 4º: Click the button «Buscar en BD (9)».</div>
	<div style='margin-top:7px;'>Options found on field 9. After selecting one of them, the form will be filled and you could calculate (Quantity field is requiered).  Then you will have the option to save the results.</div><br>

	<div style='padding-top:10px;color:#FFEFA0;' colspan='6'>Step 5º: Select one row of the step 4º results.</div>
	<div style='margin-top:7px;'>Option selected for calculation.</div><br>
	</div>
	<div style='padding-top:10px;color:#FFEFA0;' colspan='6'>Step 6º: Press the button «Cálculo» .</div>
	<div>Receta.- Kilocalorias: xxx, Proteínas: 20 g, Carbohidratos: 20 g, Grasas: 20 g,  Colesterol: xx mg, Vit. A: xx RAE, Vit. B: xx mg, Vit. C: xx mg, Calcio: xx mg, Potasio: xx mg, Hierro: xx mg </div>
	<div style='padding-top:10px;color:#FFEFA0;' colspan='6'>Step 7º: Press the button «Add to Recipe» .</div>

</div>
	<div style='font-size:12px;color:#FFEFA0;cursor:pointer;' onclick="showHide('learn')">⇅ <b>Learn (Internet sources)</b></div>
	<div id='learn' style='padding-left:17px;margin-bottom:10px;display:none'>
		<a style='color:white;cursor:pointer;' href='https://www.certifiedangusbeef.com/cuts/' target='blank_'>Beef cuts</a><a style='padding-left:15px;color:white;cursor:pointer;' href='https://national4hpoultry.ca.uky.edu/marketpoultry/partsID' target='blank_'>Poultry cuts</a>
	</div>
</div>

<div style='font-size:12px;color:#FFEFA0;cursor:pointer;' onclick="showHide('letras')">⇅ <b>Tutorial</b></div>
<div id='letras' style='width:1300px;display:none'>
<div style='width:100%;text-align:justify;'><br>
<span id="generalidades"></span><br><br>
<a style='color:white' href="#grid">Grid</a><br>
<a style='color:white' href="#menu">Menu</a><br>
<a style='color:white' href="#list">List</a><br>
<a style='color:white;text-shadow: -1px -4px 5px gray, 1px 5px 6px gray;' href="#generalidades">Generalidades</a><br>
<a style='color:white' href="#part1" target="_self">Part1</a><br><br>
La aplicación consta de 2 páginas HTML: nutrientes y recetas. Son páginas HTML-Javascript que aportan alta legibilidad del código e interacción usuario-máquina, con código PHP como interfaz soft-hardware (www.php.net/manual/en/install.windows.commandline.php) que permite disponer de un servidor local sin necesidad de acceso a Internet (con Docker mejoran las prestaciones). Por último, los comandos de GNU-Utils (gnuwin32.sourceforge.net/packages/coreutils.htm), ejecutables en el Shell, aportan máxima velocidad a las operaciones dependientes del disco duro, donde residen los archivos de base de datos y de scripts. Ha sido creada usando Google Chrome que, incorporando nativamente Google Translate, ayuda a superar la brecha lingüística.<br><br>

Las medidas de seguridad del navegador son elementales para la seguridad del usuario. No obstante, las medidas de seguridad de la aplicación vienen dadas conjuntamente con PHP. Así, las órdenes dadas desde el navegador a los comandos que operan en el disco duro (Shell) se restringen a la carpeta en la que se está ejecutando PHP como servidor. Sin embargo, alojar la aplicación en un contenedor Docker aporta una capa adicional de seguridad desde el Shell (todas las carpetas) hasta la carpeta raíz de la aplicación y, por lo tanto, a la dirección http://localhost. El usuario puede utilizar ambas opciones, con o sin Docker, pero se recomienda usarla con Docker y sólo para el escritorio o dominio http://localhost.<br><br>

El archivo esencial de la aplicación es su Base de Datos de alimentos y nutrientes. La Base de Datos fuente utilizada es la https://www.mattilsynet.no/?language=en, cuyo responsable es la 'Norwegian Food Safety Authority (NFSA, www.mattilsynet.no/language/english/about_us/)'. La aplicación conserva una copia del original en 'recetas/bd/security/The Norwegian Food Composition Table 2022 (ods)' El archivo de base de datos usado por la aplicación es 'recetas/bd/work.csv', a la que se le han añadido algunas columnas y, en su primera columna, reemplazado las referencias originales por las propias (timestamps consecutivos). Se usa una copia, alfabéticamente ordenada por sus campos Group:Subgroup, con el objetivo de favorecer la velocidad sólo de las búsquedas por grupos (<a style='color:white' href="#groups" target="_self">Group:Subgroup</a> recetas/tutorial/fs_food-improvement-agents_guidance_1333-2008_annex-2.).<br><br>

<span style='color:yellow;text-shadow: -1px -4px 5px gray, 1px 5px 6px gray;'>Buscar</span><br>
Para usar la búsqueda es buena idea atender a la siguiente regla nemotécnica: 'Usted busca líneas de campos, la App busca campos de lineas'.<br><br>

Hay 2 formas de buscar los nutrientes (nutrients) de un alimento: 1. mediante el 'Food Menu', siguiendo los pasos (Steps), y mediante 2. el botón 'Search in DB'. La primera forma está disponible siempre, la segunda sólo lo está en 'Search MODE'. Es decir, requiere pulsar el botón 'Recipe MODE' y pasar a 'Search MODE'. Los alimentos (food) son agrupados acercándose a la clasificación de la UE, pero no exactamente, porque el fin es 'crear' una receta de cocina y no 'administrar' productos alimenticios.<br><br>

Por ejemplo, la clasificación europea no incluye a los 'helados' hechos con leche en el grupo 'Dairy&Analogues' y la aplicación sí, porque ciertos helados del mercado se pueden usar como 'componentes alimenticios (food) de una receta más compleja'. La UE une en el grupo (4), de 'frutas y vegetales', a muchos alimentos que la aplicación separa en los grupos '3, 5, 6 y 13'. Además, la aplicación incluso elimina grupos, como el 'Confectionary' de la UE, que agrupa productos de mercado que el usuario de la aplicación puede 'confeccionar' a base de recetas, como los de pastelería.<br><br>

<span style='color:yellow;text-shadow: -1px -4px 5px gray, 1px 5px 6px gray;'>Clasificación</span><br>
Los títulos de los grupos son intencionadamente 'propuestos'-se pueden cambiar sin problemas adicionales-para facilitar la 'primera búsqueda' del alimento. Por ejemplo, el grupo 'egg' contendrá 'todo' lo que sea un 'huevo germinal', de ave, de pez, etc. Una vez determinado el grupo, todo aquello que se quiera incluir en él tiene que ser determinado en la Base de Datos, columna 2 y formato grupo:subgrupo, siendo su casilla 3 contigua fundamentalmente informativa auxiliar, mientras su casilla 10 será de una corta descripción. Se ha buscado usar como fuente de información Wikipedia. Por ejemplo, para los subgrupos de las frutas se ha usado la información de Wikipedia en tinyurl.com/56k8pau4<br><br>
<xmp>
Columna BD	Contenido de la celda			Menú Grid
1		número de identificación		1 Reg. No.
2		grupo:subgrupo				2 Group:Subgroup
							   Food Menu
							   Step 1: Nº y grupo de versión libre
							   Step 2: Subgrupos encontrados en la BD
							   Step 3: Alimentos encontrados en la BD
3		información auxiliar			3 Made of
10		descripción corta			4 Plus-words
</xmp>
<span style='color:yellow;text-shadow: -1px -4px 5px gray, 1px 5px 6px gray;'>Buscar por menú (Steps)</span><br>
Al pulsar en 'Step 1' el 'Grupo' es mostrado en 'Group:Subgroup', y en el 'Step 2' se le añade el 'Subgrupo' y se muestran las opciones del 'Setp 3'. Al pulsar sobre una de ellas se muestran los alimentos ya clasificados en la Base de Datos y se inicia 'Sesión de Receta' para 'añadir' uno a la receta.<br><br>

Las categorías del 'Step 1' son fijas en el HTML, mientras el resto es variable, a disposición del usuario para crearlas o modificarlas mediante el botón 'Replace in DB' (siguiendo algunas reglas) para modificarlas. Aunque, como ya se debería saber, en la App todo se puede hacer a través de la línea de comandos (no recomendado), editor de texto, u otras aplicaciones. En este caso la clasificación de la UE (fs_food-improvement-agents_guidance_1333-2008_annex-2.pdf) ayuda mucho, otras veces hay que buscar clasificaciones alternativas (r04.pdf) para diseñar 'subgrupos'.<br><br>

Al pulsar sobre un subgrupo el paso 'Step 3' mostrará información auxiliar dependiente del usuario (modificable con el botón 'Replace in DB'). Mostrará, por ejemplo, 'de qué principalmente está hecho el alimento' ('3 Made of' de 'Nutrients Grid'). Al pulsar sobre un subgrupo se mostrarán los registros que contienen, por ejemplo, el subgrupo 'cow'. Se muestran de izquierda a derecha: 1. el 'Reg. No.' único de cada registro, 2. el 'Group:Subgroup', 3. el 'Made of' y 4. una descripción corta correspondiente, en el 'Nutrients Grid', al campo '4 Plus-words'. Finalmente, en la lista de resultados, al pulsar sobre un número de identificación (en amarillo) se mostrarán los nutrientes de ese alimento en las celdas del 'Nutrients Grid'.<br><br>

El 'Recipe MODE' está dirigido a crear recetas, mientras el 'Search MODE' a buscar alimentos.<br><br>

<span style='color:yellow;text-shadow: -1px -4px 5px gray, 1px 5px 6px gray;'>Buscar por botón (Search in DB)</span><br>
Si hemos estado pulsando en los menús, el botón 'Search in DB' no funcionará hasta que pulsemos 'Recipe MODE' para entrar en 'Search MODE'. Se puede marcar la casilla (columna izquierda de 'Nutrient Grid', 3 AND/OR 4), por defecto se busca que estén presentes tanto 'Made of' como 'Plus-words'. Entonces, Se podrá buscar:<br><br>

<div style='margin-left:20px;'>1. por el '1 Reg No':<br><span style='padding-left:10px;'>Su presencia en en la casilla es determinante. Al pulsar 'Search in DB' mostrará el registro correspondiente, al final de 'Food Menu' y principio de 'Food List'. Como antes, se pulsa el 'Reg. No' para mostrar los nutrientes en el 'Nutrient Grid'.</span></div><br>

<div style='margin-left:20px;'>2. por un '2 Group:Subgroup':<br><span style='padding-left:10px;'>Se buscarán en los registros el valor 'Made of' y/o '4 Plus-words' que coincidan con el group:subgroup especificado. No puede buscar los 'Group:Subgroup', sólo 'algo' que esté clasificado en el 'Group:Subgroup' que especifique.</span></div><br>

<div style='margin-left:20px;'>3. por varios grupos:<br><span style='padding-left:10px;'>Se buscarán en los registros que coincidan con los group:subgroup seleccionados en 'Food Menu' el valor 'Made of' y/o '4 Plus-words'.</span></div><br>

<div style='margin-left:20px;'>4. por sólo valores de '3 Made of' y/o '4 Plus-words' (cualquiera o ambos):<br><span style='padding-left:10px;'>Se buscarán en todos los registros aquellos que coincidan con el valor 'Made of' y/o '4 Plus-words'.</span></div><br>
Usted puede probar marcando y desmarcando alternativamente para buscar con 'Y' o con 'O'.<br><br>

<div style='margin-left:20px;color:yellow;'><br>Ejemplo de 1:</div>
<div style='margin-left:20px;'><span style=''>En la celda '1 Reg. No.' insertar un identificador de registro, por ejemplo 1262304073. Si el botón de la esquina superior izquierda de 'Nutrients Grid' está en 'Recipe Mode' pulsarlo para cambiar a 'Search Mode'. Entonces pulsar el botón de búsqueda 'Search in DB'. Bajo 'Step 4' se mostrará el resultado: <span style='color:yellow'>1262304073 </span>1:cheese : Cheese, blue mold, Gorgonzola. Ahora, al pulsar sobre <span style='color:yellow'>1262304073</span> los nutrientes del alimento se mostrarán en el 'Nutrients Grid'.
</span></div><br>
<div style='margin-left:20px;color:yellow;'>Ejemplo de 2:</div>

<div style='margin-left:20px;'><br><span style=''>Elimine el identificador de registro, porque su presencia 'determina la búsqueda'. Ahora es el 'Group:Subgroup' especificado el que 'determina' dónde buscar '3 Made of' y/o '4 Plus-words'. Marcado como 'AND' buscará 'las líneas' que contengan tanto el primer valor como el segundo. Si el marcado es 'OR' buscará 'las que contengan el primero o al menos el segundo, por lo tanto también encontrará las líneas que contengan a ambos valores.<br><br>

En la celda '4 Plus-words' borre todo menos 'blue'. AL pulsar 'Search in DB' se buscarán los registros que contengan '1:cheese' en el campo 2º, 'cow' en el campo 3º Y (AND) 'blue' en el campo 10º. El resultado será:<br><br>

<span style='color:yellow'>1262304073</span> 1:cheese : <u>cow</u> : Cheese, <u>blue</u> mold, Gorgonzola<br>
<span style='color:yellow'>1262304074</span> 1:cheese : <u>cow</u> : Cheese, <u>blue</u> mold, Norzola<br>
<span style='color:yellow'>1262304075</span> 1:cheese : <u>cow</u> : Cheese, <u>blue</u> mold, organic, Selbu Blå<br>
<span style='color:yellow'>1262304076</span> 1:cheese : <u>cow</u> : Cheese, <u>blue</u> mold, Roquefort<br>
<span style='color:yellow'>1262304077</span> 1:cheese : <u>cow</u> : Cheese, <u>blue</u> mold, Selbu Blå<br>
<span style='color:yellow'>1262304085</span> 1:cheese : <u>cow</u> : Cheese, Stilton, <u>blue</u><br>
<span style='color:yellow'>1262304090</span> 1:cheese : <u>cow</u> : Cheese, <u>blue</u> mold, Normanna<br><br>

Pruebe también con 'O' desmarcando la casilla seleccionada programáticamente sobre el botón 'Search in DB'.
</span></div><br>
<div style='margin-left:20px;color:yellow;'>Ejemplo de 3:</div>
<div style='margin-left:20px;'><span style=''><br>Esta búsqueda es especial. En los otros casos, 'Reg. No.' es buscado en el campo 1º, 'Group:Subgroup' en el 2º, 'Madeof' en el 3º, y 'Plus-words' en el 10º. En este caso usted selecciona los grupos y se buscará 'madeof' Y/O 'Plus-words' no en un campo de la línea de registro sino en toda la línea.<br><br> Seleccione los grupos en los que va a realizar las búsquedas. Por ejemplo, marque la casilla de '1 Dairy&Analogues' y de '18 Baby&Formula'. En 'Food Menu', 'Step 1', pulse sobre '1:Dairy&Analogues', en Step 2, sobre 'cheese', y en 'Step 3', sobre 'goat'-o escriba 'goat' directamente en '3 Made of' del 'Nutrients Grid'. Inserte 'smoothie' en la celda '4 Plus-words', cambie a 'Search MODE' y desmarque la casilla 'AND/OR'. Pulse 'Search in DB'.<br><br>

El resultado muestra no sólo el grupo '1:' con los subgrupos 'milk', 'cream', 'cheese' sino que también verá el subgrupo 'baby' del grupo '18:'. Marcando la casilla para buscar registros que contengan ambas palabras dará 'Msg 2:1 No record found', porque no hay ninguno.
</span></div><br>
<div style='margin-left:20px;color:yellow;'>Ejemplo de 4:</div>
<div style='margin-left:20px;'><span style=''><br>Esta es la opción de búsqueda 'sin filtro', es decir, sin 'número de identificación' ('Reg. No.' vacío) y sin 'grupo' ('Group-Subgroup' vacío). Puede tardar mucho, pero el archivo recetas/scripts/findIdcr.PID contiene el PID para detener el script: 'recetas/scripts$> kill -SIGTERM $(cat findIdScr.PID)'.<br><br>

Tenga en cuenta que las casillas vacías son valores. Las casilla de '1 Reg No.' vacía sólo adquiere valor 'técnico' de 'casilla vacía', porque no pueden haber registros sin número de identificación. Pero para 'Group:Subgroup' sí pueden haber registros 'sin valor', es decir sin datos en su campo, porque al alimento no se le ha asignado aún un 'Group:Subgroup'. Inmediatamentement después de una actualización de la BD, también el campo de '3 Madeof' estará vacío, mientras el campo '4 Plus-words' siempre tendrá datos en su campo de BD.

Para acceder a esos registros a los que hemos de asignarle 'Group:Subgroup' y un 'Made of' estas dos casillas se dejarán vacías 1, 2, 3, y se insertará la palabra clave 'none' en la '4 Plus-words' marcando para 'AND' (si se la desmarca para 'OR' mostrará toda la base de datos y tarda bastante).

  'casilla vacía' la primera y la segunda ad para esas dos anterioreTPero, en cualquier caso, si la tercera y la cuarta están vacías la App dará un mensaje: 'Msg: Nothing to search'. endrá registros (líneas) a la que aún no la dado un 'Grupo:Subgrupo' <br><br>

Para ver esta opción en funcionamiento insertamos en 'Menu Grill', por ejemplo, 'cow-goat' ('3 Made of') y 'brie' ('4 Plusfield-words'). Establecemos el 'Search MODE' y, al pulsar 'Search in DB', el resultado será 'Msg 2:1 No record found'. Si sustituimos 'cow-goat' por 'goat' o por 'sheep' dará el mismo resultado, pero si lo sustituyéramos por 'cow' el resultado será:<br><br>

1262304081 1:cheese : <u>cow</u> : Cheese, ripened, <u>Brie</u><br><br>

Lograr esta información fue fácil, más farragoso hubiese sido usar los 'Step' del 'Food Menu' para conseguirla. En esas celdas puede utilizar patrones 'RegEx', en Internet puede aprender a usar esos patrones y luego aplicarlos en la aplicación.

</span></div><br>


</span></div><br>
Muy interesante es cómo usar las celdas del 'Nutrient Grid' con patrones 'RegEx'-en Internet puede estudiar cómo.<br><br>

A. '*': El arterisco indica que el carácter que le precede puede aparecer cero, una, o más veces. Por ejemplo, "0*42" se corresponde con 42, 042, 0042, 00042, etcétera.<br>
B. '.': El punto indica cualquier carácter excepto 'avance de línea \n'. Por ejemplo '.a' puede ser ba, ca, 1a, etc. Mejor, indica todos los caracteres de una secuencia que existan entre un carácter límite 'que abre' y otro carácter límite 'que cierra' la secuencia.<br><br>

Haciendo una prueba con la base de datos:<br>
1. Usar el 'Food Menu' pulsando en Step 1 => 1 Dairy&Analogues, Step 2 => 'cheese' y Step 3 => 'goat'. Cambiar a 'Search Mode' e insertar 'goat*hard' en la celda de '4 Plus-word'<br>
2. Pulsar 'Search in DB'<br>
El resultado es 'Msg 2:1 No record found'. Porque el arterisco dice que la letra 't', de goat, se puede repetir 0, 1 o más veces. y seguidamente tiene que aparecer la letra 'h' de 'hard'. Es decir, buscará la secuencia 'goath...', pero la secuencia de caracteres 'g-o-a-t-h' no existe en ninguno de los registros en los que se ha buscado.<br><br>

Ahora, si insertamos el patrón 'goat.*hard', que significa 'goat' seguido de un carácter 't u otro' que, por el arterisco, puede repetirse o no, entonces buscará 'goat_t u otro carácter que por '*' puede repetirse_'hard'. Pulsando 'Search in DB'.<br><br>
Encontró: 'Goat' cheese, 'hard'. Es decir, 't' (1 punto) seguido del carácter 'espacio vacío' (1 punto 'repetido'), seguido de 'c-h-e-e-s-e-,' (más repetición de puntos), seguido de 'espacio vacío' (otro punto repetido), y todo terminando en el carácter 'h'.<br>
<br><br>
1. download the actualized DB from 'matportalen.no' (Info: matportalen.no/verktoy/the_norwegian_food_composition_table)<br>
2. you must covert it into a CSV file format with '|' as field delimiter. You can use Open Office to load the'.ods' file and save as workcsv.csv ('|' as field delimiter) in the recetas/bd/bdupdate folder.<br>
	Open Office: The Norwegian Food Composition Table 2022 (ods) > workcsv.csv<br>
ok<br><br>
4. remove all columns cotaining any of the following strings: Edible part,Ref,Kilojoules,C12:0,C14:0,C16:0,C18:0,MuFa,C16:1 sum,C18:1 sum,PuFa,C18:2n-6,C18:3n-3,C20:3n-3,C20:3n-6,C20:4n-3,C20:4n-6,C20:5n-3 (EPA),C22:5n-3 (DPA),C22:6n-3 (DHA)<br>

columnsForArray='';arrayColums='';arrBogus=("Edible part" "Ref" "Kilojoules" "C12:0" "C14:0" "C16:0" "C18:0" "MuFa" "C16:1 sum" "C18:1 sum" "PuFa" "C18:2n-6" "C18:3n-3" "C20:3n-3" "C20:3n-6" "C20:4n-3" "C20:4n-6" "C20:5n-3 (EPA)" "C22:5n-3 (DPA)" "C22:6n-3 (DHA)");for bogus in "${arrBogus[@]}"; do columns=$(awk -F '|' -v bogus="$bogus" 'NR==3 { for (i = 1; i <= NF; i++) { if ($i == bogus) { print i } } }' workcsv.csv);columnsSet=$columnsSet' '$columns;done;columnsSet=$(echo $columnsSet | sed 's/ /,/g');cut -d '|' --complement -f$columnsSet workcsv.csv > tmp;mv tmp workcsv.csv<br>

awk -F '|' '$1 ~ /^[0-9]{2,}\.[0-9]{2,}/' workcsv.csv > tmp;mv tmp workcsv.csv<br>

*this is the '0 option' of the script 'bdupdate.scr'<br>
#sorted_set=$(echo "$set" | tr ' ' '\n' | sort -n | tr '\n' ' ')
ok<br><br>
____now we have the file workcsv.csv with a 'haircut' of rows and columns, ONLY REGISTERs with original id<br><br>

6. Añadirle 8 columnas a la izquierda, la primera de las cuales va a ser para los ids de la App, la segunda para los 'Group:Subgroup' y la tercera para 'Made of'. La 9ª es la de los ids originales y la 10ª la de 'Plus-words'. Quedarán 6 columnas para modificaciones en el futuro como, por ejemplo, añadir valores de alguna clase.

7.

<br>
6. execute the bdupdate.scr workcsv.csv work.txt to see the matches and unmatches after selecting the option 1
7. with the option 2 you can choose to add the unmatched records
8. you should look for repeated ids and decide the record to delete. Ids can not be repeated.
9. Copy to bd the new database file with the name work.csv

how to look for repeated numbers in the column 1 of file.txt







9. compare workCSV.o with tmp.txt. If the nutrient cell serie is equal in both files copy the 'tmp.txt field2 and field3' to workCSV.out

1. download the actualized DB from 'matportalen.no' (Info: matportalen.no/verktoy/the_norwegian_food_composition_table)
2. back up with the name workDB0.ods.
ok
3. you must transform workDB0.ods into a CSV file format with '|' as field delimiter. You can use Open Office to load workDB0.ods and save it as workcsv.csv ('|' as field delimiter).
ok
4. remove all columns cotaining any of the following strings: Edible part,Ref,Kilojoules,C12:0,C14:0,C16:0,C18:0,MuFa,C16:1 sum,C18:1 sum,PuFa,C18:2n-6,C18:3n-3,C20:3n-3,C20:3n-6,C20:4n-3,C20:4n-6,C20:5n-3 (EPA),C22:5n-3 (DPA),C22:6n-3 (DHA)
arrayColumns='';arrayBogus='';arrBogus=("Edible part" "Ref" "Kilojoules" "C12:0" "C14:0" "C16:0" "C18:0" "MuFa" "C16:1 sum" "C18:1 sum" "PuFa" "C18:2n-6" "C18:3n-3" "C20:3n-3" "C20:3n-6" "C20:4n-3" "C20:4n-6" "C20:5n-3 (EPA)" "C22:5n-3 (DPA)" "C22:6n-3 (DHA)");for bogus in "${arrBogus[@]}"; do arrayBogus=$(awk -F '|' -v bogus="$bogus" 'NR==3 { for (i = 1; i <= NF; i++) { if ($i == bogus) { print i } } }' workcsv.csv);arrayColumns=$arrayColumns' '$arrayBogus;done;arrColumns=$(echo "$arrayColumns" | tr ' ' '\n' | sort -nr | tr '\n' ' ');columnsArr=($arrColumns);echo ${columnsArr[@]};for col in "${columnsArr[@]}"; do cut -d '|' --complement -f "$col" workcsv.csv > temp.csv;mv temp.csv workcsv.csv;cat workcsv.csv > workcsv0.csv;done
116 114 112 110 108 106 104 102 100 98 96 94 92 90 88 86 84 82 80 78 76 74 72 70 68 66 64 62 60 58 56 54 52 50 49 48 47 46 45 44 43 42 41 40 39 38 37 36 35 34 33 32 31 30 29 28 27 26 25 24 22 21 20 19 18 17 16 15 14 12 10 8 7 6 4 3
ok
6. print all rows whose first cell match '^[0-9]{2,}\.[0-9]{2,}': awk -F '|' '$1 ~ /^[0-9]{2,}\.[0-9]{2,}/' workcsv.csv > workcsv0.csv;
ok
__________now we have the file workcsv0.csv with a 'haircut' of rows and columns.


7. move the first column to the end: awk 'BEGIN {FS="|"; OFS="|"} {print $0, $1}' workDB2.csv > tmp;mv tmp workDB2.csv;rm tmp
awk -F '|' '$1 ~ /^[0-9]/'
8. add nine columns to the beginning of the file: awk -F '|' 'BEGIN {OFS="|"} {$0 = "|||||||||" $0} 1' workDB2.csv > tmp;mv tmp workDB2.csv;rm tmp
9. compare workDB2.csv with bd.tmp. If the nutrient cell serie is equal in both files copy the 'bd.tmp field2 and field3' to workDB2.csv

Now the APP is ready to be public.

Pending: Update the DB depending on the updated original DB.
9. compare workDB2.csv with bd.tmp. 1. If there is a nutrient cell serie in workDB2.csv that does not exist in bd.tmp copy the entire row to the last (stop: in the second file, take into account the 'original id' at the end of rows, the nine aditional fields, and the bigest nanoseconds timestamp, incremented in one unit, in the second file), If the nutrient cell serie is equal in both files copy bd.tmp field2 and field3 to workDB2.csv,

9. insert a consecutive timestamp in nanoseconds into the first cell of each row of the first column: awk -F '|' 'BEGIN {OFS="|"} {timestamp = systime() * 1e9; $0 = timestamp "|" $0} 1' workDB2.csv > tmp;mv tmp workDB2.csv;rm tmp


<h2 id="part1"></h2>
<a style='color:white' href="#generalidades">Menú</a><br>
And then you're all set — you have a functioning hyperlink between two pieces of content on the same page. Simple as that.<br>

Why create anchor links to jump to a specific part of the page?
Even though creating anchor links adds a few more steps to your process before publishing a blog post, it can make a big impact on user experience.

Anchor links can be used to create features like table of contents, which can enhance the organization of long blog posts.

Creating links that take you to a specific part of the page makes it much easier for users to navigate through your content and find the information they are looking for. Without the assistance of anchor links, users may end up scrolling through the page for a long time, which could lead them to bounce.

Ultimately, your customers will appreciate skimmable, easy-to-read content and may be more likely to revisit your site or make a purchase because of it.

Create Anchor Links With Ease
Linking to a specific part of a page is a simple way to make your content more user-oriented. In just a few short steps, you can create anchor links that make navigating long blog posts a piece of cake.

(Hey there, curious folks from the introduction! Click here to go back to where you left off.)

Editor's Note: This post was originally published in July 2022 and has been updated for freshness, accuracy, and comprehensiveness.

New Call-to-action
Topics:
Content Creation Resources
Related Articles
prevnext
6 Handy Resources to Help Solve Your Biggest Content Creation Problems
6 Handy Resources to Help Solve Your Biggest Content Creation Problems
Sep 12, 2014

No Photoshop? No Problem: 10 Visual Content Tools for Beginners
No Photoshop? No Problem: 10 Visual Content Tools for Beginners
Jul 08, 2014

Create Ebooks in Half the Time With These Essential Resources
Create Ebooks in Half the Time With These Essential Resources
Nov 13, 2013

A 3-Minute Investment That'll Make You a Better Content Creator
A 3-Minute Investment That'll Make You a Better Content Creator
Oct 04, 2013

5 Tools to Battle Social Media Content Overload
5 Tools to Battle Social Media Content Overload
Jan 04, 2012

45 Free Content Writing Tools to Love [for Writing, Editing & Content Creation]
45 Free Content Writing Tools to Love [for Writing, Editing & Content Creation]
Feb 23, 2023

10 Content Curation Tools Every Marketer Needs
10 Content Curation Tools Every Marketer Needs
Aug 02, 2021

The Ultimate List of Websites Every Blogger Should Bookmark
The Ultimate List of Websites Every Blogger Should Bookmark
Dec 15, 2016

7 Easy-to-Use Interactive Content Tools You Should Explore
7 Easy-to-Use Interactive Content Tools You Should Explore
May 30, 2015

9 Great Tools to Help You Write & Edit Blog Posts Better
9 Great Tools to Help You Write & Edit Blog Posts Better
Mar 16, 2015

6 Handy Resources to Help Solve Your Biggest Content Creation Problems
6 Handy Resources to Help Solve Your Biggest Content Creation Problems
Sep 12, 2014

No Photoshop? No Problem: 10 Visual Content Tools for Beginners
No Photoshop? No Problem: 10 Visual Content Tools for Beginners
Jul 08, 2014

Create Ebooks in Half the Time With These Essential Resources
Create Ebooks in Half the Time With These Essential Resources
Nov 13, 2013

A 3-Minute Investment That'll Make You a Better Content Creator
A 3-Minute Investment That'll Make You a Better Content Creator
Oct 04, 2013

5 Tools to Battle Social Media Content Overload
5 Tools to Battle Social Media Content Overload
Jan 04, 2012

45 Free Content Writing Tools to Love [for Writing, Editing & Content Creation]
45 Free Content Writing Tools to Love [for Writing, Editing & Content Creation]
Feb 23, 2023

10 Content Curation Tools Every Marketer Needs
10 Content Curation Tools Every Marketer Needs
Aug 02, 2021

The Ultimate List of Websites Every Blogger Should Bookmark
The Ultimate List of Websites Every Blogger Should Bookmark
Dec 15, 2016

7 Easy-to-Use Interactive Content Tools You Should Explore
7 Easy-to-Use Interactive Content Tools You Should Explore
May 30, 2015

9 Great Tools to Help You Write & Edit Blog Posts Better
9 Great Tools to Help You Write & Edit Blog Posts Better
Mar 16, 2015



Pop up for 25 FREE HTML & CSS HACKS

A partir de ese original  https://www.matportalen.no/

Su manejo es un proceso: 1. Componer Receta (cualquiera, mesa.php), 2. Crear Receta (cualquiera, recipes.php), 3. Compartir Receta (cualquiera, Guided Recipes y Unguided Recipes), 4. Mantener App (Chef, chef.php). El paso 4º está restringido al Chef, aunque se han suprimido los permisos del Chef y cualquiera puede hacer de Chef. Se puede crear una página adicional de configuración para dar y revocar permisos y contraseñas.

La base de datos inicial contiene unos 2000 registros (filas)—demasiados para un programador amateur—que el usuario puede aumentar (mesa/bd/security/The Norwegian Food Composition Table 2022). El programador sólo ha ajustado una pocos registros o filas en la hoja de trabajo (mesa/bd/work.csv). Cada usuario tendrá que hacer su trabajo para seguir ajustando o cambiar los criterios de los ajustes. Conviene que varios usuarios compartan copias de ese archivo y así reducir la carga de trabajo individual.<br><br>

La hoja de trabajo 'work.csv' se puede cargar en LibreOffice Calc. Quien sepa usar la Hoja de Cálculo podrá añadir y ajustar los registros. También podrá hacerlo uno a uno mediante la aplicación. Esta funciona con PHP en Linux, otros sistemas operativos necesitan instalar el paquete de comandos Bash de GNU. Por supuesto, siempre va a funcionar con un Alpine en Docker si el Alpine dispone del Bourne Again SHel (bash) y no sólo del Bourne shell(sh)<br><br>

<div style='color:#FFEFA0;padding-bottom:10px;'>Veamos un ejemplo de funcionamiento para crear una receta:</div>
 1. Nos encontramos con la portada inicial. Primero, un formulario (_Form_) con un botón a la izquierda (Search 1,2,3,4) para buscar los términos de los campos 1, 2, 3, y/o 4; están vacíos porque han de ser cumplimentados por el usuario. Los campos restantes con valores muestran las necesidades diarias medias o los rangos. La Cantidad (Quantity) ha de ser insertada por el usuario y el valor Kc por 100 gr. dependerá del alimento que se seleccione en el menú, y están vacíos.
</div>
<div style='width:100%;margin-top:20px;text-align:center;'>
<img style='width:80%;' src="bd/images/Captura de pantalla de 2023-02-08 13-25-35.png" align="center">
</div>
<div style='width:100%;margin-top:20px;'><br>
Debajo del formulario tenemos el menú (_Menu_) con los pasos 'Step 1', desplegado, con sus opciones 'Dishes' y 'Snacks' deshabilitados. El resto de pasos hasta el '4', se van desplegando a medida que se avanza en las selecciones y en adelante permanecerán desplegados. Se seleccionan los términos de color blanco negrita excepto en el paso '4' en el que la opción seleccionable es su nº de registro en color amarillo.
</div>
<div style='width:100%;margin-top:20px;text-align:justify;'>
Finalmente tenemos el área 'Editable Recipe' y luego la opción para acceder a este tutorial. El primero mostrará la serie calculada de nutrientes (1) por registro según la cantidad de alimento que el usuario inserte en el campo 'Quantity' del formulario, registro por registro hasta completar la lista de alimentos de la receta. Pero para calcular los totales de nutrientes de todos los alimentos (2) de la lista requerirá que los campos 'Recipe Title' y 'Main foods' (alimentos separados por comas) hayan sido cumplimentados. El campo 'Recipe Filename' lo crea la aplicación uniendo mediante un guión bajo el título (sin espacios en blanco) a los segundos transcurridos desde el 01.Ene1970 hasta el momento del click.
</div>
<div style='width:100%;margin-top:20px;text-align:center;'>(1) y (2)</div>
<div style='width:100%;margin-top:20px;text-align:center;'>
<img style='width:80%;' src="bd/images/Captura de pantalla de 2023-02-08 13-26-48.png" align="center">
</div>
<div style='width:100%;margin-top:20px;padding-left:20px;'><br>
(1) Tras la selección de cada alimento para la receta el botón 'Calculate Food', a la derecha del cuestionario, se presiona cada vez y las series calculadas de nutrientes son mostradas una a una en el área 'Editable Recipe'. Antes de eso, si se presiona el botón 'Add to Database' a la derecha del cuestionario, esquina inferior, el registro supuestamente modificado se añade a la base de datos, de repetirse el registro o no ser modificado sobreescribirá el existente (sin previo aviso).<br><br>
</div>
<div style='width:100%;margin-top:20px;text-align:center;'>
<img style='width:80%;' src="bd/images/Captura de pantalla de 2023-02-08 13-33-43.png" align="center">
</div>
<div style='width:100%;margin-top:20px;padding-left:20px;'><br>
(2) El botón 'Calculate Recipe', a la derecha del área 'Edible Recipe', pesenta en el formulario el resultado del cálculo de todos los nutrientes a condición de cumplimentar los campos 'Recipe Title' y 'Main Foods (separados por comas)'. Finalmente, de momento, tras pulsar el botón 'Save' abre una página (mesa/recipes/recipes.php) con los nuevos datos en otra solapa para completar y gestionar la nueva receta. Los datos de esa nueva receta se conservarán mientras no sea sobreescrita por otra más reciente.<br><br>
El botón 'Search 1,2,3,4' inicial a la izquierda del formulario ha sido sustituido por el 'Recipe MODE', que vacía los campos del formulario para realizar una búsqueda. Los alimentos previamente seleccionados presentes en el área 'Editable Recipe' se conservarán. Pueden ser modificados y las líneas eliminadas, seleccionándolas (botón izquierdo presionado y arrastre), por ejemplo, mediante la tecla 'Supr' o el menú emergente para el 'Cut'.
</div>
<div style='width:100%;margin-top:20px;text-align:center;'>
<img style='width:80%;' src="bd/images/Captura de pantalla de 2023-02-09 03-04-49.png" align="center">
</div>
<div style='width:100%;margin-top:20px;padding-left:20px;'><br>
<div style='color:#FFEFA0'>La nueva solapa. Recipes</div>
Con 4 columnas, la primera izquierda muestra los campos de identificación a cumplimentar; los 2 primeros con los datos procedentes de la página previa (no conviene modificarlos). La segunda contiene la lista de alimentos, que puede ser modificada manualmente. La tercera espera del usuario las instrucciones de preparación culinaria por pasos. La cuarta ofrece los botones para gestionar la receta.<br><br>

Debajo de ésta hay 2 párrafos, el primero (Quantitative) muestra el registro de base de datos para recetas (mesa/recipes/db/quanti.db) y el segundo corresponde a la de la cualitativa (mesa/recipes/db/cuali.db); tiene pues 2 archivos de base de datos. A estos párrafos de campos para la receta les siguen 'Kc' (total de la receta) y 'Main Foods', que ya contienen los datos arrastrados de la página previa; el segundo puede ser modificado y el primero no debería. Los datos del resto serán proporcionados por el usuario mediante el siguiente '_Menu_'. <br><br>

El '_Menu_' comienza con las opciones '<span style='color:#FFEFA0'><b>Meats</b></span>, '<span style='color:#FFEFA0'><b>Dairy</b></span>', etc. La siguientes opciones van siendo mostradas a medida que van realizándose las selecciones. La selección hecha sobre el menú para grupos reinicia el proceso de selección. Debajo del menú los botones 'Show to Translate' y 'Google Translate' en todo momento pueden ser pulsados para muestrar el primero los contenidos del formulario y el segundo para realizar la traducción a los idiomas deseados en la columna 'Qualitative DB' debajo a la izquierda.<br><br>
</div>
<div style='width:100%;margin-top:20px;text-align:center;'>
<img style='width:80%;' src="bd/images/Captura de pantalla de 2023-02-09 04-00-11.png" align="center">
</div>
<div style='width:100%;margin-top:20px;padding-left:20px;'><br>
La página finaliza con la opción para 'mostrar/ocultar (⇅)' información sobre distintos temas, por ejemplo 'medidas y equivalencias', pulsando enlaces a Internet.
</div>
<div style='width:100%;margin-top:20px;padding-left:20px;'><br>
<div style='color:#FFEFA0'>Sus botones</div>
El botón 'Clear to Search' vacía todos los campos de búsqueda (tienen otro color de fondo), es decir, 'Reg. No.', 'Title', 'Author', 'Ingredients', 'Preparation', 'Kc', 'Main Foods', y el resto de esa línea. Los botones relacionados con las búsquedas tienen el mismo color de fondo. Una casilla de selección permite buscar en el archivo de base de datos 'Qualitative', seleccionada por defecto, o 'Quantitative' si se deselecciona. El botón 'Search Recipe' ejecuta la búsqueda' y el 'Restart' devuelve los datos del formulario a su estado inicial.<br><br>
Por último, el botón 'Save Recipe' guarda los datos en sus respectivos archivos de base de datos para recetas y el 'Share HTML' guarda una página HTML con la receta en inglés para seguidamente muestrala en una nueva solapa. Se comparte con otros usuarios en inglés para reiniciar el ciclo de uso en la aplicación. Si el usuario desea traducirla puede usar el menú 'click derecho' sobre la página y traducirla mediante la extensión del traductor de Google. Finalmente puede guardar la receta traducida siguiendo el mismo método y 'Guardar como ...' en la carpeta que desee; debe tener presente que si lo hace en la carpeta de la aplicación (mesa/recipes/recipeFiles) puede sobreescribir la generada previamente con 'Save Recipe' en idioma inglés.
</div>
<div style='width:100%;margin-top:20px;text-align:center;'>
<img style='width:50%;' src="bd/images/Captura de pantalla de 2023-02-09 04-55-05.png" align="center">
</div>
</div>








</div>
<div style='width:100%;display:none;'>
















En mesa/bd/security/The Norwegian Food Composition Table 2022 (ods) se encuentra la base de datos original en inglés (Noruega), A la base de datos de trabajo se le han añadido columnas. Si éstas son eliminadas o cambiadas de orden la aplicación puede dejar de funcionar y en general se espera que produzca errores. Las columnas son:<br><br>
group:subgroup|made of|brand,variety,source data|equal but ...|sustract|add|consistency|presentation|Food Item|Energy|Fat|SatFa|Ome-3|Ome-6|Chol|HC|Fib|Prot|Salt|Alcohol|A|D|E|B1|B2|Niacin|B6|Folate|B12|C|Ca|Fe|K<br><br>
Después de sumar las columnas de los Omegas y las Vitaminas B serán entonces:<br><br>
group:subgroup|made of|brand,variety,source data|equal but ...|sustract|add|consistency|presentation|Food Item|Energy|Fat|SatFa|Omegas|Chol|HC|Fib|Prot|Salt|Alcohol|A|D|E|B|C|Ca|Fe|K<br><br>
#complete base file (bd.csv) to tmp<br>
&nbsp&nbsp&nbsp	tail +6 bd.csv > tmp;<br>
#add the line number to each row AND save to work.csv<br>
&nbsp&nbsp&nbsp	cat tmp | grep -n '^' > work.csv<br>
#replace first occurence of ':' by '|' in every line (this is because the adding number is followed by ':')<br>
&nbsp&nbsp&nbsp	sed 's/:/|/' work.csv > tmp;cat tmp > work.csv<br><br>

#sum needs decimal numbers to change their ',' by '.'<br>
&nbsp&nbsp&nbsp	#save fields 1-10 in tmp file<br>
&nbsp&nbsp&nbsp	&nbsp&nbsp&nbsp	cat work.csv | cut -d'|' -f1-10 > tmp;<br>
&nbsp&nbsp&nbsp	#save fields 11-48 changing decimal ',' by '.' in tmpb file<br>
&nbsp&nbsp&nbsp	&nbsp&nbsp&nbsp	cat work.csv | cut -d'|' -f11-48 | sed 's/,/./g' > tmpb<br>
&nbsp&nbsp&nbsp	#add '|' at the end of every row of tmp file, save results in tmpc file, and rewrite tmp with tmpc<br>
&nbsp&nbsp&nbsp	&nbsp&nbsp&nbsp	sed 's/$/|/' tmp > tmpc;cat tmpc > tmp<br>
&nbsp&nbsp&nbsp	#join tmp and tmpb side by side with a width 500 chars between them<br>
&nbsp&nbsp&nbsp	&nbsp&nbsp&nbsp	pr -m -t -w 500 tmp tmpb<br>
&nbsp&nbsp&nbsp	#idem but pipeling through sed to remove tabs AND white spaces after '|'<br>
&nbsp&nbsp&nbsp	&nbsp&nbsp&nbsp	pr -m -t -w 500 tmp tmpb | sed 's/\t//g' | sed 's/| \+/|/g'<br><br>

#sum the values of the columns 16 and 17 (omegas) of the same row<br>
&nbsp&nbsp&nbsp awk -F "|" '{Total=$16+$17} END{print "Total is: " Total}' work.csv<br>
#sum the values of the columns 32 to 37 (Vit B complex) of the same row<br>
&nbsp&nbsp&nbsp awk -F "|" '{Total=$32+$33+$34+$35+$36+$37} END{print "Total is: " Total}' work.csv<br>
<br>

En el formulario, el valor del campo Group:subgroup es seleccionado por el usuario en el menú. Puede dejar en blanco el campo 'Made of ..,' y Food'. Al pulsar el botón 'Buscar en BD' el comando siguiente busca en la base de datos las líneas del grupo:subgrupo '3:pome'—(Columna 1)—y, porque el usuario no ha dejado en blanco el campo 'Made of ...', de éstas aquellas que contengan 'apple' en la columna 9:<br><br>
<span style='color:#FFEFA0;'>user@tron-telde:~/www/mesa/bd$</span> search="apple";group="3:";cat bd.csv | grep -n $group | cut -d'|' -f1-2,9,12-47 | grep -i "$search"<br><br>
El script de bash entregará las lineas al script PHP, y éste las enviará a la página en la que Javascript presenta los resultados. En este caso, el usuario dejó en blanco el campo 'Food' del formulario. Si también hubiese dejado en blanco el campo 'Made of ...' el resultado contendría una lista más larga. El usuario puede seguir haciendo búsquedas más finas y reducir las lista, por ejemplo, cumplimentando o copiando de los resultados términos de búsqueda a los campos 'Made of ...' y 'Food'. En la línea de comandos el resultado sería el siguiente:<br><br>
<span id='line1' style='color:#FFEFA0;text-decoration:underline;cursor:pointer;' onclick='copyLine(this.id)'>1298:3:pome</span><span id='line1Plus'>||Apple, Granny Smith, #FFEFA0en Delicious, raw|0,1|0|0|0|0|0|9,4|0|8,8|0|3|0|0|0|3|0|34|0|0,3|0,01|0|0,1|0,04|3|0|0|4|0,1|0|62|4|0|0|0,05|8|2</span><br>
<span id='line2' style='color:#FFEFA0;text-decoration:underline;cursor:pointer;' onclick='copyLine(this.id)'>1299:3:pome</span><span id='line2Plus'>||Apple, imported, raw|0,2|0|0|0,01|0,04|0|10,7|0,1|10,6|0|2|0,3|0|0|2|0|24|0|0,2|0,02|0,03|0,1|0,04|1|0|3|6|0,1|1|147|6|0|0|0,03|107|4</span><br>
<span id='line4' style='color:#FFEFA0;text-decoration:underline;cursor:pointer;' onclick='copyLine(this.id)'>1303:3:pome</span><span id='line4Plus'>||Apple, unspecified, raw|0,2|0|0|0,01|0,05|0|10,6|0,1|10,5|0|2|0,3|0|0|2|0|22|0|0,2|0,02|0,02|0,1|0,04|1|0|4|6|0,1|1|145|6|0|0|0,03|93|2</span><br>
<span id='line5' style='color:#FFEFA0;text-decoration:underline;cursor:pointer;' onclick='copyLine(this.id)'>1370:3:pome</span><span id='line5Plus'>||Apple jam, with less sugar|0,1|0|0|0|0,02|0|26|0,1|25,9|20|2|0,2|0|0|0|0|6|0|0,2|0,01|0,01|0,1|0,03|0|0|5|3|0,1|0|72|3|0|0|0,02|7|1</span><br>
<span id='line6' style='color:#FFEFA0;text-decoration:underline;cursor:pointer;' onclick='copyLine(this.id)'>1371:3:pome</span><span id='line6Plus'>||Apple jam, without added sugar|0,1|0|0|0|0,02|0|8|0,1|7,9|0|2|0,2|0|0|1|0|9|0|0,3|0,02|0,01|0,2|0,04|1|0|8|4|0,1|0|106|4|0|0|0,03|10|2</span><br><br>

Si fueran muchas líneas, como antes se dijo, puede copiar alguno de entre los mostrados en ellas, por ejemplo 'jam', pegarlo en el formulario y realizar una nueva búsqueda más específica. De lo contrario, que es lo más usual, el usuario selecciona aquella línea que contenga el alimento con los nutrientes y valores que mejor se correspondan con el alimento de su receta. Los datos se copiarán en el formulario y, al pulsar sobre 'Añadir a Receta', quedarán preparados para el cálculo final.<br><br>


En cualquier caso, el script en bash habrá tomado los valores de cada nutriente en cada línea. Si es necesario habrá hallado el valor medio, por ejemplo para las vitaminas B1, B6, etc., acumulado los resultados de cada línea y envíado el paquete final al script PHP. Este último lo entregó a la página para que Javascript muestre los resultados para cada línea. En la página, el usuario tendrá que seleccionar aquella línea que contenga el alimento con nutrientes que mejor se corresponda con el alimento de su receta. Hecho esto con cada alimento de una receta el usuario podrá obtener con un click una tabla con los valores de cada alimento y los valores totales de los nutrientes de la receta, de acuerdo con los cantidades empleadas.<br>

<div style='padding-left:10px;'><br>
<div style='color:#FFEFA0;'>Grupos y subgrupos:</div><br>
Hay 18 grupos. Cada uno tiene un número indeterminado de subgrupos según los haya creado (añadido o modificado) cada usuario. Los subgrupos son guardados en el archivo subgroups.bd a partir del archivo de datos bd.csv. Ese archivo se debe crear cada vez que se hagan modificaciones en la columna 1 del archivo bd.csv, o bien cuando se añada un nuevo alimento en una nueva línea o registro.<br><br>

En la página los grupos se muestran en números romanos I, II, ..., XVIII y con una etiqueta que alude a la clase de alimentos que va a clasificar. En el archivo de base de datos bd.csv los números romanos son sustituidos por números ordinarios, se eliminan las etiquetas, y se sigue cada grupo-número con dos puntos (:) y la etiqueta del subgrupo.

Vea los grupo:subgrupo actualmente presentes en el archivo bd.csv ejecutando en la línea de comandos lo siguiente:<br><br>
<span style='color:#FFEFA0;padding-left:10px;'>user@tron-telde:~/www/mesa/bd$</span> cat bd.csv | cut -d'|' -f1 | cut -d':' -f1-2 | grep "\S"
<br><br>
<div style='color:#FFEFA0;'><b>Descripción de cada Grupo:</b></div>
<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'><b>I Milk&Derivatives:</b></div>
<div style='padding-left:20px;'>La leche es un líquido secretado por las glándulas mamarias de las hembras de los mamíferos para nutrir a sus crías durante un período que comienza inmediatamente después del nacimiento. La leche es esencialmente una emulsión de grasa y proteína en agua, junto con azúcar disuelta (carbohidrato), minerales y vitaminas. Estos constituyentes están presentes en la leche de todos los mamíferos, aunque sus proporciones difieren de una especie a otra y dentro de las especies.
<br><br>
Las leches vegetales son suspensiones de material vegetal disuelto y desintegrado en agua, que tienen un aspecto similar a la leche de origen animal, pero no son productos lácteos. ​ Se elaboran a partir de ciertas variedades de frutos secos, cereales, legumbres y otras semillas, extrayendo el material vegetal en agua, separando el líquido y formulando el producto final, generalmente con adición de ingredientes para permitir su conservación y mejorar su sabor y sus propiedades nutricionales. La mayoría de estas bebidas carecen del equilibrio nutricional de la leche de vaca, son bajas en proteínas, grasas, calorías y hierro, y algunas tienen contenidos de proteínas y calcio extremadamente bajos.<br><br>
Forman parte de este grupo esos líquidos y todo alimento derivado de ellos, como el yogurt o el queso, así como aquellos a los que formando una mezcla se les añada como principal componente. Por ejemplo, son mezclas el café con leche, el arroz con leche, o el muesli con leche. No así pasteles u otros compuestos que contengan algo de leche, <b>porque su componente principal no es la leche</b>.<br><br>Conviene, por razones de comunicación y compartir registros que esta regla se cumpla, pero el usuario siempre tiene la última palabra.
<br><br>
<i><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Milk' target='blank_'>Milk</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Colostrum' target='blank_'>Colostrum</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Curd' target='blank_'>Curd</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Casein' target='blank_'>Casein</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Whey' target='blank_'>Whey</a><a style='color:#FFEFA0;padding-right:10px;' href='' target='blank_'>Cheese</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Butterfat' target='blank_'>Butterfat</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/List_of_dairy_products' target='blank_'>List of dairy products</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Plant_milk' target='blank_'>Plant milk</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Milk_substitute' target='blank_'>Milk substitute</a><a style='color:#FFEFA0;padding-right:10px;' href='https://en.wikipedia.org/wiki/Infant_formula' target='blank_'>Infant formula</a><a style='color:#FFEFA0;padding-right:10px;' href='' target='blank_'></a></i>

</div><br>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;font-weight:bold;'>II Eggs:</div>
<div style='padding-left:20px;'>Un huevo es un cuerpo redondeado de tamaño y dureza variables, que las hembras de diversos grupos de animales producen, y que sustenta y protege al embrión cuando el óvulo es fecundado,1​ convirtiéndose así en cigoto. Ponen huevos los vertebrados ovíparos, con poco o ningún desarrollo dentro de la madre, así como muchos invertebrados.<br><br>
Forman parte de este grupo todos los huevos y alimentos derivados de ellos, cualesquiera que sean los animales de los que procedan. Hay huevos de aves diversas, pero también de animales terrestres o marinos. El usuario debe valorar cuál ha de ser la fuente del nutriente principal, por ejemplo, la tortilla de patatas puede ser clasificada dentro de este grupo si el nutriente elegido es la proteína del huevo, pero puede ser clasificada dentro del grupo de féculas o almidones—VI Starchy roots&Tubers—que agrupa, por ejemplo, a las patatas.<br><br>

<i><a style='color:#FFEFA0;padding-right:10px;' href='https://es.wikipedia.org/wiki/Huevo_(biolog%C3%ADa)' target='blank_'>Huevos (Biología)</a><a style='color:#FFEFA0;padding-right:10px;' href='https://es.wikipedia.org/wiki/Huevo_(alimento)' target='blank_'>Huevos (Alimentación)</a><a style='color:#FFEFA0;padding-right:10px;' href='https://www.botanical-online.com/alimentos/huevos-tipos' target='blank_'>Clases de Huevos</a><a style='color:#FFEFA0;padding-right:10px;' href='https://www.institutohuevo.com/huevos-de-gallina-y-de-otras-especies-domesticas/' target='blank_'>Huevos de otras especies domésticas</a><a style='color:#FFEFA0;padding-right:10px;' href='https://www.mapa.gob.es/es/ministerio/servicios/informacion/huevas_tcm30-102458.pdf' target='blank_'>Huevas de pescado</a></i>


</div><br>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;font-weight:bold;'>III Fruits:</div>
<div style='padding-left:20px;'>Frutos son los ovarios maduros carnosos o secos de plantas con flores, que encierran la semilla o semillas. Por lo tanto, los albaricoques, los plátanos y las uvas, así como las vainas de frijol, los granos de maíz, los tomates, los pepinos y (en sus cáscaras) y las almendras son técnicamente frutas. Popularmente, sin embargo, el término se restringe a los ovarios maduros que son dulces y suculentos o carnosos.<br><br>
Por comodidad limitamos a este grupo sólo a aquellos alimentos que son «ovarios maduros carnosos o suculentos» llamados popularmente «frutas». Pueden ser más o menos dulces, pueden ácidos o neutros, tienen aromas y sabores que les caracterizan y suelen contener un alto porcentage de agua. Un criterio para incluir aquí algunas clasificadas como «Tropical Fruits» en otras clasificaciones es que encajen en alguno de los grupos distintos a «Special Fruits», y eso permita esperar que lo seleccionado tenga una estructura manejable mediante la misma técnica de pelado, corte, etc. Entre un coco y un plátano hay, según este último criterio, una gran diferencia siendo ambas clasiificadas como «Tropical Fruits».<br><br>
Las desecadas al aire o por alcohol pertenecen a este grupo pero no si se endulzaran. Así los jarabes o mermeladas pertenecen al grupo «VII Pasta&Sugars» y los zumos también se incluyen aparte, en el grupo «XIV Water&Drinks».<br><br>
<i><a style='color:#FFEFA0;padding-right:10px;' href='https://es.wikipedia.org/wiki/Fruta' target='blank_'>Frutas</a></i><a style='color:#FFEFA0;padding-right:10px;' href='' target='blank_'></a></i><a style='color:#FFEFA0;padding-right:10px;' href='' target='blank_'></a></i><a style='color:#FFEFA0;padding-right:10px;' href='' target='blank_'></a></i><br><br>
 Contamos con los subgrupos:<br><br>
<table style='width:100%'><tr><td><img style='width:25%;padding-right:10px;bakground-color:white;' src="bd/images/berry.png" align="left"><span  style='color:#FFEFA0;'><a style='color:#FFEFA0;' href='https://es.wikipedia.org/wiki/Baya' target='blank_'>Berries</a>:</span> Popularmente, las bayas son frutas jugosas altamente perecederas, pequeñas y con piel fina. Al comerlas ingerimos la piel y también las semillas, estas últimas no las digerimos y normalmente las defecamos. Ejemplos: uvas, fresas, moras, arándanos, frambuesas.<br>
<i><a style='color:#FFEFA0;padding-left:20px;padding-right:10px;' href='https://www.purewow.com/food/types-of-berries' target='blank_'>25 Berries</a><a style='color:#FFEFA0;padding-right:10px;' href='https://www.livescience.com/57477-why-are-bananas-considered-berries.html' target='blank_'>Berries (science)</a></i></td></tr><tr><td>Image: Thanks to Wikipedia (<a style='color:#FFEFA0;' href='https://creativecommons.org/licenses/by-sa/4.0/deed.es' target='blank_'>License</a>)</td></tr></table>
<br><br>

<table style='width:100%'><tr><td><img style='width:25%;padding-right:10px;' src="bd/images/Drupe_fruit_diagram-es.svg" align="left"><span style='color:#FFEFA0;'><a style='color:#FFEFA0;' href='https://es.wikipedia.org/wiki/Drupa' target='blank_'>Drupes:</a></span> Tienen una piel exterior que cubre una fruta suave y carnosa. En el centro tiene un único hueso duro que contiene la semilla. Ejemplos: cerezas, albaricoques, nectarinas, melocotones, ciruelas.</td></tr><tr><td>Image: Thanks to Wikipedia (Public domain)</td></tr></table>
<br><br>

<table style='width:100%'><tr><td><img style='width:25%;padding-right:10px;' src="bd/images/Pome_apples_text.jpg" align="left"><a style='color:#FFEFA0;' href='https://en.wikipedia.org/wiki/Pome' target='blank_'>Pomes</a>: Tienen un núcleo central que contiene semillas y está rodeado por una gruesa capa de pulpa. Algunos núcleos incluyen: manzanas y peras. Incluimos aquí otras, por ejemplo, el plátano, considerando que su parte central se ha reducido mucho hasta carecer de semilla, y su parte carnosa no ser ácida, como un «citrus», ni tener semillas diseminadas, como algunos «melon»—watermelon.</td></tr><tr><td>Image: Thanks to Wikipedia (<a style='color:#FFEFA0;' href='https://creativecommons.org/licenses/by-sa/4.0/deed.es' target='blank_'>License</a>)</td></tr></table>
<br><br>

<table style='width:100%'><tr><td><img style='width:25%;padding-right:10px;' src="bd/images/Orange_cross_section_description.png" align="left"><a style='color:#FFEFA0;' href='https://en.wikipedia.org/wiki/Citrus' target='blank_'>Cítrus:</a> Corteza exterior gruesa. Una fina membrana separa la carne en segmentos, y son característicamente ácidas. Por ejemplo: naranjas, mandarinas, limones, limas, pomelos, kumquats.</td></tr><tr><td>Image: Thanks to Wikipedia (<a style='color:#FFEFA0;' href='https://creativecommons.org/licenses/by-sa/4.0/deed.es' target='blank_'>License</a>)</td></tr></table>
<br><br>

<table style='width:100%'><tr><td><img style='width:25%;padding-right:10px;' src="bd/images/Melon_Sugar_Baby_Matisse-9953.jpg" align="left"><span  style='color:#FFEFA0;'><a style='color:#FFEFA0;' href='https://en.wikipedia.org/wiki/Melon' target='blank_'>Melons</a>:</span> Frutas grandes y jugosas con piel gruesa y muchas semillas. Por ejemplo: melón, sandía, yuca, mielada.</td></tr><tr><td>Image: Thanks to Wikipedia (<a style='color:#FFEFA0;' href='https://commons.wikimedia.org/w/index.php?curid=80526723' target='blank_'>By © Raimond Spekking / CC BY-SA 4.0 (via Wikimedia Commons</a>)</td></tr></table>
<br><br>

<table style='width:100%'><tr><td><img style='width:25%;padding-right:10px;' src="bd/images/ARS_tropical_fruit.jpg" align="left"><a style='color:#FFEFA0;' href='https://en.wikipedia.org/wiki/Category:Tropical_fruit' target='blank_'>Special Fruits:</a> Cultivadas en climas cálidos se consideran algo exóticas. Disponible en todo el mundo. Ejemplos: coco, piña, granada.<br><br>
</td></tr><tr><td>Image: Thanks to Wikipedia (<a style='color:#FFEFA0;' href='https://commons.wikimedia.org/wiki/Template:PD-USGov-USDA-ARS/i18n/es' target='blank_'>License</a>)</td></tr></table>





</div><br>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>IV Dry Grains:</div>
<div style='padding-left:10px;'>A grain is a small, hard, dry fruit (caryopsis)–with or without an attached hull layer–harvested for human or animal consumption. This group contains cereals and dry seeds of legumes also called pulses. Legumes other than pulses are contained in their pods and are tender. For example, a pea pod is a legume, but the peas inside the pod are pulses. For example, wheat, corn, rice, lentils, chickpeas, ... <br><br>

Cereals are herbaceous plants of the graminaceous family (with the exception of buckwheat) cultivated mainly for their grain. A pseudocereal or pseudograin is one of any non-grasses that are used in much the same way as cereals (true cereals are grasses). Pseudocereals can be further distinguished from other non-cereal staple crops (such as potatoes) by their being processed like a cereal: their seed can be ground into flour and otherwise used as a cereal.<br><br>

So we can make 3 subgroups: cereals (wheat, maize (corn), rice, barley, oat, sorghum, rye, millet), pseudocereals (amaranth, chia, quinoa, buckwheat), and pulses (beans, peas, and lentils).<br><br>

https://www.vegrecipesofindia.com/glossary-of-cereals-grains-in-english-and-hindi/
</div><br>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>V Vegetables&Mushrooms:</div>
<div style='padding-left:10px;'>fatty vegetable (olives), green vegetable, non-green vegetable, ...</div><br>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>VI Starchy roots&Tubers:</div>
<div style='padding-left:10px;'>potatoes, sweet potatoes, carrots, beets, turnips, ...</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>VII Flours&Pasta:</div>
<div style='padding-left:10px;'>Group 1, Group 2, Group 3, Group 4, Group 5, Group 6, Group 8, Group 9, Group 10, Group 13, Group 15, Group 17, Group 18</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>VIII Meat:</div>
<div style='padding-left:10px;'>cow, sheep, goat, reindeer, ...</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>IX Poultry:</div>
<div style='padding-left:10px;'>hen, chicken, duck, ...</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>X Finfish:</div>
<div style='padding-left:10px;'>ocean, rivers, lakes, farmed, ...</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XI Shellfish:</div>
<div style='padding-left:10px;'>Crustaceans (shell and legs): prawn, crab, crab, etc.<br>
Molluscs: w/shell: limpet, mussel, clam, etc., and no/shell: octopus, squid, cuttlefish, etc.<br>
Echinoderms: Urchin, Sea Cucumber<br></div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XII Oil&Fats:</div>
<div style='padding-left:10px;'>liquid, creamy, gelatinous, solid</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XIII Seeds&Nuts:</div>
<div style='padding-left:10px;'>walnuts, almonds, peanuts, soy</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XIV Water&Drinks:</div>
<div style='padding-left:10px;'>water, alcoholic</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XV Spices&Herbs:</div>
<div style='padding-left:10px;'>grains, powder, whole, chemical</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XVI Viscera&Sausages:</div>
<div style='padding-left:10px;'>liver, heart, kidney, brain, tongue, blood</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XVII Soups&Sauces:</div>
<div style='padding-left:10px;'></div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XVIII Baby&Formula:</div>
<div style='padding-left:10px;'></div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XIX Magic food:</div>
<div style='padding-left:10px;'></div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XX Dishes:</div>
<div style='padding-left:10px;'>Refers to the set of foods served for the main meals (breakfast, lunch and dinner)</div>

<div style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;padding-left:10px;'>XXI Snaks:</div>
<div style='padding-left:10px;'>Refers to combinations of a snack (any food 'usually' eaten between main meals) and a drink, both served as a single meal. This group does not refer to a single bite or a single glass, rather both are served together in combination. Its units are described individually in the groups '14:Water&Drinks, 8:Meat, or whatever'. Individually, a snack is typically 200 to 300 calories.<br><br>
Although each person's daily caloric intake is based on their personal goals and needs, nutrition experts estimate that the average daily intake at each meal should be broken down as follows: 300 to 400 calories for breakfast and 500 to 700 calories each for lunch, and dinner. But you can split up your main meals with just snacks and mixed drinks to get to those totals.</div><br>

<div>
<span style='color:#FFEFA0;margin-top:10px;margin-bottom:10px;'>How to change subgroups in work.csv</span><br>
	<span>Edit work.csv with LibreOffice Calc. In the 2nd column, change the name after the ':', and save the sheet. On the page, press the 'Update Database' button (upper left corner), and the message 'Update Database...' will be displayed next to it. Wait until the bash script finishes and the page shows the message 'Database update finished' (it will take 1.5-2 minutes, depending on the number of rows in work.csv).<br><br>
The script will backup the previous work.csv in the 'security folder'. The file name will be created with a timestamp and the file extension '.dbwork' (eg 1674009279.dbwork).  Epoch, or Unix timestamps, is the number of seconds that have passed since January 1, 1970, at 00:00:00 UTC.
	</span>
</div>
<span style='color:white'><br><br><br>
El comando, dentro de un script o serie de comandos, sumará los campos de vitaminas proporcionando un valor medio a cada complejo vitamínico y otros nutrientes, calculará totales de cada uno de ellos, etc.<br><br>

Para añadir un nuevo registro a la bd.csv debe usar la línea de comandos.</span><br>

</div>

<br><br>
<div>Javascript toma el dato del usuario y se lo entrega a PHP.<br> PHP dispara bash que 1. busca el dato en mesa.bd, y 2. le entrega los resultados a PHP.<br> PHP se los entrega a javascrip y éste presenta los resultados de bash al usuario.<br><br>

Javascript:<br>
function <span style='color:#FFEFA0'>jsToPHPtoBashToBD()</span> get user data for <span style='color:#FFEFA0'>scr/PHPtoBashtoBD.php</span> script file to run bash script <span style='color:#FFEFA0'>scr/bashToBD.scr</span><br><br>

PHP<br>
<span style='color:#FFEFA0'>scr/PHPtoBashToBD.php</span> script file to run bash script <span style='color:#FFEFA0'>scr/bashToBD.scr</span><br><br>

Bash<br>
<span style='color:#FFEFA0'>scr/bashToBD.scr</span> script to access the <span style='color:#FFEFA0'>bd/mesa.bd</span> file, read it, process the data, and output the results from <span style='color:#FFEFA0'>bd/results.tmp</span> to <span style='color:#FFEFA0'>scr/PHPtoBashToBD.php</span><br><br>

<a style='color:#FFEFA0' href='https://www.fao.org/economic/the-statistics-division-ess/methodology/methodology-systems/crops-statistics-concepts-definitions-and-classifications/en/' target='_blank'>Fuente para el menú</a><br><br>
<a style='color:#FFEFA0' href='file>://home/pere/www/TheLady/src/txt/fs_food-improvement-agents_guidance_1333-2008_annex-2.pdf' target='blank'>hhhhh</a><br><br>
</div></div>


<div style='font-size:12px;color:#FFEFA0;cursor:pointer;' onclick="showHide('instrucciones')">⇅ <b>Info</b></div>
<div style='display:none' id='instrucciones'><br>
For the manual<br>
En tanto mejora the DB (works.csv), al añadir los nutrientes a su receta si un alimento 'no existe' en su DB puede usar 'alimentos equivalentes'. En Internet y chatGPT no es difícil averiguar los componentes más importantes. insertando valores para P, HC, Fat, and may be more items. Por ejemplo, chatGPT:
Can you tell me the quantitative composition table of 100 g of mochiko rice flour (asian rice)?
Response<bR>
Yes, I can provide you with the quantitative composition table for 100 g of mochiko rice flour:<bR><bR>

Calories: 366<bR>
Total Fat: 0.3 g<bR>
Saturated Fat: 0.1 g<bR>
Trans Fat: 0 g<bR>
Cholesterol: 0 mg<bR>
Sodium: 8 mg<bR>
Total Carbohydrates: 85 g<bR>
Dietary Fiber: 1 g<bR>
Sugars: 0 g<bR>
Protein: 6 g<bR><br>
Can you tell me the quantitative vitamins and minerals of 100 g of mochiko rice flour (asian rice)?<br>
Response:<br>
Calcium: 6 mg<br>
Iron: 1.1 mg<br>
Magnesium: 22 mg<br>
Phosphorus: 89 mg<br>
Potassium: 76 mg<br>
Sodium: 8 mg<br>
Zinc: 1.1 mg<br>
Copper: 0.2 mg<br>
Manganese: 1.1 mg<br>
Selenium: 14.5 mcg<br>
<br><br>
Comandos bash:<br>
cat bd.csv | cut -d'|' -f1,11 | grep 'i:*cream'<br><br>
cat bd.csv: Usar 'todo' el contenido del archivo bd.csv.<br>
| cut -d'|' -f1,11: Seleccionar sólo las columnas 1 y 11, todas separadas por '|'.<br>
 | grep 'i:*cream': Del resultado anterior seleccionar sólo aquellas filas que contengan «i:», seguido de cualquier serie de caracteres «*», y de «cream».


<br><br>
I Leche&Derivados (Milk&Derivatives)
<div style='padding-left:10px'>
Milk: Cow, Sheep, Goat, Mare, Camel, Yak, Buffalo, Donkey, Moose, Reindeer, Mithun, Other<br>
Cheese<br>
Yogurt<br>
Cream<br>
Butter<br>
Margarine<br>
Ghee<br>
Milkshake<br>
Curd<br>
Whey<br>
Buttermilk</div><br>

II Huevos (Eggs)
<div style='padding-left:10px'>egg white, egg yolk</div><br>
III Frutas&Bayas (Fruits&Berries)
<div style='padding-left:10px'></div><br>

IV Cereales&Granos de Legumbres (Cereals&Dry Legume Grains (pulses, legume seeds)
<div style='padding-left:10px'>Los cereales son, con diferencia, el grupo de cultivos más importante. Los carbohidratos, principalmente almidones, son el elemento nutritivo dominante en los cultivos de cereales. También contienen una cantidad modesta de proteína y poca grasa. El contenido de humedad es bajo.<br><br>
Proceden de plantas anuales, generalmente de la familia de las gramíneas, que producen granos que se utilizan para alimentos, piensos, semillas y fines industriales, por ejemplo, etanol. Excluyen las leguminosas, como las legumbres, pero incluyen el arroz, el alpiste, el trigo sarraceno y el triticale. Se ha recomendado que la denominación de "cultivos de cereales" se limite a los cultivos cosechados para grano seco únicamente, excluyendo, por tanto, los cultivos cosechados en verde para forraje, ensilaje, pastoreo, etc.; y, en el caso del maíz, cosechado en verde, también para alimento.
<br><br>
En la alimentación humana las <span style='color:#FFEFA0'>granos de legumbre</span> proceden de especies que producen <span style='color:#FFEFA0'>granos o semillas secas</span>—<u>no son cereales</u>. Las semillas <span style='color:#82E0AA'>verdes y tiernas</span> son clasificadas entre los <span style='color:#82E0AA'>vegetales</span>—judías verdes, guisantes verdes, etc., como una legumbre entera (hojas, tallo, y cápsula) Se excluyen las semillas usadas mayormente para extraer aceite—cacahuete, soja, etc.— y aquellas destinadas a la siembra—alfalfa, trébol, etc.</div><br>

V Hortalizas&Hongos (Vegetables&Mushrooms—Including Green legumes)
<div style='padding-left:10px'>
Frutos: Berenjena y pimientos.<br>
Legumbres (pods): judías verdes, guisantes verdes, etc. (chickpeas, clovers, cowpeas, kidney, lentils, mung beans, peanuts, peas, pigeon peas, soy beans)<br>
Bulbos: Ajo, cebolla, puerro, chalota, etc.<br>
Coles: Repollo, brécol, coles de Bruselas y coliflor.<br>
Hojas y tallos tiernos: Acelga, achicoria, borraja, cardo, endibias, escarola, espinacas y lechuga.<br>
Inflorescencia: Alcachofa.<br>
Pepónides: Calabacín, calabaza y pepino.<br>
Raíces: Nabo, rábanos, remolacha de mesa y zanahoria.<br>
Tallos jóvenes: Apio, espárrago blanco y triguero.<br>
Hongos: Setas, champiñones.</div><br>

VI Raíces&Tubérculos (Starchy roots&Tubers—Polisacáridos)
<div style='padding-left:10px'>
Generalmente sus cultivos son anuales y producen raíces, tubérculos, rizomas, cormos y tallos, con alto contenido de <b>almidón o fécula (polisacárido) y agua</b> . <i>Se excluyen los cultivos principalmente destinados a la alimentación animal, a la industria azucarera (remolacha azucarera), o las especies clasificadas como "hortalizas de raíz, bulbo y tubérculos" (cebollas, remolachas).</i> Sí se incluyen la médula y la harina amiláceas que se derivan de ella y que están contenidas en el tronco de la palma de sagú y en el tallo del plátano abisinio (Musa ensete).<br><br>
Patata, Batata, Otras.
</div><br>

VII Azucar&Miel (Sugar&Honey—Mono y disacáridos)
<div style='padding-left:10px'>A diferencia de los cereales, las legumbres y los tubérculos, el componente principal de los cultivos de azúcar no es el almidón sino los monosacáridos simples (glucosa y fructosa) y, en particular, los disacáridos (sacarosa o sacarosa). El contenido de proteínas y grasas es insignificante.<br><br>

Los cultivos de azúcar son dedicados principalmente a la fabricación de azúcar, en segundo lugar a la producción de alcohol (alimentario y no alimentario) y etanol. Hay dos cultivos azucareros principales: la remolacha azucarera y la caña de azúcar. La caña de azúcar es una hierba perenne y la remolacha azucarera es anual. El azúcar y los jarabes también se producen en América del Norte a partir de la savia de ciertas especies de árboles de arce y, en algunos países, del maíz y el sorgo, que son principalmente cultivos de cereales, excepto el sorgo dulce, cuando se cultiva explícitamente para hacer jarabe.</div><br>

VIII Carnes (Meat)
<div style='padding-left:10px'>
Mamíferos (mammal), Aves, Reptiles/Amfibios, Insectos, Otros</div><br>

IX Carnes (Poultry)
<div style='padding-left:10px'>
Aves: Chicken, Hen, Turkey, Duck, Goose, Other</div><br>

IX Pescados (Finfish)
<div style='padding-left:10px'>Peces
</div><br>

X Mariscos (Shellfish)
<div style='padding-left:10px'>
Crustáceos (caparazón y patas): langostino, cangrejo, buey de mar, etc.<br>
Moluscos: <u>c/concha:</u> lapa, mejillón, almeja, etc. y <u>s/concha</u>: pulpo, calamar, sepia, etc.<br>
Equinodermos: Erizo, pepino de mar</div><br>

XI Aceites&Grasas (Oil&Fats)
<div style='padding-left:10px'></div><br>

XII Nueces&Semillas (Nuts&Seeds)
<div style='padding-left:10px'>Las nueces son frutos de árboles, en general se conocen como «frutos secos». Se caracterizan por sus cáscaras leñosas o duras cuyo peso del total del fruto varía desde un 20% en el caso de las castañas hasta un 70% en el caso de los anacardos.<br><br>

Se excluyen los utilizados para aromatizar bebidas, los frutos masticatorios, los estimulantes, y los utilizados para la extracción de aceite o mantequilla. También se excluyen las nueces de areca/betel, las nueces de cola, las nueces de illipe, las nueces de karite, los cocos, las nueces de tung, las nueces de palma de aceite, etc.</div><br>

XIII Aguas&Gaseosas&Alcoholes
<div style='padding-left:10px'></div><br>

XIV Especias&Hierbas (Spices&Herbs)
<div style='padding-left:10px'></div><br>

XV Alimentos exóticos (Exotic food, Miscellany)
</div>
<div style='padding-left:10px'></div><br>
</div>
</div>

<br><br><br><br>
</body>
</html>

<script>
window.document.title="Nutrients";
document.getElementById('search1234').style.innerHTML='<button style="width:110px;" onclick="search1234()">Search 1,2,3,4</button>';

//document.getElementById('addtodatabase').style.visibility='hidden';
document.getElementById('calculatefood').style.visibility='hidden';

document.getElementById('f2').innerHTML = 'Woman'
document.getElementById('f3').innerHTML = 'Life'
document.getElementById('f22').innerHTML = ''
document.getElementById('f23').innerHTML = ''
document.getElementById('f24').innerHTML = ''
document.getElementById('f25').innerHTML = 'Freedom'

document.getElementById('resultsMenu').innerHTML = ''
document.getElementById('regLines').innerHTML = ''
document.getElementById('editableRecipe').value='\n'
document.getElementById('f4').innerHTML = "<span style='color:white;font-weight:bold;'>Remember</span>: You must write in this row to fill the cell 4 content. The content of this top row is sent to Bash. The content of the '4 Plus-words' cell is merely indicative
</span>"

//alert('Learn in three lines how to get started\n' + '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0' + 'Click on the \'Tutorial\'  below')
</script>

<script>

// Function to remove fragment identifier and refresh the page from the top
function removeFragmentAndRefresh() {
  if (window.location.hash) {
    var newUrl = window.location.href.split('#')[0];
    window.location.replace(newUrl);
  }
}

// Call the function to remove the fragment and refresh
removeFragmentAndRefresh();
</script>
<div id='phrases'>
<?php echo exec("echo $(cat deepblue.phr)"); ?>
</div>
</body>
</html>
