<?php
$dataBD=exec("echo $(./findId4.scr " . $_POST['group'] . ")");
echo $dataBD;
?>
