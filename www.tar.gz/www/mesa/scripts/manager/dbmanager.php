<?php

if (isset($_POST['WtoD'])) {
    $command = $_POST['WtoD'];
    $output = shell_exec("./dbManager.scr $command 2>&1");
    echo "$output";
} else {
    echo "No 'group' parameter provided.";
}

?>
