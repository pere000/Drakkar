<?php
// Set Content Security Policy headers
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';");

// Set Content-Type header
header("Content-Type: text/html; charset=UTF-8");
?>
<!DOCTYPE html>
<html><head>
<title>Manager</title>
<link rel="stylesheet" href="../normalize.css">

<style>
body {
width:95%;background-color:lightgray;color: navy;font-size: 12px;
font-family: "Verdana", sans-serif;
}
html *
{
   font-family: normal 12px sans-serif, Verdana, Arial; !important;

}

.container {
  width: 100%; /* Ensure the container takes up the full width */
  overflow: hidden; /* Clear any float and prevent overflow issues */
}

.box {
  width: 100%;
  box-sizing: border-box;
  float: left; /* Use float to position boxes side by side */
  /* You can also use display: inline-block; with vertical-align: top; if you prefer */
}
.tooltip {
    position: relative;
    cursor: pointer;
}

.tooltip::after {
    content: attr(data-tooltip);
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 5px;
    border-radius: 3px;
    font-size: 12px;
    white-space: nowrap;
    visibility: hidden;
    opacity: 0;
    transition: visibility 0s, opacity 0.3s ease;
}

.tooltip:hover::after {
    visibility: visible;
    opacity: 1;
}


</style>

<script>
//why doesn't it work?
function policy() {
var vf1 = document.getElementById('f1').value;
var vf5 = document.getElementById('f5').value;
var vf6 = document.getElementById('f6').value;
var vtree = document.getElementById('tree').innerHTML;
if (!vf6){
document.getElementById('mss').innerHTML = "Canceled: <span style='color:navy'>F6 cannot be blank'.</span>";
exit
}
var extensionF6 = vf6.split('.').pop(); // Get the extension part of the value
var pattern = /^(db|csv|txt)$/; // Define the pattern for the extension
if (!pattern.test(extensionF6)) {
document.getElementById('mss').innerHTML = "Canceled: <span style='color:navy'>F6 extension must be 'db, csv, or txt'.</span>";
exit;
}
if (vf5){
var extensionF5 = vf5.split('.').pop(); // Get the extension part of the value
var pattern = /^(db|csv|txt)$/; // Define the pattern for the extension
if (!pattern.test(extensionF5)) {
document.getElementById('mss').innerHTML = "Canceled1: <span style='color:navy'>F5 extension must be 'db, csv, or txt'.</span>";
exit;
}
}



pattern = /^[0-9]+$/;
if (vf1){
//f1 filled
	if (!pattern.test(vf1)) {
	document.getElementById('mss').innerHTML = "Canceled: <span style='color:navy'>F1 must be numeric.</span>";
	exit;
	}

	if (vf5){
	//F5 NOT Blank
		if (!vtree.includes(vf5)) {	//if (!vtree.includes(vf5)) {
		//F5 NOT tree
			document.getElementById('mss').innerHTML = "Canceled. <span style='color:navy'>Only F6 can <u>Create</u> a file (111). You can <u>Rename</u> '"+vf6+"' (011).</span>";
		exit
		}

		//F5 TREE
			if (vtree.includes(vf6)) {
			//F6 TREE
				document.getElementById('mss').innerHTML = "Last requirement: Record replacement.";
			}
			else
			{
			//F6 NOT tree
				document.getElementById('mss').innerHTML = "Last requirement: creating new file and adding data.";
			}
	}
	else
	{
	//F5 blank
		if (vf1 === '0000000000'){
document.getElementById('mss').innerHTML = "Canceled: <span style='color:navy'>Record deletion of IC '0000000000' is not allowed. The file deletion via '001' is an option.</span>";
exit
		}
		if (vtree.includes(vf6)) {
		//F6TREE
			document.getElementById('mss').innerHTML = "Last requirement: Record deletion.";
		}
		else
		{
		//F1+F6NOTtree
			document.getElementById('mss').innerHTML = "Canceled: <span style='color:navy'>Deletion limited to filenames in collections.</span>";
		}
	}
}
else
//fi blank
{

	if (!vtree.includes(vf6)) {
	//F6 TREE?
	document.getElementById('mss').innerHTML = "Canceled1: <span style='color:navy'>The F6 file must exist in Collections to be renamed or deleted.</span>";
	exit
	}

	if (vf5){
	//RENAME 011
		if (extensionF6 !== extensionF5){
			document.getElementById('mss').innerHTML = "Canceled: <span style='color:navy'>F5 and F6 extensions must be the same.</span>";
		exit
		}
		if (vf5 === vf6){
			document.getElementById('mss').innerHTML = "Canceled: <span style='color:navy'>New 1L file has been created</span>";
		//exit
		}
	}
}	//f1 end
}  //End function


function creaDel(WtoD){

verifyString();policy()
document.getElementById('mss').innerHTML=''
notAllowed=document.getElementById('f6').value+document.getElementById('f5').value
if (notAllowed== ''){
	document.getElementById('mss').innerHTML="Both, F5 and F6 can not be empty. 'Process Data' not allowed";exit;}
toLoad=WtoD.split('|')

    var formValues=''
    for (i=1;i<12;i++){
    formValues=formValues+'|'+document.getElementById('f'+i).value;
    }
    formValues=formValues.slice(1)

    if (toLoad[0] == 'add'){
        formValues=formValues.split('|')
        formVal=formValues.join('|');
        sendstr='"'+formVal+'"'
        toSend=sendstr
    }

var hr = new XMLHttpRequest();
var toForm;

hr.onreadystatechange = function () {
    if (hr.readyState == 4) {
        if (hr.status == 200) {
            var return_data = hr.responseText.trim(); // Remove leading and trailing whitespaces
           // alert(return_data)
				document.getElementById('mss').innerHTML=return_data
		            document.getElementById("result").value = return_data;
		            //alert('createDel: '+return_data)
		            fn='0000000000 '+document.getElementById('f6').value
		            if (fn !== ''){sendForTree(fn)}
		            //alert(fn)

        } else {
            alert('Failed to retrieve data');
        }
    }
};

// Set up the POST request
hr.open('POST', 'dbmanager.php', true);

// Set the appropriate headers for a POST request
hr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

// Set the data to be sent in the POST request
var postData = 'WtoD='+WtoD+'@'+toSend; // Replace with your actual data
	hr.send(postData);
}

var clipBoardContent=''
var rawRecord22=''
function gridResult() {
		let rawRecord11=''
		let rawRecord1=''
navigator.clipboard.readText().then(text =>
    {
        document.getElementById('result').value = text;
        var pipeOccurrences = document.getElementById('result').value.split('|').length;
        if (pipeOccurrences !==48){alert('The strip is malformed. '+pipeOccurrences)}

        let rawRecord=document.getElementById('result').value.trim()
        if (rawRecord == '')
	        {
	        document.getElementById('result').value=rawRecord22
	        return
	        }
        rawRecordArr=rawRecord.split('|')

		            rawRecord1=rawRecord
                // Input the grid elements
		            for (var i = 0; i < 10; i++) {
		            id= 1 + i
		            document.getElementById('f'+id).value= rawRecordArr[i]	//id=1-10
		            rawRecord1=rawRecord1+'|'+rawRecordArr[i]
		            }

		        // Build the nutrients strip
		            for (var i = 10; i < 48; i++) {
		            rawRecord11 = rawRecord11+'|'+rawRecordArr[i]
		            }
                // Input the nutrients strip
			        document.getElementById('f11').value = rawRecord11.slice(1)
            		document.getElementById('result').value=rawRecord
    });
}

async function toClipboard(theId) {
    const inputElement = document.getElementById(theId);
    if (!inputElement) {
        alert(`Element with ID '+theId+' not found.`);
        return;
    }

    const clipBoardContent = inputElement.value.trim();
    if (!clipBoardContent) {
        alert(`Content in element '+theId+' is empty.`);
        return;
    }

    try {
        await navigator.clipboard.writeText(clipBoardContent);
        //alert('Content copied to clipboard: '+clipBoardContent);
    } catch (error) {
        alert('Error copying to clipboard: '+error);
    }
}


function verifyString(){
document.getElementById('mss').innerHTML=''
//document.getElementById('f4').value='';
theF1=document.getElementById('f1').value.trim();theF6=document.getElementById('f6').value.trim();theF5=document.getElementById('f5').value.trim();
theF2=document.getElementById('f4').value.trim();theF3=document.getElementById('f3').value.trim();theF10=document.getElementById('f10').value.trim();
//alert('entra')
var regexpPattern = /^[a-zA-Z0-9]+[\w:]*\.[a-zA-Z0-9]+$/;

theFT=theF5+theF6
if ( theF1 == '' && theFT == '' ){
	document.getElementById('mss').innerHTML="F1+F5+F6: Search. Not implemented";
	return}

//F1 is empty	=> Delete or create files
if (theF1 == ''){

	//Delete file
	if (theF6 == ''){
		if (theF5 !== '') {
			document.getElementById('mss').innerHTML='010: Use F6 to delete files or F5+F6 to rename files.'
			}
		return}

	//Delete file
	if (theF5 == ''){
		if (!regexpPattern.test(theF6)) {document.getElementById('mss').innerHTML="F6 is not a valid file name. 'Process Data' not allowed";
		return}

		stdFX=theF6.split('.');stdFX=stdFX[1]
	   if (stdFX == 'db'){document.getElementById('f4').value='0100';}
	   if (stdFX == 'csv'){document.getElementById('f4').value='0010';}
	   if (stdFX.trim() !== 'db' && stdFX.trim() !== 'csv'){
			document.getElementById('f4').value='0001';}

	document.getElementById('mss').innerHTML='001: F6 file will be deleted if it has not a child file.';
	return}

	if (theF6 !== ''){
	//Create
		if (theF5 !== '' && theF6 !== ''){
		if (!regexpPattern.test(theF6)) {document.getElementById('mss').innerHTML="F6 is not a valid file name. 'Process Data' not allowed";return}
		if (!regexpPattern.test(theF5)) {document.getElementById('mss').innerHTML="F5 is not a valid file name. 'Process Data' not allowed";}
	stdF6=theF6.split('.');stdF6=stdF6[1]
	stdF5=document.getElementById('f5').value.split('.');
	   if (stdF6 == 'db'){document.getElementById('f4').value='0100';}
	   if (stdF6 == 'csv'){document.getElementById('f4').value='0010';}
   if (stdF6.trim() !== 'db' && stdF6.trim() !== 'csv' && stdF6.trim() !== ''){document.getElementById('f4').value='0001';}

	document.getElementById('mss').innerHTML="011 Rename F6 to F5: If "+theF6+" doesn't exist it will be created under "+theF5+".";
	return}
	}	//end F5 blank
return
}	//End F1 blank
else
{
//if F1 filled	=> Delete, replace or delete a record
	if (theF5.trim() !== '' && theF6 == ''){
	document.getElementById('mss').innerHTML="110: Not implemented";
	return}

	//only F6 is filled ==> new record action
	if (theF6.trim() !== '' && theF5 == ''){
		if (!regexpPattern.test(theF6)) {document.getElementById('mss').innerHTML="101: F6 is not a valid file name. 'Process Data' not allowed";return}
		if (theF1 == '0000000000'){document.getElementById('mss').innerHTML="Deleting F1 record will orphan other files. 'Process Data' not allowed.";return}

		stdF6=theF6.split('.');
		stdF6=stdF6[1]
	   if (stdF6 == 'db'){document.getElementById('f4').value='0100';}
	   if (stdF6 == 'csv'){document.getElementById('f4').value='0010';}
	   if (stdF6.trim() !== 'db' && stdF6.trim() !== 'csv'){document.getElementById('f4').value='0001';}

		document.getElementById('mss').innerHTML="101: Delete record in the F6 file if the record ID is not 0000000000.";
	return}

	//Both, F6 and F5 are filled ==> record replacement
	if (theF5.trim() !== '' && theF6 !== ''){
		if (!regexpPattern.test(theF6)) {document.getElementById('mss').innerHTML="F6 is not a valid file name. 'Process Data' not allowed";return}
		if (!regexpPattern.test(theF5)) {document.getElementById('mss').innerHTML="F5 is not a valid file name. 'Process Data' not allowed";return}
	stdF6=theF6.split('.');stdF6=stdF6[1]
	stdF5=document.getElementById('f5').value.split('.');
	   if (stdF6 == 'db'){document.getElementById('f4').value='0100';document.getElementById('f5').value=document.getElementById('f6').value
	   }
	   if (stdF6 == 'csv'){document.getElementById('f4').value='0010';document.getElementById('f5').value=stdF5[0]+'.db'
	   }
	   if (stdF6.trim() !== 'db' && stdF6.trim() !== 'csv' && stdF6.trim() !== ''){
			document.getElementById('f5').value=stdF5[0]+'.csv';
			document.getElementById('f4').value='0001';}

			document.getElementById('mss').innerHTML="111: Update the record ID data in F6 file or add it if the record ID doesn't exist; create the files needed to build the branch.";
			return
	}
}
}

var fn=''
function sendForTree(sft) {
	var hr = new XMLHttpRequest();
    var url = "getTree.php";
    fn = sft;

    hr.open('POST', url, true);
    hr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    var postData = 'flop=' + fn;
//alert('postData: ' +postData)
    hr.onreadystatechange = function() {
        if (hr.readyState == 4) {
            if (hr.status == 200) {
	            var return_data = hr.responseText.trim();
						// Find the index of '@' in the string
						var atIndex = return_data.indexOf('@');

						// Extract the substrings before and after '@'
						var part1 = return_data.substring(0, atIndex);
						var part2 = return_data.substring(atIndex + 1);

					document.getElementById('tree').innerHTML = part1;
					document.getElementById('filesContents').innerHTML = part2;

        } else {
            alert('Failed to retrieve data. Status: ' + hr.status);
        }
    }
    }
    hr.send(postData);
}


function loadGrid(clicked){
document.getElementById('result').value=clicked
//alert(clicked)
toForm=clicked.split('|')
                        for (var i = 0; i < 10; i++) {
                        id=1 + i;
                          document.getElementById('f'+id).value = toForm[i];
                        }
                        accum=''
                        for (var i = 10; i < 48; i++) {
                            accum=accum+'|'+toForm[i]
                        }
                            document.getElementById('f11').value = accum.slice(1);
                            document.getElementById('mss').innerHTML = '';

}
</script>
</head><body>
<div id='resultsMenu'></div>
<div style='width:100%;font-family:satisfy;text-align:center;font-size:40px;text-shadow: 1px 1px 2px green, 0 0 1em green, 0 0 0.2em green;padding-left:5%;cursor:pointer;' translate="no"><span style='color:red;text-shadow:1px 3px 2px green'>༺ </span>  <span onclick="messageRefresh()">Drakkar Manager</span>  <span style='color:red;text-shadow:1px 3px 2px green'> ༻</span> <span style='font-family:normal;font-size:12px;color:red;'> <i>... share Freedom, release Rights</i></span></div>

<div style='width:100%;font-family:satisfy;text-align:center;font-size:14px;text-shadow: 1px 1px 2px green, 0 0 1em blue, 0 0 0.2em green;'>Recipes Records Manager</div>

<div id='form' style='width:100%;display:block;margin-left:10px;margin-top:20px;'>
<span id='a1' style='display:none;font-size:18px;font-weight:bold;color:blue;'>▲
<span style='font-size:12px;cursor:pointer;padding-left:1px;' onclick="if (document.getElementById('mess').style.display == 'none'){document.getElementById('mess').style.display='block';document.getElementById('a1').style.display='block';document.getElementById('a2').style.display='none';}else{document.getElementById('mess').style.display='none';document.getElementById('a1').style.display='none';document.getElementById('a2').style.display='block';}">HowTo</span>
<span id='a' style=''>▼
<span style='font-size:12px;cursor:pointer;'>App Configuration</span></span></span><span id='a2' style='display:block;font-size:19px;font-weight:bold;color:blue;'>▼<span style='font-size:12px;cursor:pointer;' onclick="if (document.getElementById('mess').style.display == 'none'){document.getElementById('mess').style.display='block';document.getElementById('a2').style.display='none';document.getElementById('a1').style.display='block';}else{document.getElementById('mess').style.display='none';document.getElementById('a2').style.display='block';document.getElementById('a1').style.display='none';}">HowTo</span><span id='a' style=''>▼<span style='font-size:12px;cursor:pointer;'>App Configuration</span></span></span>
</div>
<div id='mess' style='margin-left:30px;display:none;text-align:justify;color:black;'>

<span style='color:green;'>Hello!</span>.<br><br>For beginners, click on "HowToDb' in the "Collections" list at the bottom. On its right, click on its "Card Identity' number: "0000000000". This is the main record and its description field says: "Anything achievable is a recipe (Trikonic)". Finally, once the card is shown click on its Provider (F9) title.<br><br>We have just began.



<br><br><br><br>
</div>


	<div id='manual' style='display:none;text-align:justify;margin-top:10px;'>
		<span style='color:maroon;font-weight:bold;'>All Food (Stem)</span>: This is a label indicating any file containing all the records (one record per food) from an original database provider. Each file has the file extension '.db' and follows the 'standard '0100'. Every file serves as a parent database containing records with a unique set of nutrients. They are primarily designed for use with different database providers, each with its native RegExp ID formulas that generally vary from one provider to another. However, the same database (.db) can be used with incompatible branches (.csv).<br>
		<span style='color:maroon;font-weight:bold;'>Food Class</span>: This is a label that indicates that the file contains a collection of records (included in its 'Stem') for a given class of cooked foods. Each file has the file extension '.csv' and follows the 'standard '0010'.<br>
		<span style='color:maroon;font-weight:bold;'>Cooked Foods</span>: This is a label indicating that the file contains a collection of records of cooked foods made with foods from its 'Food Class'. Each record depends on some culinary recipe, but can not repeat their culinary nutrients set (unique food). Each file has the file extension '.txt' and follows the 'standard '0001'.</br>
		<span style='color:maroon;font-weight:bold;'>Free Flavours Station</span>: This is a label indicating that the file contains a collection of records of cooked foods made with foods from different sources (Food Classes) Each record depends on some culinary recipe, but can contain records with the same culinary nutrients set (same food, different flavors, colors, treatment, etc.). Each file has the file extension '.free' and follows the 'standard '00<span style='color:red;font-weight:bold;'>1</span>1'. This is a label designed mainly for beverages, verbi gratia for mineral waters.</br>
		<span style='color:maroon;font-weight:bold;'>Load, Create, and Delete a file or Modify its standard</span>:<br>Click the file name to upload it (<span style='color:maroon;font-weight:bold;'>Load</span>). After uploading, click “Delete” to delete (<span style='color:maroon;font-weight:bold;'>Delete</span>) or after making necessary changes—App File Requirements—click “Create” (<span style='color: maroon;font-weight:bold;'>Create</span>)  or simply overwrite by clicking “Replace” button (<span style='color:maroon;font-weight:bold;'>Modify</span>).</br>
	</div>


<div id="requirements" style='display:none'>
    <div style='text-align:justify;'>
    App File Requirements:<br>
        <span style='color:green;'>Example dishes.csv: 0000000000|0:various|WWEIA|0010|wweia.db|dishes.csv|matportalen.no|^([0-9]+(\.[0-9]+)?)$|00.000|Creole American meals|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0</span>
            <table style='width:100%;font-size:12px;'>
                <tr style='color:maroon;'><td>Collection Group:Subgroup (F2)</td><td>Collection Tag (F3)</td><td>Collection Standard (F4)</td><td>DB parent (F5)</td><td>DB Filename (F6)</td><td>Provider URL (F7)</td><td>Collection RegExp Formula (F8)</td><td>Provider ID(F9)</td><td>Collection Description (F10)</td></tr>
                <tr style='color:green;'><td>0:various</td><td>WWEIA</td><td>0010</td><td>wweia.db</td><td>dishes.csv</td><td>matportalen.no</td><td>^([0-9]+(\.[0-9]+)?)$</td><td>00.000</td><td>Creole American dishes WWEIA 5:Mexican</td></tr>
            </table>
    <u>You should not touch</u>:<br>
        0000000000, because it is the ID number for this class of records in any file.<br>
        0|0|0 ... 0|0|0, because although these types of records do not have established nutrients, they are necessary to match patterns.<br><br>
    When you click on a file name, its 'Requirements' record (0000000000) is loaded and its fields values ​​are placed in the form cells.<br>To create a new DB file, you basically need to change only F6 (new file name) and F10 (its description).<br><br>
    The 'Collection Tag' can only be modify for the 'Free Flawors' files. In other cases the page does not work.<br>
    The 'Collection Tag' which is not from the NFSA DB is always from any DB, i.e. 'WWEIA'. No other DB than that provided by the NFSA has been tested.<br>
    There is no need to modify the 'Collection RegExp Formula'. This stage of application has not yet been developed to use another RegExp formulas for another providers IDs, so mesa.php will not be able to handle those records and will fail.
    </div>
</div>
 <table style='font-size:11px;width:100%;margin:0 auto;'>
<tr>
	<td style='color:green;font-weight:bold;text-align:right;'>F1 Filled</td>
	<td style='background-color: navy;color:white;'>Add, replace or delete <b>a record</b></td>
	<td style='color:green;font-weight:bold;text-align:right;'>F1 Blank</td>
	<td style='background-color: navy;color:white;'>Create or delete <b>a file</b> or search strings in records</td>
</tr>
<tr>
	<td style='text-align:right;'><u>F5 and F6 filled</u></td>
	<td style='background-color: navy;color:white;'>111: Update or add data to F6; files are created to build the branch if needed.</td>
	<td style='text-align:right;'><u>F5 and F6 Filled (<span style='color:red;font-weight:bold;'>Clear F1</span>)</u></td>
	<td style='background-color: navy;color:white;'>011: Rename file F6 to file name F5</td>
</tr>
<tr>
	<td style='color:red;font-weight:bold;text-align:right;'>F5 Blank <span style='color:black'>(<i>select and cut</i>)</span></td>
	<td style='background-color: navy;color:white;'>101: <b>Delete record ID data</b> in the F6 file if the record ID is not 0000000000.</td>
	<td style='color:red;font-weight:bold;text-align:right;'>F5 Blank <span style='color:black'>(<i>select and cut</i>)</span></td>
	<td style='background-color: navy;color:white;'>001: <b><i>Delete F6 file</i></b> if it hasn't a child</td>
</tr>



</table><br>

    <div class="box" id="box1" style='background-color:lightyellow;'>
        <table style='width:100%;font-size:12px;'>
            <tr style='font-weight:bold;background-color:lightgray;text-align:center;color:green;'>
                <td colspan='6'>Records Grid</td>
            </tr>
            <tr style='color:maroon;font-weight:bold;'>
                <td style='width:15%;' style='background-color:lightgray;'>

<input type='button' value='New ID' style='margin-right:15px;' onclick="document.getElementById('f1').value=Math.floor(Date.now() / 1000)">Record ID (F1):</td>
                <td style='text-align:left;'><input type='text' id='f1' style='width:100%;border:none;background-color:#F4ECF7;' oninput="verifyString()" onclick="verifyString()"></td>
                <td id='mss' style='text-align:left;' colspan='4'></td>
            </tr>
            <tr style='color:maroon;font-weight:bold;background-color:yellow;'>
                <td style='width:12%;'>Destination (F6)</td><td style='width:12%'>Parent (F5)</td>
<td style='width:15%;cursor:pointer;' onclick="window.open('http://'+document.getElementById('f7').value);">Remote-File1 (F7) *</td><td style='width:12%'>Group:Subgroup (F2)</td><td style='width:15%'>Label-Tag (F3)</td><td style=''>Description-Variables (F10)</td></tr>
            <tr>
                <td><input type='text' id='f6' style='width:100%;border:none;background-color:#F4ECF7;' oninput="verifyString()" onclick="verifyString()"></td>
                <td><input type='text' id='f5' style='width:100%;border:none;background-color:#F4ECF7;' oninput="verifyString()" onclick="verifyString()"></td>
                <td><input type='text' id='f7' style='width:100%;border:none;background-color:navy;color:white;' oninput="verifyString()" onclick="verifyString()"></td>
                <td><input type='text' id='f2' style='width:100%;border:none;' oninput="verifyString()" onclick="verifyString()"></td>
                <td><input type='text' id='f3' style='width:100%;border:none;' oninput="verifyString()" onclick="verifyString()"></td>
                <td><input type='text' id='f10' style='width:100%;border:none;' oninput="verifyString()" onclick="verifyString()"></td>
            </tr>
            <tr style='color:maroon;font-weight:bold;background-color:yellow;'>
<td>Standard (F4)</td>
<td style='width:13%;'>RegExp-Keys (F8)</td>

<!-- *<a href="tutorial/generalInfo.html" target='_blank'>Link to Gen</a> *<a href="tutorial/generalInfo.html" target='_blank'>Link to Gen</a>-->
<td style='cursor:pointer;' onclick="window.open(document.getElementById('f9').value);">Local-File2 (F9) *</td>


<td id='tail' colspan='3'>Nutrients (F11-48)</td></tr>
            <tr>
                <td><input type='text' id='f4' style='width:100%;border:none;' oninput="verifyString()" onclick="verifyString()"></td>
                <td><input type='text' id='f8' style='width:100%;border:none;color:navy;font-weight:bold;' oninput="verifyString()" onclick="verifyString()"></td>
                <td><input type='text' id='f9' style='width:100%;border:none;background-color:navy;color:white;' oninput="verifyString()" onclick="verifyString()"></td>
                <td colspan='3'><input type='text' id='f11' style='width:100%;border:none;' oninput="verifyString()" onclick="verifyString()"></td>
            </tr>
            <tr style='background-color:lightgray;text-align:center;'>
                <td colspan='6'><input type='button' value='Process Data' style='border-radius: 5px;border: 1px solid #000;padding: 4px 4px;background:navy;font-size: 12px;font-weight:bold;color:white;cursor: pointer;' onclick=creaDel('add');></td>
            </tr>
            <tr>
            <td colspan='6' style='text-align:center;border: 1px solid black;cursor:pointer;' onclick="toClipboard('result');"><b>Raw Record</b>►Copy to Clipboard<span </span></td>
            </tr>
            <tr>
            <td colspan='6' style="height:30px;"><input type='text' id='result' style='width:100%;border:none;' onclick="gridResult()" >

            </td>
            </tr>
        </table>

    </div>

</div>
<div id='tree' style='float:left;width:25%;padding:15px 0px 0px 0;'>

<?php $fileContent = shell_exec("echo $(cat treeTmp.html) | cut -d'@' -f1");echo "$fileContent";?>

</div>



<div id='filesContents' style='float:left;width:75%;padding:15px 0px 0px 0;'>

<?php $fileContent = shell_exec("echo $(cat treeTmp.html) | cut -d'@' -f2");echo "$fileContent";?>

</div>



















</body></html>
