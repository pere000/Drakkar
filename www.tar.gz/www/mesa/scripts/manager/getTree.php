<?php
    $command = $_POST['flop'];
    $output = shell_exec("./manageTree.scr ".$command);
    echo "$output";
?>
