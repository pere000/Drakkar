<?php
if (isset($_POST['sft'])) {
    $command = $_POST['sft'];
    $output = shell_exec("./manageTree.scr ".$command);
    echo "$output";
} else {
    echo "No 'group' parameter provided.";
}

?>
