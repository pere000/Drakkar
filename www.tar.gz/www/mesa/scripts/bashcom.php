<?php
if (isset($_POST['group'])) {
    $command = $_POST['group'];
    $output = shell_exec("./bashcom.scr $command 2>&1");
    echo $output;
} else {
    echo "No 'group' parameter provided.";
}
?>