<?php
exec("echo $(./saveRecipe.scr " . $_POST['group'] . ")");
?>
