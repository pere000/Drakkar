<?php
//ejecutar saveRecipe.scr
#exec("echo $(./ajax_post.scr)");
exec("echo $(./saveRecipe.scr " . $_POST['group'] . ")");

//exec("echo $(./saveRecipe.scr)");
//echo 'Recipe saved.';
//echo $dataBash;
//exec("echo $(echo 'ok' > texto.txt)";
//exec("echo $(echo '|" . $_POST['group']"' >> texto.txt)");
//exit
//$dataBash = exec("echo $(cat texto.txt)");
//file_put_contents("texto.txt", "|" . $_POST['firstname'] . " " . $_POST['lastname'], FILE_APPEND);
//$dataBash = file_get_contents('texto.txt');
//echo 'Thank you Mr. '. $_POST['firstname'] . ' ' . $_POST['lastname'] . '. The content of the texto.txt file is "' . $dataBash . '".';

?>
