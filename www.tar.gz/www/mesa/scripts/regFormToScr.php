<?php

exec("echo $(./regFormPhpToScr.scr " . $_POST['group'] . ")");
//exec("echo " . $_POST['group'] . " > tmp5");
$dataBash = exec("echo $(cat tmp.regFormScrToPhp)");
echo 'Bash: '.$dataBash;

?>
