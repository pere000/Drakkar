<?php


exec("echo $(./searchdb.scr " . $_POST['group'] . ")");

echo $_POST['group'];


?>
