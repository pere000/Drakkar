<?php
	$dataBash=exec("echo $(./mesaSearch.scr  ".$_POST['forScrS1'].")");
	echo $dataBash;
?>
