<?php
//exec("echo $(echo 'test' > loc.php)");

exec("echo $(./ajax_post.scr " . $_POST['group'] . ")");
$dataBash = exec("echo $(cd ..;cat bd/menu/tmp)");
echo $dataBash;

?>
