<?php
if (isset($_POST['group'])) {
    $impFile = $_POST['group'];
    $output = shell_exec("./impFile.scr $impFile 2>&1");
   echo $output;
} else {
    echo "No 'group' parameter provided.";
}
?>
