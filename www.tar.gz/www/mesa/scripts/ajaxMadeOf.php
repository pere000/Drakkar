<?php
exec("echo $(./ajaxMadeOf.scr " . $_POST['group'] . " " . $_POST['madeOf'] . ")");

//Devuelve ajavascript
$dataBash = exec("echo $(cd ..;cat bd/menu/ajaxMadeOf_.tmp)");
echo $dataBash;


?>
