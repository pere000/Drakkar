<?php
$dataBash=exec("echo $(./mesaSearchNut.scr " . $_POST['group'] . ")");
echo $dataBash;

?>
