#!/bin/bash

dirdb='../../bd/dbs/';

#echo '$1: '$1 >> $dirdb'tmp'
file='none'
    if [[ $(echo $1 | cut -d'@' -f1) == 'load' ]];then
        echo $1 > $dirdb'tmp'
        #get filename
        file=$(echo $1 | cut -d'@' -f2 | cut -d'|' -f1)
        echo $file > $dirdb'tmp'
        #get the record id
        toWork=$(echo $1 | cut -d'|' -f2)
        result=$(grep "$toWork" $dirdb"$file")
        echo $result;
    fi

    if [[ $(echo $1 | cut -d'@' -f1) == 'crea' ]];then
		#create only .db,.csv,.txt,.free
    		if [[ "$(echo $1 | cut -d'|' -f6)" =~ \.db$|\.csv$|\.txt$|\.free$ ]]; then
				#get the standard strip
				strip=$(echo $1 |cut -d'@' -f2-)
				#create the new file
				file=$(echo $strip | cut -d'|' -f6)
				>$dirdb$file
				#add the standard to the new file
				echo $strip > $dirdb$file
				#send the result to the page
				echo $strip;
        	else
				echo 'none'
			exit
    		fi
    fi

    if [[ $(echo $1 | cut -d'@' -f1) == 'rep' ]];then
		line_number=1;
        #get file and strip
        strip=$(echo $1 | cut -d'@' -f2-)
        file=$(echo $strip | cut -d'|' -f6)
    			#get id
    			recordId=$(echo $strip | cut -d'|' -f1)

        #replace strip in the file
        	#if [ $file == 'txt' ];then

    				#get n
    				line_number=$(grep -n $recordId $dirdb$file | cut -d':' -f1)
					#replace
					sed -i "${line_number}s/.*/${strip//\//\\/}/" "$dirdb$file"
					#send strip to the form
					echo $strip;
        	#fi
    fi	#end rep

    if [[ $(echo $1 | cut -d'@' -f1) == 'add' ]];then
        #get file and strip
        strip=$(echo $1 | cut -d'@' -f2-)
        file=$(echo $strip | cut -d'|' -f6)
    			#get new id and replace it to the strip
				timestamp=$(date +"%s")
				stripRest=$(echo $strip | cut -d'|' -f2-)
				strip=$timestamp'|'$stripRest
					echo $strip >> "$dirdb$file";
		echo $strip

	fi

    if [[ $(echo $1 | cut -d'@' -f1) == 'del' ]];then
    	if [ -z "$(echo $1 | cut -d'@' -f2 | cut -d'|' -f5)" ]; then
			rm $dirdb$(echo $1 | cut -d'@' -f2 | cut -d'|' -f6)
		else
			line_number=$(grep -n $(echo $1 | cut -d'@' -f2 | cut -d'|' -f1) $dirdb$file | cut -d':' -f1)
			sed -i "${line_number}d" "$dirdb$(echo $1 | cut -d'@' -f2 | cut -d'|' -f6)"
		fi
	exit
    fi

arrList=();if ls "$dirdb"*~ 1> /dev/null 2>&1; then rm "$dirdb"*~;fi;

arrList=$(grep -r '^0000000000' $dirdb* | grep '0100' | cut -d'|' -f6);arrList=($arrList)

t=0;g=0
>'../../bd/tech/manager2.txt'
    for ((i=0; i<${#arrList[@]}; i++)); do
        head="$(grep '^0000000000' $dirdb* | grep '0100|.*|'${arrList[i]})";
        stem=$(echo "$head" | cut -d'|' -f3)
echo 'stem: '$stem >> $dirdb'tmp'
        if [ $stem == 'NFSA' ];then stem_='Norwegian Food Safety Authority';fi
        if [ $stem == 'WWEIA' ];then stem_='What We Eat In AMerica';fi

        echo "<div><span style='margin-top:20px;color:green;'><span style='color:maroon'><b>Stem DB ~</b></span><span id='"$t"' style='font-size:18px;color:maroon;cursor:pointer;' onclick=\"openClose('t"$t"');\">▼</span> <span style='color:maroon'><b>DB file</b></span>: <span id='s"$g"' style='cursor:pointer' onclick=creaDel('load|'+this.id+'|0000000000');>"${arrList[i]}"</span>, <span style='color:maroon'><b>Group:Subgroup (F2) </b></span>: "$(echo "$head" | cut -d'|' -f2)" </span> <span style='color:maroon'><b>What is it</b>:</span><span style='color:blue'>  "$(echo "$head" | cut -d'|' -f10)"</span></div><div id='t"$t"' name='toto' style='display:none'>" >> '../../bd/tech/manager2.txt'
t=$((t+1))
    middle=$(echo DB: $(echo "$head" | cut -d'|' -f6) 'description: '$(echo $head | cut -d'|' -f10));
    middle=();
    middle=($(grep -r '^0000000000' $dirdb* | grep $stem'|0010|'${arrList[i]} | cut -d'|' -f6));

    for ((j=0; j<${#middle[@]}; j++)); do
    showA2Profile=$(grep -r '^0000000000' $dirdb* | grep '0010|.*|'${middle[j]});

     echo "<div><span style='color:red;margin-left:20px;'><span style='color:maroon'><b>Food Class ~</b></span> <span style='color:maroon'><b>DB file: </b></span><span id='v."$g"' style='cursor:pointer' onclick='creaDel(\"load|\"+this.id+\"|0000000000\");'>"$(echo $showA2Profile | cut -d'|' -f6)'</span>, <span style='color:maroon'><b>Description: </b></span>"'$(echo $showA2Profile | cut -d'|' -f10)'", <span style='color:maroon'><b>Standard: </b></span>'$(echo $showA2Profile | cut -d'|' -f4)', <span style='color:maroon'><b>Provider: </b></span>'$(echo $showA2Profile | cut -d'|' -f7)"</span>" >> '../../bd/tech/manager2.txt'


txt=($(grep -r '^0000000000' $dirdb* | grep $stem'|0001|' | cut -d'|' -f6))

    for ((k=0; k<${#txt[@]}; k++)); do
    txtrear=$(grep -r '^0000000000' $dirdb* | grep $stem'|0001|'$(echo $showA2Profile | cut -d'|' -f6)'|'${txt[k]})
    first=$(echo $txtrear | cut -d'|' -f6)
        if ! [ -z $first ];then

        echo "<div style='margin-bottom:4px;color:green;margin-left:40px;'><span style='color:maroon'><b>Cooked Foods ~</b></span> <span style='color:maroon'><b>DB file:</b></span><span id='r."$g"' style='cursor:pointer' onclick='creaDel(\"load|\"+this.id+\"|0000000000\")'> "$(echo $txtrear | cut -d'|' -f6)'</span>, <span style='color:maroon'><b>Description: </b></span>"'$(echo $txtrear | cut -d'|' -f10)'", <span style='color:maroon'><b>Standard: </b></span>'$(echo $txtrear | cut -d'|' -f4)', <span style='color:maroon'><b>Provider: </b></span>'$(echo $txtrear | cut -d'|' -f7)"</div>" >> '../../bd/tech/manager2.txt';
        fi
g=$((g+1))
    done
done;
echo "</div>" >> '../../bd/tech/manager2.txt';
done
free=();
free=($(grep -r '^0000000000' $dirdb* | grep '|0011|' | cut -d'|' -f6))
p=0
echo "<div style='margin-top:20px;color:maroon'><b></span>Free flavours:</b><span style='font-size:18px;cursor:pointer;' onclick=\"openClose('p"$p"');\">▼</span><br>" >> '../../bd/tech/manager2.txt'
echo "<span id='p"$p"' name='toto' style='display:none'>" >> '../../bd/tech/manager2.txt'
    for ((i=0; i<${#free[@]}; i++)); do
    flavor=$(grep -r '^0000000000' $dirdb* | grep '|0011|.*|'${free[i]})
    free=$(grep -r '^0000000000' $dirdb* | grep '|0011|.*|'${free[i]} | cut -d':' -f2-);


    echo "<div style='color:green;margin-left:40px;'><span style='color:maroon'><b>DB file</b>:</span> <span id='f."$g"' style='cursor:pointer' onclick='creaDel(\"load|\"+this.id+\"|0000000000\")'> "$(echo $free | cut -d'|' -f6)"</span>, <span style='color:maroon'><b>Description</b>:</span> \""$(echo $free | cut -d'|' -f10)"\", <span style='color:maroon'><b>Standard</b>:</span> "$(echo $free | cut -d'|' -f4)", <span style='color:maroon'><b>Provider</b>:</span> "$(echo $free | cut -d'|' -f7)"</div>" >> '../../bd/tech/manager2.txt'

#p=$((p+1))
g=$((g+1))
    done;
echo '</span>' >> '../../bd/tech/manager2.txt'

>'../../bd/tech/records.txt'
dirdb='../../bd/dbs/';
if ! [[ $file == 'none' ]];then
echo $file >> $dirdb'tmp'
line_count=$(awk 'END {print NR}' "$dirdb$file");for ((i=1; i<=line_count; i++));
do line=$(sed -n "${i}p" "$dirdb$file");
echo "<span style='color:maroon;font-weight:bold;'>File: </span> <span id='z."$g"' style='cursor:pointer' onclick=\"creaDel('load|'+this.id+'|"$(echo $line | cut -d'|' -f1)"')\">$file</span> <span style='color:maroon;font-weight:bold;'>Id: </span> $(echo $line | cut -d'|' -f1) <span style='color:maroon;font-weight:bold;'>Recipe: </span> $(echo $line | cut -d'|' -f6) <span style='color:maroon;font-weight:bold;'>Group:Subgroup: </span> $(echo $line | cut -d'|' -f2) <span style='color:maroon;font-weight:bold;'>Description: </span> $(echo $line | cut -d'|' -f10)<br>" >> ../../bd/tech/records.txt
g=$((g+1))
done;
else
echo '<span>Waiting your command</span>' >> ../../bd/tech/records.txt
fi
