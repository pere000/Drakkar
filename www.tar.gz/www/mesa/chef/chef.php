<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<link rel="stylesheet" href="../recipes/recipeFiles/scripts/shareRecipe.css"/>
<script type="text/javascript" src="../recipes/recipeFiles/js/jquery-3.6.0.slim.js"></script>

<style>
body {width:94.9%;background-color:#145A32;color: white;font-size: 12px;
font-family: "Verdana", sans-serif;}


.box {display:flex;width:100%;margin-left:1%;font-size:12px;}
.one{flex-direction:column;width:15%;color:gold;font-weight:bold;font-size:12px;}
.two{width:40%;color:gold;margin-right:15px;font-weight:bold;}
.three{width:40%;color:gold;font-weight:bold;}
.four{flex-direction:column;width:15%;padding:0 0px 0 15px;color:navy;font-weight:bold;}
.divButton{cursor:pointer;width:150px;margin:2px 0 2px 0;background: gold;border: solid 0.01em yellow;border-radius: 10px 40px 40px 10px;}
.divButton:hover {flex: 1 1 10%;cursor:pointer;background: yellow;border: solid 0.1em gold;border-radius: 10px 40px 40px 10px;}
.divButton[name='up']{cursor:pointer;width:150px;margin:19px 0 2px 0;background: gold;border: solid 0.01em yellow;border-radius: 10px 40px 40px 10px;}
.divButton[name='up']:hover {flex: 1 1 10%;cursor:pointer;background: yellow;border: solid 0.1em gold;border-radius: 10px 40px 40px 10px;}
.divButton[name='down']{cursor:pointer;width:150px;margin:10px 0 0px 0;background: gold;border: solid 0.01em yellow;border-radius: 10px 40px 40px 10px;}
.divButton[name='down']:hover {flex: 1 1 10%;cursor:pointer;background: yellow;border: solid 0.1em gold;border-radius: 10px 40px 40px 10px;}
.one1{flex-direction:column;width:15%;color:white;font-weight:bold;}
.two1{width:41%;color:white;font-weight:bold;}
.three1{width:40%;color:white;font-weight:bold;}
.four1{width:15%;padding:0 0px 0 15px;color:white;font-weight:bold;}
input[type='text']{font-size:12px;color:black;}
textarea{width:100%;height:96%;padding:5px 5px 0 5px;font-size:12px;color:black;}

.menuA {display:flex; flex-direction:row;column-gap:8px;justify-content:left;color:yellow;font-weight:bold;}
.optionA {cursor:pointer;flex: 0 1% 10%;color: yellow;transition: all 2s;}
.optionA:hover {flex: 1 1 10%;}
.colonsW {color:white;}

.menuB {display:none;flex-direction:row;column-gap:8px;justify-content:left;font-weight:bold;}
.optionB {cursor:pointer;flex: 0 1% 10%;color:gold;transition: all 2s;}
.optionB:hover {flex: 1 1 10%;}
span.optionB{cursor:pointer;color:white;}

.menuC {flex-direction:row;column-gap:8px;justify-content:left;font-weight:bold;}
.optionC {display:none;column-gap:8px;cursor:pointer;flex: 0 1% 10%;color:white;transition: all 2s;}
.optionC:hover {flex: 1 1 10%;column-gap:4px;}
.optionD:hover {flex: 1 1 10%;color:white;}

/*All tables, buttons, .boxes*/
table { width: 300px; border-collapse: collapse; }
table.nutrients {width: 100%; border-collapse: collapse;color:olive}
button{width:150px;font-size:12px;font-weight:bold;}
.box {display:flex;font-size:12px;}
#replaceCheck {background-color:#FFF8DC;}
table.nutrients tr.trTitles {color:green; };
textarea{font-size: 12px;}

#c1 {flex-wrap:wrap;color:black;padding: 10px 5px 10px 5px;display:none;}
.magnum {cursor:pointer;color:gold;}
.magnum_ {cursor:pointer;color:white;}

.showRecipe{color:yellow;padding-left:10px;color:yellow;}
.showTitle{padding-left:10px;}
.showContent{padding-left:20px;color:white;}

.uno {width:100%;margin-left:1%;margin-top:5px;color:white;}
.dos {width:100%;margin-left:1%;margin-top:4px;color:yellow;}
.tres {width:100%;padding-left:7%;}
.cuatro {width:90%;}
.tab {background-color:#FAFAD2;width:100%;;padding-left:4px;}
.color{color:yellow;width:100%;}

button.buttonA{
background-color:#FAFAD2;cursor:pointer;width:120px;margin-bottom:5px;margin-top:2px;
}
button.buttonB{
cursor:pointer;width:120px;margin-top:10px;
}

#searchBox{background-color:#FAFAD2;}
#searchDB{color:#696969;font-weight:bold;}
#Replace{color:#696969;font-weight:bold;}
button[type='button']{font-size:12px;cursor:pointer;width:120px;color:black;}
table.google{margin-left:auto;margin-right:auto;margin-top:20px;padding-left:4.2%;text-align:center;color:black;}
div[name='selectMessage']{background-color:white;color:black;}
div[name='heads']{text-align:center;margin-bottom:5px;color:yellow;}
div[name='grandblock']{width:100%;margin-left:1%;color:black;}
.ref{float:left;width:95%;margin-bottom:7px;background-color:#FAFAD2;'}
.classX {
  list-style: none;
  margin: 0;
  overflow: hidden;
  padding: 0;
}

.classX tagX {
  float: left;
}

tagX.classX {


}

tagA,
tagB,
tagX {

}

#idX {

}

imgX {

}

</style>
<script>
/*
function run(phpRunScr) {

        // Creating Our XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Making our connection
        var url = phpRunScr;
        xhr.open("GET", url, true);

        // function execute after request is successful
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
               //alert(this.responseText);
				document.getElementById('nutrientsRecords').innerHTML='';
				document.getElementById('nutrientsRecords').innerHTML=this.responseText;
            }
        }
        // Sending our request
        xhr.send();
    }
*/

//Shortest ajax code in pure javascript without using Json format (chatGPT)
function ram(phpRunScr,dataToBeSent,dataRecoverFolder){
//alert(dataToBeSent)

//('scripts/phpRunScr.php','name=null','nutrientsRecords') => no se envía data
//('','list','')
if (dataToBeSent == 'list'){
	//alert('dataToBeSent es la clase-JSON "list": '+dataToBeSent)

		var collectedNumId='';
		var elements = document.getElementsByName(dataToBeSent);
		// Loop through all elements and change their color to red
		for(var i=0; i<elements.length; i++) {

			if (elements[i].checked == true){collectedNumId=collectedNumId+','+elements[i].id.slice(0,-1)}
		}
	dataToBeSent='name='+collectedNumId.slice(1)
	//alert('dataToBeSent es: '+dataToBeSent)
}
else
{
dataToBeSent='name=null'
}
//exit
//dataToSend="name=John&age=30" (URL-encoded format);
//The dataToSend string for xhr.send(stringToBeSent) is already built for the server to receive 'John and 30' at $_POST['name'] and $_POST['age'] respectively
//dataToBeSent="name=John"
//alert(dataToBeSent)
const xhr = new XMLHttpRequest();
xhr.open("POST", phpRunScr, true);
xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhr.onreadystatechange = function () {
	if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {document.getElementById(dataRecoverFolder).innerHTML=xhr.responseText;}
	};
	xhr.send(dataToBeSent);
}


function ramB(phpRunScr,dataToSend,folderTo){
//alert(phpRunScr+', '+dataToSend+', '+folderTo)
		var idCollection='';
		//get by name='list' the collection of checkbox
		var elements = document.getElementsByName(dataToSend);
		//Loop through all the elements, get their value id=$vId, remove the underscore, and build a ids collection.
		for(var i=0; i<elements.length; i++) {
			elId=elements[i].id.slice(0,-1);
//alert('elId?: '+elId)
			register=elId+':'+document.getElementById(elId+'bis').innerHTML;register='"'+register+'"'
//alert("register?: "+register)
			if (elements[i].checked == true){idCollection=idCollection+'#'+register}
		}
		idCollection=folderTo+'#'+idCollection.slice(1)	//dataToBeSent to PHP-scr scriptsmyString.replace(/a/g, "b");
//newreg=idCollection.replace(/\|/g, ",")
//alert(newreg)
dataToBeSent="idCollection="+idCollection //.replace(/\|/g, ",")
//alert('dataToBeSent: '+dataToBeSent)
//exit
const xhr = new XMLHttpRequest();
xhr.open("POST", phpRunScr, true);//alert('data to send to: '+phpRunScr)
xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhr.onreadystatechange = function () {
	if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {document.getElementById(dataRecoverFolder).innerHTML=xhr.responseText;}
	};
	xhr.send(dataToBeSent);//alert('dataToBeSent: '+dataToBeSent)
}

//////////////////////////////////////////////////////////////////////////
//Shortest ajax code in pure javascript without using Json format (chatGPT)
//
function ramC(phpRunScr,dataToBeSent,dataRecoverFolder){

//alert(phpRunScr+', '+dataRecoverFolder)
//exit
//COME FROM BUTTON 'Pending Recipes' => ramC('imported/test.php','Null','Null')
//alert(dataToBeSent)
document.getElementById('msgChef').innerHTML='*** Before clicking a button, check all the boxes whose records you want to delete or validate.';
document.getElementById("msgChef").style.color = 'white';document.getElementById("msgChef").style.fontSize = '12px';document.getElementById("msgChef").style.fontWeight= 'normal';
if (dataToBeSent == 'list'){
	//alert('dataToBeSent es la clase-JSON "list": '+dataToBeSent)

		var collectedNumId='';
		var elements = document.getElementsByName(dataToBeSent);
		// Loop through all elements and change their color to red
		for(var i=0; i<elements.length; i++) {

			if (elements[i].checked == true){collectedNumId=collectedNumId+','+elements[i].id.slice(0,-1)}
		}
	dataToBeSent='name='+collectedNumId.slice(1)
	//alert('dataToBeSent es: '+dataToBeSent)
}
else
{
//=> GO TO test.php => test.scr
dataToBeSent='name=null'
}
//alert(phpRunScr)
const xhr = new XMLHttpRequest();
xhr.open("POST", phpRunScr, true);
xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhr.onreadystatechange = function () {
	if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
var text = xhr.responseText;
//alert('')
//alert(text);
document.getElementById(dataRecoverFolder).innerHTML=text;
}
	};
	xhr.send(dataToBeSent);
}
////////////////////////////////////////////////////////////////////////////

function ZIndex(itemId){
//Absolute filter


var itemZ='p'+itemId.slice(1)
if (document.getElementById(itemZ).style.zIndex == '3'){exit}
var top=document.getElementById(itemZ).style.top
var height=document.getElementById(itemZ).style.height
var zIndex=document.getElementById(itemZ).style.zIndex


	switch (itemZ) {
		case 'p_1':
			//alert('p_1');
			if (document.getElementById('p_2').style.zIndex == '3'){
			//alert('process p_2');
			//process p_2 and itemId
			var dataZ=itemZ+'|'+document.getElementById(itemZ).style.top+'|'+document.getElementById(itemZ).style.height+'|'+document.getElementById(itemZ).style.zIndex+'|p_2|'+document.getElementById('p_2').style.top+'|'+document.getElementById('p_2').style.height+'|'+document.getElementById('p_2').style.zIndex;
document.getElementById(itemZ).style.top = document.getElementById('p_2').style.top
document.getElementById(itemZ).style.height = document.getElementById('p_2').style.height
document.getElementById(itemZ).style.zIndex = document.getElementById('p_2').style.zIndex
document.getElementById('p_2').style.top = top
document.getElementById('p_2').style.height = height
document.getElementById('p_2').style.zIndex = zIndex



			}else{
			//alert('process p_3');
			//process p_3 and itemId
			var dataZ=itemZ+'|'+document.getElementById(itemZ).style.top+'|'+document.getElementById(itemZ).style.height+'|'+document.getElementById(itemZ).style.zIndex+'|p_3|'+document.getElementById('p_3').style.top+'|'+document.getElementById('p_3').style.height+'|'+document.getElementById('p_3').style.zIndex;


document.getElementById(itemZ).style.top = document.getElementById('p_3').style.top
document.getElementById(itemZ).style.height = document.getElementById('p_3').style.height
document.getElementById(itemZ).style.zIndex = document.getElementById('p_3').style.zIndex
document.getElementById('p_3').style.top = top
document.getElementById('p_3').style.height = height
document.getElementById('p_3').style.zIndex = zIndex
			}
		break;

		case 'p_2':
			//alert('p2');
			if (document.getElementById('p_3').style.zIndex == '3'){
			//alert('process p_3');
			//process p_3 and itemId
			var dataZ=itemZ+'|'+document.getElementById(itemZ).style.top+'|'+document.getElementById(itemZ).style.height+'|'+document.getElementById(itemZ).style.zIndex+'|p_3|'+document.getElementById('p_3').style.top+'|'+document.getElementById('p_3').style.height+'|'+document.getElementById('p_3').style.zIndex;
document.getElementById(itemZ).style.top = document.getElementById('p_3').style.top
document.getElementById(itemZ).style.height = document.getElementById('p_3').style.height
document.getElementById(itemZ).style.zIndex = document.getElementById('p_3').style.zIndex
document.getElementById('p_3').style.top = top
document.getElementById('p_3').style.height = height
document.getElementById('p_3').style.zIndex = zIndex
			}else{
			//alert('process p_1');
			//process p_1 and itemId
			var dataZ=itemZ+'|'+document.getElementById(itemZ).style.top+'|'+document.getElementById(itemZ).style.height+'|'+document.getElementById(itemZ).style.zIndex+'|p_1|'+document.getElementById('p_1').style.top+'|'+document.getElementById('p_1').style.height+'|'+document.getElementById('p_1').style.zIndex;
document.getElementById(itemZ).style.top = document.getElementById('p_1').style.top
document.getElementById(itemZ).style.height = document.getElementById('p_1').style.height
document.getElementById(itemZ).style.zIndex = document.getElementById('p_1').style.zIndex
document.getElementById('p_1').style.top = top
document.getElementById('p_1').style.height = height
document.getElementById('p_1').style.zIndex = zIndex
			}
		break;

		case 'p_3':
			//alert('p_3')
			if (document.getElementById('p_1').style.zIndex == '3'){
			//alert('process p_1');
			//process p_1 and itemId
			var dataZ=itemZ+'|'+document.getElementById(itemZ).style.top+'|'+document.getElementById(itemZ).style.height+'|'+document.getElementById(itemZ).style.zIndex+'|p_1|'+document.getElementById('p_1').style.top+'|'+document.getElementById('p_1').style.height+'|'+document.getElementById('p_1').style.zIndex;
document.getElementById(itemZ).style.top = document.getElementById('p_1').style.top
document.getElementById(itemZ).style.height = document.getElementById('p_1').style.height
document.getElementById(itemZ).style.zIndex = document.getElementById('p_1').style.zIndex
document.getElementById('p_1').style.top = top
document.getElementById('p_1').style.height = height
document.getElementById('p_1').style.zIndex = zIndex
			}else{
			//alert('process p_2');
			//process p_2 and itemId
			var dataZ=itemZ+'|'+document.getElementById(itemZ).style.top+'|'+document.getElementById(itemZ).style.height+'|'+document.getElementById(itemZ).style.zIndex+'|p_2|'+document.getElementById('p_2').style.top+'|'+document.getElementById('p_2').style.height+'|'+document.getElementById('p_2').style.zIndex;
document.getElementById(itemZ).style.top = document.getElementById('p_2').style.top
document.getElementById(itemZ).style.height = document.getElementById('p_2').style.height
document.getElementById(itemZ).style.zIndex = document.getElementById('p_2').style.zIndex
document.getElementById('p_2').style.top = top
document.getElementById('p_2').style.height = height
document.getElementById('p_2').style.zIndex = zIndex
			}
		break;



					}
//alert(dataZ);
document.getElementById('data1').innerHTML=dataZ
document.getElementById('data2').innerHTML=dataZ
document.getElementById('data3').innerHTML=dataZ
}






</script>



</head><body onload="setup()">

<div style='width:99%;font-family:satisfy;padding-left:50px;text-align:left;font-size:40px;text-shadow: 1px 1px 2px red, 0 0 1em white, 0 0 0.2em yellow;' translate="no"><span style='color:#FFD1DC;text-shadow:1px 3px 2px gold;'>༺ </span>  Western Free Rose  <span style='color:#FFD1DC;text-shadow:1px 3px 2px gold;'> ༻</span></div>

<div style='margin-left:130px;margin-top:-20px;font-family:normal;font-size:24px;color:gold;'>Head Chef</div>

<div style='position:absolute;width:97.5%;font-weight:bold;background-color:#EAEDED;color:#808000;top:100px;height:20px;z-index:0;'>
	<span id='q_1' style='padding-left:70px;cursor:pointer;' onmouseover='ZIndex(this.id)'>Recipes DB</span>
	<span id='q_2' style='padding-left:70px;cursor:pointer;' onmouseover='ZIndex(this.id)'>Main DB: Quantitative fields</span>
	<span id='q_3' style='padding-left:80px;cursor:pointer;' onmouseover='ZIndex(this.id)'>Main DB: Qualitative fields</span>
</div>


<div id='p_1' style = "position:absolute;width:97.5%;background-color:blue;color:white;top:120px;height:500px;z-index:3;">
	<div class="box" style='padding-top:20px;'>
		      <div class='one1'>References</div>
		      <div class='two1'>Ingredients <span id='ingredients_'</span></div>
		      <div class='three1'>Preparation<span id='steps_'</span></div>
		      <div class='four1'>Do</div>
	</div>
<div class="box">
	<div class='one'>
		Reg. No. <span id='file_'></span><br><input id='a_0' label='1' style='' type='text' onclick='orderToSearch(this.id)'><br>
		Title <span id='title_'></span><br><input id='a_7' label='8' type='text' onclick='orderToSearch(this.id)'><br>
		Author (Country) <span id='author_'></span><br><input id='a_8' label='9' type='text' value='Western Free Rose' onclick='orderToSearch(this.id)'><br>
		Image <span id='country_'></span><br><input id='a_9' label='10' type='text' onclick='orderToSearch(this.id)'><br>
		Url <span id='url_'></span><br><input id='a_10' label='11' type='text' onclick='orderToSearch(this.id)'>
	</div>

	<div class='two'>
		<textarea id='a_11' label='12' type='text' style='' onclick='orderToSearch(this.id)'></textarea>
	</div>
    <div class='three'>
		<textarea id='a_12' type='text' onclick='orderToSearch(this.id)'>
Step 1

Step 2

Step (your turn to continue ...)
		</textarea>
	</div>

	<div class='four'>


		<div class='divButton' name='down' onclick='record();'>Save to Rec-DB</div>
		<div class='divButton'><input id='replace' type='checkbox' onclick=''><span id='Replace'> Force</span></div>
		<div class='divButton' name='up' onclick="ramC('scripts/test.php','Null','forChef');">Pending Recipes</div>
		<div class='divButton' name='up' onclick='shareHTML();'>Sharing Recipe</div>
		<div class='divButton' name='up' onclick='alert('For sharing HTML in reicipeFiles folder');'>Seach</div>

	</div>
</div>
<div style='padding-left:3%;padding-right:4%'><br>


<table style='width:100%'>
<tr><td style='width:5%'>Weight g</td><td style='width:5%'>Energy kc</td><td style='width:30%'>Preparation</td><td style='width:30%'>Main Food</td>
<td style='width:10%'>Group</td><td style='width:10%'>Subgroup</td></tr>
<tr><td><input id='a_5' style='width:95%' type='text'></td><td><input id='a_6' style='width:95%' type='text'></td><td><input style='width:99%' type='text' id='a_4'></td><td><input id='a_1' style='width:99%' type='text'></td><td><input style='width:97%' type='text' id='a_2'></td><td><input style='width:99%' type='text' id='a_3'></td></tr>
</table>

</div>
<div style='margin-top:15px;padding:0 0 5px 40px;'><input type='button' value='Delete' onclick='pendings("delete")'><input type='Button' style='margin:0 20px 0 10px;' value='Validate' onclick='pendings("validate")'> Add: <input type='checkbox' id='AddReg' style='' onclick="alternateAddRpl(this.id)"> Replace: <input type='checkbox' id='RplReg' style='margin-right:10px;' onclick="alternateAddRpl(this.id)">
<span id='msgChef' style=''> *** Before clicking a button, check all the boxes whose records you want to delete or validate.</span></div>
<div id='forChef' style='width:99%;height:40.5%;background-color:#F9E79F;padding: 5px 2px 0px 10px;overflow-y: scroll;text-align:left;'>

	<?php
	echo "";
	$head=	exec("

					echo $(cat imported/userdbHTML.htm);

				");
	echo $head."<br>";
	?>
</div>
	</div>

	<div id='p_2' style = "position:absolute;width:97.5%;background-color:#F9E79F;color:navy;top:120px;height:500px;z-index:2;">
<table class="nutrients">
	<tr class='whiteFont'>
		<td style='text-align:right;color:green;width:11%;'>Food :</td>
		<td id='f4' style='padding-left:5px;' colspan='9'> ...</td>

	</tr>
	<tr class='trTitles'><td id='search1234' style='padding-left:10px;color:red;font-weight:bold;'><button style='width:170px;' onclick='calculate()'>Add/Replace...<span style='color:red'>Oops!</span></button></td><td style='width:10%'>1 Reg. No.</td><td style='width:10%'>2 Group:Subg.</td><td style='width:10%'>3 Made of ...</td><td width="400px">4 +Plus-words</td><td style='font-weight:bold;width:8%'>Quantity g</td><td style='font-weight:bold;width:8%'>Kc Total</td><td style='width:8%;'>Kc 100 g</td><td style='width:6%;'>Ca (mg)</td><td></td></tr>
	<tr>
		<td style='text-align:left;padding-left:1.3%;color:red;'><input id='replaceCheck' onclick='ifCheck()' type='checkbox'><span> Remove</span></td>
		<td id='f1' style='background-color:#FFF8DC;font-weight:bold;' onclick='document.getElementById(this.id).innerHTML=""' contenteditable='true'></td>
		<td id='f2' contenteditable='true' style='width:12%'></td>
		<td id='f3' contenteditable='true'></td>
		<td id='f25' contenteditable='true'></td>

		<td id='f23' contenteditable='true' onclick='document.getElementById(this.id).innerHTML=""'>23</td>
		<td id='f24'>1600-3000</td>
		<td id='f22'>22</td>
		<td id='f19' contenteditable='true'>1300</td>
		<td></td>
	</tr>

	<tr class='trTitles'>
	<td style='padding-left:10px;color:red;font-weight:bold;'><button style='width:120px;' onclick='alert('pendent')'>Update in list</button></td><td>Proteins (g)</td><td>Carbo (g)</td><td>Fat (mg)</td><td>SatFat (mg)</td><td>Cholest. (mg)</td><td>ClNa (g)</td><td>Alcohol (g)</td><td>Fe (mg)</td>
	<td></td></tr>
	<tr>
	<td style=''></td>
	<td id='f5' contenteditable='true'>50 (10-35% kc)</td>
	<td id='f6' contenteditable='true'>275 g (45-65% Kc)</td>
	<td id='f7' contenteditable='true'>78 g (&#60;30% Kc)</td>
	<td id='f8' contenteditable='true'>20 g per day (sat+trans &#60;11% Kc)</td>
	<td id='f9' contenteditable='true'>300</td>
	<td id='f10' contenteditable='true'>&#60;5</td>
	<td id='f11' contenteditable='true'>0</td>
	<td id='f20' contenteditable='true'>18</td>
	<td style=''></td>
	</tr>
	<tr class='trTitles'>
	<td style='padding-left:10px;color:red;font-weight:bold;'><button style='width:120px;' onclick='loadReg()'>Load Reg No</button></td><td>Fiber (g)</td><td>Omegas (g)</td><td>Vit A (RAE)</td><td>Vit B (mg)</td><td>Vit C (mg)</td><td>Vit D (µg)</td><td>Vit E (alfa-TE) </td><td>K (mg)</td><td></td>
	</tr>
	<tr>
	<td style=''></td>
	<td id='f12' contenteditable='true'>28-35</td>
	<td id='f13' contenteditable='true'>0.25-0.5</td>
	<td id='f14' contenteditable='true'>900</td>
	<td id='f15' contenteditable='true'>15</td>
	<td id='f16' contenteditable='true'>90</td>
	<td id='f17' contenteditable='true'>20</td>
	<td id='f18' contenteditable='true'>15</td>
	<td id='f21' contenteditable='true'>&#8925;4700</td>
	<td></td>
	</tr>
</table>
<div style='width:100%;background-color:#EAEDED;font-weight:bold;color:#808000;margin-top:10px;'>
	<span style='margin-left:70px;cursor:pointer;' onclick="ram('scripts/phpRunScr.php','null','nutrientsRecords');">Load list</span>
	<span style='margin-left:70px;cursor:pointer;' onclick="document.getElementById('nutrientsRecords').innerHTML=document.getElementById('messageImported').innerHTML;">Import list</span>
	<span style='margin-left:70px;cursor:pointer;' onclick="ramB('scripts/export.php','list','importExport')">Export list</span>
	<span style='margin-left:70px;cursor:pointer;' onclick="ram('scripts/phpRunScr.php','list','nutrientsRecords')">Delete checked records</span>
</div>
<div id='pendiente0' style='width:99%;height:65%;background-color:#F9E79F;padding: 5px 2px 0px 10px;overflow-y: scroll;text-align:left;'>

	<?php
	echo "";
	$head=	exec("

					echo $(./scripts/tmp5.scr);

				");
	echo $head."<br>";
	?>
</div>
	</div>

	<div id='p_3' style = "position:absolute;width:97.5%;background-color:#99A3A4;color:black;top:120px;height:400px;z-index:1;">

<div style='padding-left:20px;margin-top:20px;margin-right:40px;'>
	<table class="nutrients" style='width:100%;'>

		<tr class='trTitles'>
			<td id='search1234' style='width:10%;'></td>
			<td style='width:16%;padding-left:5px;'><span style='color:red;font-weight:bold;'>Reg. No.</span></td>
			<td style='width:16%;padding-left:5px;'><span style='cursor:pointer;'>Group:Subg.</span></td>
			<td style='width:20%;padding-left:5px;'><span style='cursor:pointer;'>Made of ...</span></td>
			<td style='width:16%;padding-left:5px;'><span style='cursor:pointer;'>Brand, variety</span></td>
			<td style='width:16%;'></td>
		</tr>
		<tr>
			<td style='text-align:right;padding-right:20px;'><button style='color:red;font-weight:bold;' onclick='loadReg()'>Load Reg No</button></td>
			<td id='F1' style='padding-left:5px;background-color:#EAEDED;color:red;font-weight:bold;' contenteditable='true'>1reg1</td>
			<td id='F2' style='padding-left:5px;background-color:white;' contenteditable='true'>2s:sg2</td>
			<td id='F3' style='padding-left:5px;background-color:#EAEDED;' contenteditable='true'>3made3</td>
			<td id='F4' style='padding-left:5px;background-color:white;' contenteditable='true'>4var4</td>
			<td style='text-align:right;color:red;font-weight:bold;'><button style='width:110px;font-weight:bold;color:red;' onclick='calculate()'>Add/Replace</button> (Chef)<input id='replaceCheck' onclick='ifCheck()' type='checkbox'><span style='font-weight:bold;color:red;padding-right:30px;'> Remove</span></td>
		</tr>

		<tr class='trTitles'>
			<td style='padding-left:10px;'></td>
			<td style='padding-left:5px;'><span style='cursor:pointer;'>Equal but ...</span></td>
			<td style='padding-left:5px;'><span style='cursor:pointer;'>Sustracted items</span></td>
			<td style='padding-left:5px;'><span style='cursor:pointer;'>Added items</span></td>
			<td style='padding-left:5px;'><span style='cursor:pointer;'>Consistency</span></td>
			<td style='width:20%;padding-left:5px;'><span style='cursor:pointer;'>Presentation</td>
		</tr>
		<tr>
			<td style=''></td>
			<td id='F5' style='padding-left:5px;background-color:white;' contenteditable='true'>5cuasieq5</td>
			<td id='F6' style='padding-left:5px;background-color:#EAEDED; contenteditable='true'>6subs6</td>
			<td id='F7' style='padding-left:5px;background-color:white;' contenteditable='true'>7added7</td>
			<td id='F8' style='padding-left:5px;background-color:#EAEDED;' contenteditable='true'>8consiten8</td>
			<td id='F9' style='padding-left:5px;background-color:white;' contenteditable='true'>9present9</td>
		</tr>
		<tr class='trTitles'>
			<td style=''></td><td style='padding-left:5px;' colspan='0'>Food item</td>
		</tr>
		<tr>
			<td style=''></td>
			<td id='F10' style='padding-left:5px;background-color:#EAEDED;' contenteditable='true' colspan='4'>10Food item10</td>
		</tr>
	</table><br><br><br>
Click on any title to show your options. (ajax-php-scr cat)<br>
Each group of options for each title is contained in its own file. (onclick load=>ajax-php-scr cat into chef/auxDb folder)<br>
New options inserted by the user are added to their group file, and they also can be replaced or deleted. (On Add/replace=>ajax send text-php-scr grep filter repetitions)<br><br>
Warning!:<br>Modifying the contents of 'Group:Subgroup' or 'Made of...' are major changes that require code changes.<br>They are essential for the proper functioning of the application. Read the App Manual (Alert Warning!).
</div>
	</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div id='messageImported' style='display:none;text-align:justify;'><div style='padding-top:20px;text-align:justify;'><span style='color:red'>
Importing external new registers</span><br>
The file to import new external records is called 'imported' and must be located in the 'mesa/importExport' folder. Its content must be in plain text with one record per line, just like the 'tp5Nut and import.tmp' files located in the 'mesa/chef/db and mesa/chef/imported' folder respectively. At the best, the shared file you receive to import registries into your application should have the name "exported". So you have to rename it to "imported" and overwrite the existing one "in the mesa/importExport folder". To keep some eventual content from the existing imported registries in 'chef/imported/import.tmp' file, you can add new lines to it. Alternatively, you can rename it. But in any case, there must always be a file called 'chef/imported/import.tmp' and another called 'mesa/importExport/imported', even if both are empty.<br><br>

On load and refresh, just like clicking 'Load List', the content of the existing 'mesa/chef/imported/imported' file is added to the 'mesa/importExport/import.tmp' file and flushed regardless of whether it is empty. The existing 'mesa/importExport/import.tmp' file is then updated for loading. The App maintains an empty 'mesa/chef/imported/imported' file for you to add new records and save them using your operating system's resources.<br><br>

Do not delete the 'mesa/chef/imported/imported' file or rename it. Because, just by using your operating system resources, you can overwrite or load that file to add new records and save them. This is the easiest way to accomplish the task. Therefore, this application, designed for a local host or desktop server, does not incorporate any programmatic method to perform an upload as it would for a remote Internet server.<br><br><span style='color:red'>

Exporting your registers for sharing</span><br>The file to export your registers is called 'exported' and, like the 'imported' file, it must also be located in the 'mesa/chef/imported' folder. You can export one or all of those displayed in the uploaded list. But, before exporting the desired ones, you must first select their corresponding checkboxes. Each click on 'Export List' will overwrite the 'mesa/chef/imported/exported' file. You must select the desired registers so that they are all collected at once.</div>
</div>
<br><br><br><br><br><br><br><br>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
fails<br>
chef recipe<br>
Users: only the owner has access to their own data in their own database folder (mesa/bd/users/pere/peredb.tmp).<br>
Chef: You have access to data on the fly and in the common user file (chef/imported/userdb.tmp) to validate your proposing recipes, as well as data from validated recipes (recipes/db/tmp.db—ref , ingredients—and prep.tmp—steps) and validated nutrient data files (mesa/bd/work.csv).<br>
Everyone: Can access nutrients (mesa/bd/work.csv) and validated recipes (recipes/db/tmp.db).<br><br>

recipes.php<br>
<span style="color:gold">Currently:</span><br>
<div style='padding-left:40px'>You can search for recipes <span style="color:gray">only by ids</span> and upload them <span style="color:gold">completely</span> in a nice format. When the 'Share HTML' button is clicked the 'Share HTML' guided black page is loaded.
Then, when its 'Head Chef' button is clicked the data is sent on-the-fly and the chef page loads them.</span><br>
But you can display nicely formatted recipe <u>data only on the fly</u> from the guided HTML share page. (Chef: Javascript)<br></div><br>
You should load the <u>data pending validation</u> from the recipe file (chef/imported/userdb.tmp) and pass it to your existing javascript function to display it (Chef: Javascript)<br>
When <span style="color:gray">validating the chef/imported/userdb.tmp recipe regs</span>, you should <span style="color:gray">format and split</span> them into two files: recipes/db/tmp.db and prep.tmp (Chef: Bash scr)<br>
You need:<br>
<span style='padding-left:60px'>1 Button to upload user regs for recipes pending validation (chef.php, HTML-CSS—Pending Recipes)</span><br>
<span style='padding-left:60px'>1 Bash script to return <span style="color:gray">formatted</span> data to PHP (chef/scripts/pending.scr)—1º</span><br>
<span style='padding-left:80px'>In this step, it is not necessary to split the data into two files.</span><br>
<span style='padding-left:80px'>Only after validation will it be absolutely necessary to split the data into two files without HTML format</span><br>


<span style='padding-left:60px'>1 AjaxJavascript with post method to trigger the PHP script and retrieve the formatted data (chef.php, ajax function pending())—2º</span><br>
<span style='padding-left:60px'>1 PHP script file to trigger the bash scr script which format the data and return the data to PHP (chef/scripts, pending.php)—3º</span><br>
<span style='padding-left:60px'>A modified algorithm to display the data (chef.php, javascript code)—4º</span><br><br>


<br><br>

1680597469_japanesemochi.html<br>
ingredientes format<br>
step format<br>
nutrients sets must go in the page and display:none to be passed to chef recipe.<br><br>


it is very clear that the most difficult task is to build the recipe. The database is very unordered. There is a great dependence on resources such as google and chatGPT to obtain equivalences of the measurements to the International Metric System<br>
<br><br>
1. Pending: Save, Load, Share button functions and scripts<br>
2. Pending: Load scripts and probably previous steps (mesa/recipes/recipeFiles/HTML shared page) and the scripts for saving data of 'Preparation'
3. To solve the previous problem, look at the following message: table/recipes/recipeFiles/ pages loaded directly in the browser:<br>
Last recorded in DB:
Reg.:1680432962|Main Food:potato,milk|Group:Vegetables|Subgroup:Veggies|Preparation: Mashed:Boiled|Weight g:548.00|Energy Kc:300.72 |Title:PotatoesMilk|Author (Country):Western Free Rose|Image:none|Url:|500 g: 270.00 Kc: Potatoes, early, raw: Ref. 1262305078 48 g: 30.72 Kc: Milk, whole, unspecified: Ref. 1262304039
PROCESS<BR>
<u>ONLY RECIPES</u>:<br>
recipes.php (recipes/db): Clear to Search, etc.<br>
<span style='color:red'>recipe database (tmp.db and prep.db)</span><br>
Reg.:1677456990|Main Food:cheese|Group:Dairy|Subgroup:Milk|Preparation: pomu|Weight g:23.24|Energy Kc:66.78 |Title:prueba1|Author (Country):Western Free Rose|Image:|Url:|21 g: 66.70 Kc: Halloumi: Ref. 1262304093 0.21 g: 0.08 Kc: Pepper, chili, green, raw: Ref. 1262305152|1677456990<br>
<span style='color:red'>pars qualitative (quali.db)</span><br>
Reg.:|Main Food:cheese|Group:Dairy|Subgroup:cheese|Preparation: spiced|Weight g:|Energy Kc:42.00 |Title:|Author (Country):|Image:a|Url:<br>
<span style='color:red'>pars quantitative (quanti.db)</span><br>
Reg.:|Main Food:cheese|Weight g:|Energy Kc:42.00 |Prot g:10.20|Carbs g:0.40|Fat g:0.00|satFat g:0.00|Chol g:1.00|Salt g:0.50|Alcoh g:0.00|Fib g:0.00|Omeg g:0.00|Vit C mg:0.00|Ca mg:6.00|Fe mg:0.00|K mg:160.00<br><br>

<span style='color:red'>chef.php (chef/proposedRecipes)</span><br>
Since the proposed file 'Recipes/recipesToChef' is not going to contain progressively expanded content, it can receive full records from 'recipes/recipes.php' for validation. Luego, <br>
1. 'chef/chef.php-Recipes DB' should load and validate them for delivery to 'recipes/db/tmp.db' and 'recipes/db/prep.db' (scripts, buttons and layout hangers). <br>
2. Shared recipe 'recipes/recipeFiles/whatEverTitle.html' must contain scripts to download the recipe data to the external host in the format 'proposedRecipes/recipesToChef file' to be added to the 'proposedRecipes/externalRecipes file'.<br><br>

<u>ONLY MAIN REGISTRIES</u>:<br>
<span style='color:gold'>chef/chef.php-Quanti and Quali (chef/db, chef/import)</span><br>
Its sources are in chef/db/tmp5Nut and import/import.tmp which contains the main database registries that come from mesa/mesa.php-mesa/db/work.csv? (scripts, buttons and layout hangers)<br><br>
mesa.php => create recipe => save recipe (recipes.php) 	=> send to chef (mesa/chef/proposedRecipes/recipesToChef) for corporate approval (chef.php-Recipes DB)<br>
mesa.php => create recipe => share html (recipes.php) 	=> for personal use (end of route)<br>
The chef works the recipes with the page 'mesa/chef/chef.php-Recipes DB' using the short database 'mesa/chef/chefRecipes/tmp5Recipe'. He is helped by the 'Quantitative and Qualitative displays. To search for nutrients and other items using the internal 'time stamps' on the recipe, you need to use the main database with 'mesa/mesa.php (pending search)' in the '1 Reg. No. field' and 'mesa/recipes/recipes .php' in the 'Ingredients field'.<br><br>

There is a database for approved recipes (mesa/recipes/db/tmp.db), which is used by normal users of 'mesa/recipes/recipes.php' to display recipes and send recipes with proposed modifications to the chef (mesa/chef/proposedRecipes/recipesToChef).<br><br>

recipes.php (func. search()) => search.php => search.scr => recipes/db/tmp.db => recipe reg. => display and modify (ok)<br>
recipes.php => 'modified recipe' => save button (Pendent-func. record()) => IT MUST GO: mesa/chef/proposedRecipes/recipesToChef (pendent)
chef.php (Pendent-ver modificar scripts onload-refresh and 'Load list', igual que para imported-import.tmp) => add to mesa/chef/db/tmp5Nut (domestic) (pendent)<br><br>
<span style='color:black'>At this point, most of the tasks in this block are usefully implemented.</span>


<BR><BR>
0. Los registros del archivo doméstico tmp5Nut deben ser 'creados' por 'chef' o bien 'cargados' desde la DB para ser corregidos. Sólo 'chef' tiene potestad para crearlos, corregirlos (o borrarlos) y 'añadirlos' a la DB. En el display se muestran bajo el título 'Domestic'.<br><br>
Los registros del archivo 'mesa/importExport/imported' son externos. Al refrescar la página sólo se cargan los 'domésticos' (chef/db/tmp5Nut) y los muestra. También se añaden los registros de 'mesa/importExport/imported' a los de chef/imported/import.tmp, se eliminan los de 'mesa/importExport/imported', pero no se muestran esos registros. Al pulsar sobre 'Load list' se muestran todos los registros de chef/imported/import.tmp bajo el título 'Imported'.<br><br>
1. Load list (ok)<br>
2. Delete checked records (ok)<br>
3. Export List Script (ok)<br>
4. Qualitative fields. Sources: chef/db/tmp5Nut, chef/imported/import.tmp
</div>

<br><br>
0. CONCEPT <div style='padding-left:20px;'>
1. For safety, DISPLAY-RECORDING are well separated<br>
2. Mesa y recipes són sólo SEARCH-DISPLAY, mientras que chef es SAVE-REMOVE (display lo indispensable)</div><br>
1. Chef no necesita buscador, ya está en mesa y recipes. Tampoco traducir receta ni aprender idiomas.<br>
<div style='padding-left:20px;'>
a. El chef debe supervisar los cambios en las bases de datos.<br>
b. La BD es PREFORMADA en mesa y recipes:
</div>

2. Los form de nutrientes y recipes implican "Load-Edit reg. PREFORMADOS => Modify, Save, Remove".<br>


<div style='padding-left:20px;'>1. Componentes de receta (Tab Recipes).<br>2. Componentes nutritivos (Tab Nutrients), <br></div>
3. <b>En recipes.php se debe resolver YA el problema de los 'steps' para chef.php manejar los registros, por ejemplo, a través de GET (esencial)</b><br>

4. Cargar onload el archivo de 'pendientes mesa/scripts/tmp5' (no complicado))<br>


5. DESARROLLAR Save to DB y Remove (ya está adelantado en recipes)<br>
6. COPIAR Share HTML (simple)<br>
7. VER el uso de los 2 tab que quedan: <div style='padding-left:20px;'>
TAB 2: Form de nutrientes de mesa (Edit, ..., Remove de  reg. PREFORMADOS)<br>
TAB 3: Pendiente. Quizás recursos en general y gráficos como 'image' en particular</div>.
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>





<script>
//put title to the browser tab
window.document.title="Chef";
//get values from url
var link = window.location.href;
//delete data from url
window.history.pushState({page: ""}, "", "chef.php");
//remove location.host
var data=link.split("?")
//Display array element 1
//alert('Los datos ya están en chef/imported/userdb.tmp, pero shareHTML.scr tiene que borrar la página share HTML, que no se repite, y sólo luego añadir el registro, es rápido. Al vuelo se dan para no cortar la rutina del usuario. Hay que sustituir los % por espacios, splitear el string y colocar los elementos en sus lugares\n\n'+data[1])
var forChef=data[1].replace(/%20/gi, ' ')
document.getElementById("forChef").innerHTML=forChef;
var sets=forChef.split('_')
	references=sets[0].split('|')
		document.getElementById("a_0").value=references[0].replace('Reg.:', '');
		document.getElementById("a_7").value=references[7].replace('Title:', '');
		document.getElementById("a_8").value=references[8].replace('Author (Country):', '');
		document.getElementById("a_9").value=references[9].replace('Image:', '');
		document.getElementById("a_10").value=references[10].replace('Url:', '');

		document.getElementById("a_5").value=references[5].replace('Weight g:', '');
		document.getElementById("a_6").value=references[6].replace('Energy Kc:', '');
		document.getElementById("a_1").value=references[1].replace('Main Food:', '');
		document.getElementById("a_2").value=references[2].replace('Group:', '');
		document.getElementById("a_3").value=references[3].replace('Subgroup:', '');
		document.getElementById("a_4").value=references[4].replace('Preparation:', '');


	ingredients=sets[1].split('#')
		elementsIn1=ingredients[0].split('|');elementsIn2=ingredients[1].split('|');elementsIn3=ingredients[2].split('|');elementsIn4=ingredients[3].split('|');
			document.getElementById("a_11").innerHTML=elementsIn1[0]+' g: '+elementsIn1[1]+' Kc: '+elementsIn1[2]+': Ref. '+elementsIn1[3]+'\n'+elementsIn2[0]+' g: '+elementsIn2[1]+' Kc: '+elementsIn2[2]+': Ref. '+elementsIn2[3]+'\n'+elementsIn3[0]+' g: '+elementsIn3[1]+' Kc: '+elementsIn3[2]+': Ref. '+elementsIn3[3]+'\n'+elementsIn4[0]+' g: '+elementsIn4[1]+' Kc: '+elementsIn4[2]+': Ref. '+elementsIn4[3]

	steps=sets[2].split('#')
		elementsSt1=steps[0].split('|');elementsSt2=steps[1].split('|');elementsSt3=steps[2].split('|');
		document.getElementById("a_12").innerHTML=elementsSt1[0]+'\n'+elementsSt1[1].slice(1)+'\n\n'+elementsSt2[0]+'\n'+elementsSt2[1].slice(1)+'\n\n'+elementsSt3[0]+'\n'+elementsSt3[1].slice(1)


</script>

<script>
//display recipe reg items
function showReg(regId){

//alert(regId+', '+document.getElementById('a_0').value)
references=document.getElementById('ref_'+regId.replace('reg_', '')).innerHTML
references=references.split('|');
//alert(document.getElementById('ref_'+regId.replace('reg_', '')).innerHTML)

//references, etc
		for (i=0;i<11;i++){
	val=references[i].split(':')
	document.getElementById('a_'+i).value=val[1]
		}
//ingredients
var ingJs=document.getElementById('ing_'+regId.replace('reg_', '')).innerHTML
	ingJs=ingJs.split('|');
		var ingJsT=''
//let str = "Reg. 1232 n";
var pattern = /^[\d.]*\s*g.*$/;
var str=''

		for (i=0;i<ingJs.length;i++){
			ingJsItem=ingJs[i].split(':');
str=ingJsItem[0]
//alert(str)
if (str.match(pattern)) {
  //alert("Found a matching substring!");
ingJsT=ingJsT+''+ingJsItem[0]+': '+ingJsItem[1]+': '+' '+ingJsItem[2]+': '+' '+ingJsItem[3]+'\r\n';
} else {
  //alert("No matching substrings found.");
ingJsT=ingJsT+''+ingJsItem[0]+'\r\n';
}
//if (str.match(pattern)) {alert(ingJsItem[3])};fi //else{alert('not match')};fi

//alert(ingJsT)
		}
			document.getElementById('a_11').value=ingJsT
//steps
var ingJs=document.getElementById('ste_'+regId.replace('reg_', '')).innerHTML
	stepsM=ingJs.split('|');
		var ingJsT='';
		for (i=0;i<stepsM.length;i++){
		stepsm=stepsM[i].split('#')
let searchWord = "Step";
		n=i+1;
			for (j=0;j<stepsm.length;j++){
let myString = stepsm[j];
				if (myString.includes(searchWord)) {
					ingJsT=ingJsT+'Step '+n+'\r\n'
				} else {
					ingJsT=ingJsT+''+stepsm[j]+'\r\n\n'
				}
			}
		}
document.getElementById('a_12').value=ingJsT
}
///////////////////////////////////////////


function alternateAddRpl(thisAoR){
	if (document.getElementById(thisAoR).checked == true) {
	document.getElementById('AddReg').checked = false;
	document.getElementById('RplReg').checked = false;
	document.getElementById(thisAoR).checked = true;}
}



////////////////////////////////////////////////
var accumulate=''
function pendings(optFlag){
document.getElementById("msgChef").style.color = 'white';document.getElementById("msgChef").style.fontSize = '12px';document.getElementById("msgChef").style.fontWeight= 'normal';
//alert('pendings(optFlag): '+optFlag)
accumulate=''
//alert(accumulate)
ctrl=0
valDelLength=document.getElementsByClassName('delVal').length
//alert(valDelLength)
//alert(valDelLength)
	//serie of ids
    for(var i = 0;i<valDelLength;i++) {
        if (document.getElementsByClassName('delVal')[i].checked) {
			numReg=document.getElementsByClassName('delVal')[i].id.split('_');
			//document.getElementById('delete_'+numReg[1]).style.display='none'
			document.getElementById('check_'+numReg[1]).checked = false;
ctrl=1;
accumulate=accumulate+'|'+numReg[1];	//to be sent to PHP
        }
	}
//add to accumulate the checkbox addReg or rplReg checked
if (document.getElementById('AddReg').checked == true) {accumulate='add'+accumulate;/*alert("AddReg true; accumulate: "+accumulate)*/}
if (document.getElementById('RplReg').checked == true) {accumulate='replac'+accumulate;/*alert("RplReg true; accumulate: "+accumulate)*/}
//alert(accumulate+' . To be sent to '+regId+' regs');
if (ctrl == 0) {document.getElementById("msgChef").innerHTML = 'Before clicking a button, check all the boxes whose records you want to delete or validate.';document.getElementById("msgChef").style.fontSize = '16px';document.getElementById("msgChef").style.fontWeight= 'bold';msgChef.animate([{opacity:0},{opacity:1}],{duration:3000,iterations:3});exit;}


	document.getElementById('AddReg').checked = false;
	document.getElementById('RplReg').checked = false;
//alert('pending(optFlag) envía los ids acumulados optFlags: '+optFlag+', accumulate: '+accumulate)
pendingsRecipes('scripts/pendingRecipes.php',optFlag,accumulate)
}

function pendingsRecipes(phpToRun,optFlag,strSet){
//alert('entra pendingRecipes(phpToRun,optFlag,strSet): '+phpToRun+' ,'+optFlag+' ,'+strSet+'')
var dataToBeSent="flagBell="+optFlag+"&dataDeal='"+strSet+"'"; //(URL-encoded format)
alert('dataToBeSent: '+dataToBeSent)
//exit
//alert('dataToBeSent to scripts/pendingRecipes.php: '+dataToBeSent)
	const xhr = new XMLHttpRequest();
	xhr.open("POST", phpToRun, true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhr.onreadystatechange = function ()
			{if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {var text=xhr.responseText;
//alert('Aquí tengo que intervenir y revertir delete HTML de los validate: '+text);
document.getElementById('msgChef').innerHTML=text;
//alert('llega Msg, variable txt')
//document.getElementById('theMsg').innerHTML=document.getElementById('theMsg').innerHTML.slice(1).replace(/\s/g, '');
//alert('inserta Msg, sin coma final')
strSet=strSet.split('|')
//alert('strsSet[0]: '+strSet[0])
recoverItems=document.getElementById('theMsg').innerHTML.split(",")
var deletedRegs=''
//alert('recoverItems: '+recoverItems)
    for(var i = 0;i<recoverItems.length;i++) {
//alert(recoverItems[i])
//alert(document.getElementById('reg_'+recoverItems[i]).style.color)
		if (document.getElementById('reg_'+recoverItems[i]).style.color == 'red'){
			//alert('red')
			deletedRegs=deletedRegs+' '+recoverItems[i]
				if (optFlag == 'validate'){
					if (strSet[0] !== ''){
document.getElementById('msgChef').innerHTML='<span style="color:black">Deleted</span> (in userdb.tmp), and <span style="color:gold">'+strSet[0]+'ed</span> (to tmp.db and prep.db): <span id="theMsg" style="color:gold">'+deletedRegs+'</span>'}
else{
document.getElementById("msgChef").innerHTML = 'You must use Add/Replace options to delete or validate.';
document.getElementById("msgChef").style.fontSize = '16px';
document.getElementById("msgChef").style.fontWeight= 'bold';
msgChef.animate([{opacity:0},{opacity:1}],{duration:3000,iterations:2});
document.getElementById('delete_'+recoverItems[i]).style.display='block';;}
				}else{
				document.getElementById('msgChef').innerHTML='Not validated. <span id="theMsg" style="color:black">Deleted</span> in userdb.tmp: <span id="theMsg" style="color:gold">'+deletedRegs+'</span>'
				}
		}else{
				if (optFlag == 'validate'){
				document.getElementById('delete_'+recoverItems[i]).style.display='block';
				document.getElementById('reg_'+recoverItems[i]).style.color='red';}
		}
	}

}
ramC('scripts/test.php','Null','forChef')
		};
	xhr.send(dataToBeSent);
}

</script>
</body></html>
