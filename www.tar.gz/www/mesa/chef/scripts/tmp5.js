function tmp5(theId){

alert(document.getElementById(theId+'bis').innerHTML);
tmp5Arr=document.getElementById(theId+'bis').innerHTML.split('|');

document.getElementById('f23').innerHTML='';
document.getElementById('f24').innerHTML='';
/*Since the set starts at 'theId' then the 10th should be the 9th,
/*and since the array starts at [0] then the 9th must be the 8th => [0] is '02'(g:Sg), [1] is '04'(madeOf), ... and [40] is '42'(pot).
/*the sets of 'ids' fn and Fn are just for display, equal ids for equal or different places.*/
document.getElementById('f1').innerHTML=theId;/*reg01F1*/;document.getElementById('F1').innerHTML=theId;/*timestamp*/
document.getElementById('f2').innerHTML=tmp5Arr[0];/*g:SgO2F2*/;document.getElementById('F2').innerHTML=tmp5Arr[0];
document.getElementById('f3').innerHTML=tmp5Arr[1];/*madeOfO3F3*/;document.getElementById('F3').innerHTML=tmp5Arr[1];/*MadeOf*/
document.getElementById('f25').innerHTML=tmp5Arr[8];/*FoodItem*/;
document.getElementById('f4').innerHTML=tmp5Arr[8];/*foodItem10F4*/;document.getElementById('F4').innerHTML=tmp5Arr[2];/*variety*/
document.getElementById('f22').innerHTML=tmp5Arr[10];/*kc%12F22*/
document.getElementById('f7').innerHTML=tmp5Arr[11];/*fat13F7*/;document.getElementById('F7').innerHTML=tmp5Arr[5];/*AddedItems*/;
document.getElementById('f8').innerHTML=tmp5Arr[12];/*satFat14F8*/;document.getElementById('F8').innerHTML=tmp5Arr[6];/*consistency*/;
document.getElementById('f13').innerHTML='omegaO16-17F13';/*omega16-17F13*/
document.getElementById('f9').innerHTML=tmp5Arr[16];/*omega16-17F13*/;document.getElementById('F9').innerHTML=tmp5Arr[7];/*presentation*/;
document.getElementById('f6').innerHTML=tmp5Arr[17];/*hc19F6*/;document.getElementById('F6').innerHTML=tmp5Arr[4];/*substract*/;
document.getElementById('f12').innerHTML=tmp5Arr[21];/*fib23F12*/;
document.getElementById('f5').innerHTML=tmp5Arr[22];/*prot24F5*/;document.getElementById('F5').innerHTML=tmp5Arr[3];/*equalBut*/;
document.getElementById('f10').innerHTML=tmp5Arr[23];/*salt25F10*/;document.getElementById('F10').innerHTML=tmp5Arr[8];/*foodItem*/;
document.getElementById('f11').innerHTML=tmp5Arr[24];/*alcoh26F11*/
document.getElementById('f14').innerHTML=tmp5Arr[25];/*vita27F14*/
document.getElementById('f17').innerHTML=tmp5Arr[28];/*vitd30F17*/
document.getElementById('f18').innerHTML=tmp5Arr[29];/*vite31F18*/
document.getElementById('f15').innerHTML='vitbO32-37F15';/*vitb32-37F15*/
document.getElementById('f16').innerHTML=tmp5Arr[36];/*vitc38F16*/
document.getElementById('f19').innerHTML=tmp5Arr[37];/*ca39F19*/
document.getElementById('f20').innerHTML=tmp5Arr[38];/*fe40F20*/
document.getElementById('f21').innerHTML=tmp5Arr[40];/*pot42F21*/
/*'reg01F1' 'gSgO2F2' 'madeOfO3F3' 'foodItem10F4' 'kc%12F22' 'fat13F7' 'satFat14F8' 'omega16-17F13' 'chol18F9' 'hc19F6' 'fib23F12' 'prot24F5' 'salt25F10' 'alcoh26F11' 'vita27F14' 'vitd30F17' 'vite31F18' 'vitb32-37F15' 'vitc38F16' 'ca39F19' 'fe40F20' 'pot42F21'*/
93(01f1 Reg)_2:eggs-fish(02f2 g:sg)_cod-roe(03f3 MadeOf)_[04 variety_05 EqualBut_06 Substract_07 Add_08 Consistency_Cod roe, compressed, canned(10f4 FoodItem)_27.1(24F5 P)_0(19f6 HC)_1.9(13f7 G)_0.4(14f8 satfat)_330(18f9 cho)_0.3(25f10 sal)_0(26f11 alcoh)_0(23f12 fib)_.64(16-17f13 Om)_79(27f14 A)_23.86(32-37f15 B)_0(38f16 C)_18(30f17 D)_6.2(31f18 E)_11(39f19 Ca)_1(40f20 Fe)_170(42f21 K)_126(12f22 kc)



};
