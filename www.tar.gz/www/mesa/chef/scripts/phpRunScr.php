<?php
	$dataBash=exec("echo $(./bashScript.scr ".$_POST['name'].")");
	echo $dataBash;
?>
