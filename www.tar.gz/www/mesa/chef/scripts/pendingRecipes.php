<?php
	#$dataBash=exec("echo $(./test.scr mierda)");
$dataBash=exec("echo $(./pendingRecipesALGORITHM.scr ".$_POST['flagBell']." ".$_POST['dataDeal'].")");
	echo $dataBash;
?>
