<?php

$dataBash=exec("echo $(./pendingRecipesALGORITHM.scr ".$_POST['flagBell']." ".$_POST['dataDeal'].")");
	echo $dataBash;
?>
