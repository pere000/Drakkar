<?php
	$dataBash=exec("echo $(./export.scr ".$_POST['idCollection'].")");
	//echo $dataBash;
?>
