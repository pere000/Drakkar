<!DOCTYPE html>
<html>
<head>
<!--
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
-->
<link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
<style>
body {width:94.9%;background-color:#696969;color: white;font-size: 12px;
font-family: "Verdana", sans-serif;}


.box {display:flex;width:103.7%;margin-left:1%;font-size:12px;}
.one{flex-direction:column;width:15%;color:gold;font-weight:bold;font-size:12px;text-align:left;}
.two{width:40%;color:gold;margin-right:15px;font-weight:bold;}
.three{width:40%;color:gold;font-weight:bold;}
.four{flex-direction:column;width:15%;padding:0 0px 0 15px;color:navy;font-weight:bold;}
.divButton{cursor:pointer;width:150px;margin:2px 0 2px 0;background: gold;border: solid 0.01em yellow;border-radius: 10px 40px 40px 10px;}
.divButton:hover {flex: 1 1 10%;cursor:pointer;background: yellow;border: solid 0.1em gold;border-radius: 10px 40px 40px 10px;}
.divButton[name='up']{cursor:pointer;width:150px;margin:19px 0 2px 0;background: gold;border: solid 0.01em yellow;border-radius: 10px 40px 40px 10px;}
.divButton[name='up']:hover {flex: 1 1 10%;cursor:pointer;background: yellow;border: solid 0.1em gold;border-radius: 10px 40px 40px 10px;}
.divButton[name='down']{cursor:pointer;width:150px;margin:10px 0 0px 0;background: gold;border: solid 0.01em yellow;border-radius: 10px 40px 40px 10px;}
.divButton[name='down']:hover {flex: 1 1 10%;cursor:pointer;background: yellow;border: solid 0.1em gold;border-radius: 10px 40px 40px 10px;}
.one1{flex-direction:column;width:15%;color:white;font-weight:bold;}
.two1{width:41%;color:white;font-weight:bold;}
.three1{width:40%;color:white;font-weight:bold;}
.four1{width:15%;padding:0 0px 0 15px;color:white;font-weight:bold;}
input[type='text']{font-size:12px;color:black;}
textarea{width:100%;height:96%;padding:5px 5px 0 5px;font-size:12px;color:black;}

.menuA {display:flex; flex-direction:row;column-gap:8px;justify-content:left;color:yellow;font-weight:bold;}
.optionA {cursor:pointer;flex: 0 1% 10%;color: yellow;transition: all 2s;}
.optionA:hover {flex: 1 1 10%;}
.colonsW {color:white;}

.menuB {display:none;flex-direction:row;column-gap:8px;justify-content:left;font-weight:bold;color:white;}
.optionB {cursor:pointer;flex: 0 1% 10%;color:gold;}
.optionB:hover {flex: 1 1 10%;}

.menuC {flex-direction:row;column-gap:8px;justify-content:left;font-weight:bold;}
.optionC {display:none;column-gap:8px;cursor:pointer;flex: 0 1% 10%;font-weight:bold;color:gold;transition: all 2s;margin-left:12px;}
.optionC:hover {flex: 1 1 10%;}

#c1 {flex-wrap:wrap;color:black;padding: 10px 5px 10px 12px;display:none;}
.magnum {cursor:pointer;color:gold;}
.magnum_ {cursor:pointer;color:white;}

.showRecipe{color:yellow;padding-left:10px;color:yellow;}
.showTitle{padding-left:10px;}
.showContent{padding-left:20px;color:white;}

.uno {width:100%;margin-left:1%;margin-top:5px;color:white;}
.dos {width:100%;margin-left:1%;margin-top:4px;color:yellow;}
.tres {width:100%;padding-left:7%;}
.cuatro {width:90%;}
.tab {background-color:#FAFAD2;width:100%;;padding-left:4px;}
.color{color:yellow;width:100%;}

button.buttonA{
background-color:#FAFAD2;cursor:pointer;width:120px;margin-bottom:5px;margin-top:2px;
}
button.buttonB{
cursor:pointer;width:120px;margin-top:10px;
}

#searchBox{background-color:#FAFAD2;}
#searchDB{color:#696969;font-weight:bold;}
#Replace{color:#696969;font-weight:bold;}
button[type='button']{font-size:12px;cursor:pointer;width:120px;color:black;}
table.google{margin-left:auto;margin-right:auto;margin-top:20px;padding-left:4.2%;text-align:center;color:black;}
div[name='selectMessage']{margin-bottom:10px;background-color:#DCDCDC;color:black;}
div[name='heads']{text-align:center;margin-bottom:5px;color:yellow;}
div[name='grandblock']{width:100%;margin-left:1%;color:black;}
.ref{float:left;width:95%;margin-bottom:7px;background-color:#FAFAD2;'}
.classX {
  list-style: none;
  margin: 0;
  overflow: hidden;
  padding: 0;
}

.classX tagX {
  float: left;
}

tagX.classX {


}

tagA,
tagB,
tagX {

}

#idX {

}

imgX {

}

</style>

<script>
//necesariamente global variables
var base_url=window.location.origin;
var vFileA = '';
var vFile = "";
var fileSplit=''

var reg=''
var title=''
var author=''
var country=''
var url=''
var ingredients=''
var steps=''
var foodNames=''

//var quantitativedb=''
//var qualitativedb=''

var pasosPage=''
var referencesFile=''
var fileSent=''
var saveReg=''
//recipe fields
var reg='';var weight='';var kc='';var prot='';var carbs='';var fat='';var satFat='';var chol='';var salt='';var alcoho='';var fib='';var omeg='';var vitc='';var ca='';var fe='';var k='';var filename='';var mainfoods='';var g='';var sg='';var treat='';

const tx = document.getElementsByTagName("textarea");
	for (let i = 0; i < tx.length; i++) {
	  tx[i].setAttribute("style", "height:" + (tx[i].scrollHeight) + "px;overflow-y:hidden;");
	  tx[i].addEventListener("input", OnInput, false);
	}

/*function txtLineByLine(){
//document.getElementById('file').value='';
var vFileFilter = document.getElementById('title').value;
	if (vFileFilter == "") {
	alert("The 'Title' can not be empty. Exit.");exit;}
	else{
fileSplit=fileSent.split('#');
vFileFilter=fileSplit[0].split('|')
document.getElementById('title').value=''
vTitle=vFileFilter[0].split('.')
	document.getElementById('title').value=vTitle[0]



	};
document.getElementById('ingredients').innerHTML = document.getElementById('ingredients').innerHTML.trim();
document.getElementById('steps').innerHTML = document.getElementById('steps').innerHTML.trim();

referencesFile='Title: '+document.getElementById('title').value.replace(/(^|\s)\S/g, l => l.toUpperCase())+' | Group: '+document.getElementById('g').value.replace(/(^|\s)\S/g, l => l.toUpperCase())+' | Subgroup: '+document.getElementById('sg').value.replace(/(^|\s)\S/g, l => l.toUpperCase())+' | Main Food: '+document.getElementById('popFoodName').value.replace(/(^|\s)\S/g, l => l.toUpperCase())+' | File: '+document.getElementById('file').value.replace(/(^|\s)\S/g, l => l.toUpperCase())+' | Author: '+document.getElementById('author').value.replace(/(^|\s)\S/g, l => l.toUpperCase())+' | Image: '+document.getElementById('country').value.replace(/(^|\s)\S/g, l => l.toUpperCase())+' | Url: '+document.getElementById('url').value.replace(/(^|\s)\S/g, l => l.toUpperCase())

document.getElementById('referencesPage').innerHTML=referencesFile
document.getElementById('refPage').innerHTML=referencesFile
//alert(referencesFile)
//leer linea a linea textarea
	var textArea = document.getElementById('ingredients');
	//create and fill VARIABLE 'linesIngrd' array
	var lines__Ingrd = textArea.value.split('\n');    // lines is an array of strings
	var ingredientes='';losingredientes=''
	for (var i = 0; i < lines__Ingrd.length; i++) {														//los id de salida 6,7,... las veces de linesIngrd.length
		ingredientes=ingredientes + lines__Ingrd[i] + ':'
losingredientes=losingredientes+lines__Ingrd[i]+'<br>'
	}

document.getElementById('ingredientes').innerHTML=ingredientes.slice(0,-1)
document.getElementById('ingPage').innerHTML=losingredientes
//alert(losingredientes)
//leer linea a linea textarea
	var textArea = document.getElementById('steps');

	//create and fill VARIABLE 'linesIngrd' array
	var line_Ingrd = textArea.value.split('\n');    // lines is an array of strings
	var pasos='';pasosPage='';
	for (var i = 0; i < line_Ingrd.length; i++) {														//los id de salida 6,7,... las veces de linesIngrd.length
		pasos=pasos + line_Ingrd[i] + ':'
pasosPage=pasosPage+line_Ingrd[i]+'<br>'
	}

document.getElementById('stepes').innerHTML=pasos.slice(0,-1)
document.getElementById('stepPage').innerHTML=pasosPage
//alert(pasosPage)

}*/

/*
function record(){
//block saveing
alert('Needs: Blocking items')
//Recipe records. Get form elements.
//In Quantitative DB...........................Warning Usar document.getElement.....
quantitativedb='Reg.:'+document.getElementById('file').value+'|Main Food:'+document.getElementById('popFoodName').value+'|Weight g:'+weight+'|Energy Kc:'+kc+'|Prot g:'+prot+'|Carbs g:'+carbs+'|Fat g:'+fat+'|satFat g:'+satfat+'|Chol g:'+chol+'|Salt g:'+salt+'|Alcoh g:'+alcoh+'|Fib g:'+fib+'|Omeg g:'+omeg+'|Vit C mg:'+vitc+'|Ca mg:'+ca+'|Fe mg:'+fe+'|K mg:'+k
//alert(quantitativedb)

//In Qualitative DB
qualitativedb='Reg.:'+document.getElementById('file').value+'|Main Food:'+document.getElementById('popFoodName').value+'|Group:'+document.getElementById('g').value+'|Subgroup:'+document.getElementById('sg').value+'|Preparation: '+document.getElementById('treat').value+'|Weight g:'+weight+'|Energy Kc:'+kc+'|Title:'+document.getElementById('title').value+'|Author (Country):'+document.getElementById('author').value+'|Image:'+document.getElementById('country').value+'|Url:'+document.getElementById('url').value
//alert(qualitativedb)
var savetodb=quantitativedb+'#'+qualitativedb

//ajax send to mesa/scripts/ajaxSaveRecipe.php => mesa/scrpts/saveRecipe.scr => quanti.db, quali.db
    //Create an XMLHttpRequest object
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/ajaxSaveRecipe.php";
    //saveRecipe data on the client-side is sent to ajaxSaveRecipe.php PHP script on the server-side
    var fn = savetodb;
    	var vars = "group="+'\''+fn+'\'';
//alert(fn)
//alert('ok vars '+vars)
    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				var return_data = hr.responseText;
				document.getElementById("saveMessage").innerHTML = 'Saved to DB';
			}

		}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);
    //HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
    document.getElementById("saveMessage").innerHTML = "processing...";







/*save to descargas by only javascript
var text = document.getElementById("description").innerHTML;
var a = document.createElement("a");
a.href = window.URL.createObjectURL(new Blob([text], {type: "text/plain"}));
a.download = qualitativedb+'.html';
a.click();

}
*/
function showHide(){
if (document.getElementById('instrucciones').style.display === 'none') {
        document.getElementById('instrucciones').style.display='block'
    }
else
	{
		document.getElementById('instrucciones').style.display='none'
	}
}

/*function changeDB(){
//alert(document.getElementById('searchBox').checked)
	if (document.getElementById('searchBox').checked){
	document.getElementById('searchDB').innerHTML='Qualitative DB'
	}
	else{
	document.getElementById('searchDB').innerHTML='Quantitative DB'
	}
}*/

var ctrlOrderToSearch='0';var sequence=1;var mem='';var orderToScr='';var orderToScrPlus=''
var idMem=1;




var clearToSearchMode='false';

function clearToSearch(){
//alert('ctrlOrderToSearch: '+ctrlOrderToSearch+', sequence: '+sequence+', idMem: '+idMem+', mem: '+mem+', orderToScr: '+orderToScr+', vtarget: '+vtarget+', vpatterns: '+vpatterns)

//sólo debe funcionar si se ha pulsado clearToSearch => debe estar marcado clearToSearchCtrl='searchMode'
	if (clearToSearchMode == 'false'){

		clearToSearchMode='true';
		document.getElementById('gridMode').innerHTML='Search'

		//document.getElementById('stepsA').style.visibility = 'hidden';
		//document.getElementById('stepsB').style.visibility = 'hidden';

		showSearchDisplay()
	}else{
		//alert("You enter in edit mode.");
		//document.getElementById('stepsA').style.visibility = 'visible';
		//document.getElementById('stepsB').style.visibility = 'visible';
		document.getElementById('gridMode').innerHTML='Edit'

		restart();
		exit;
	}

//you enter search mode
document.getElementById('p_2').style.checked = true;

document.getElementById('gridMode').innerHTML='Search'
ctrlOrderToSearch='1';
sequence=1;mem='';orderToScr='';vtarget='';vpatterns='';idMem=1;

///////////////////////
document.getElementById('file').readOnly = false;   //to  disable readonly
	document.getElementById('file').style.backgroundColor="white";document.getElementById('file').style.color='black';
document.getElementById('ingredients').readOnly = false;   //to  disable readonly
	document.getElementById('ingredients').style.backgroundColor="white";
	document.getElementById('ingredients').style.color='black';
document.getElementById('steps').readOnly = false;   //to  disable readonly
document.getElementById('g').readOnly = false;   //to  disable readonly
	document.getElementById('g').style.backgroundColor="white";document.getElementById('g').style.color='black';
//document.getElementById('description').style.visibility='hidden';
//document.getElementById('showSearch').zIndex = "2";
//////////////////// = make an array and a for loop
//file,ingredientes,g,sg,popFoodName,steps,country,title,url,treat
document.getElementById('file_').innerHTML=''
document.getElementById('title_').innerHTML=''
document.getElementById('author_').innerHTML=''
document.getElementById('country_').innerHTML=''
document.getElementById('url_').innerHTML=''
document.getElementById('ingredients_').innerHTML=''
document.getElementById('steps_').innerHTML=''
document.getElementById('popFoodName_').innerHTML=''
document.getElementById('g_').innerHTML=''
document.getElementById('sg_').innerHTML=''
document.getElementById('treat_').innerHTML=''
////////////////////

document.getElementById('url').innerHTML=''
document.getElementById('treat').innerHTML=''

///////////////////
		ingredients=document.getElementById('ingredients').value;
		steps=document.getElementById('steps').value;
		reg=document.getElementById('file').value;
		title=document.getElementById('title').value;
		author=document.getElementById('author').value;
		country=document.getElementById('country').value;
		url=document.getElementById('url').value;
		foodNames=document.getElementById('popFoodName').value;
		kcal=document.getElementById('kcal').value;
		g=document.getElementById('g').value;
		sg=document.getElementById('sg').value;
		treat=document.getElementById('treat').value;

			document.getElementById('ingredients').value=''
			document.getElementById('steps').value="This is just a reminder box.\n\n1. The minimum data is 1 STR.\n2. The '@' can be part of the STR in the Image or the Url box.\n3. The search content is in the box with the lowest number.\n4. Don't use disruptive characters, '^\"&$|\!#, more than one '@' symbol, protocols such as 'http://, or more than 1 STR in the Reg No, Image or URL box.\n\n***. In boxes except 8 and 9: right click to delete content, left click to paste."
			alert(ingredients)
			document.getElementById('file').value='';
			document.getElementById('title').value='';
			document.getElementById('author').value='';
			document.getElementById('country').value='';
			document.getElementById('url').value='';
			document.getElementById('popFoodName').value='';
			document.getElementById('kcal').value='';

			document.getElementById('g').value='';document.getElementById('sg').value='';
			document.getElementById('treat').value='';

}

function restart() {
//alert('You enter in Edit Mode')
document.getElementById('gridMode').innerHTML='Edit'
clearToSearchMode='false';ctrlOrderToSearch='0';sequence=1;mem='';orderToScr=''
///////////////////////
////////////////////previous values
document.getElementById('file').value=reg
document.getElementById('title').value=title
document.getElementById('author').value=author
document.getElementById('country').value=country
document.getElementById('url').value=url
document.getElementById('ingredients').value=ingredients
document.getElementById('steps').value=steps
document.getElementById('popFoodName').value=foodNames
document.getElementById('kcal').value=kc
document.getElementById('g').value=g
document.getElementById('sg').value=sg
document.getElementById('treat').value=treat

//file,ingredientes,g,sg,popFoodName,steps,country,title,url,treat
document.getElementById('file_').innerHTML=''
document.getElementById('title_').innerHTML=''
document.getElementById('author_').innerHTML=''
document.getElementById('country_').innerHTML=''
document.getElementById('ingredients_').innerHTML=''
document.getElementById('steps_').innerHTML=''
document.getElementById('popFoodName_').innerHTML=''
document.getElementById('g_').innerHTML=''
document.getElementById('sg_').innerHTML=''
////////////////////readonly and colors
document.getElementById('file').readOnly = true;   //to  disable readonly
document.getElementById('file').style.backgroundColor="navy";document.getElementById('file').style.color='white';
document.getElementById('ingredients').readOnly =false;   //to  disable readonly
document.getElementById('ingredients').style.color='black';
document.getElementById('g').readOnly = true;   //to  disable readonly
//document.getElementById('description').style.visibility='visible';
//document.getElementById('showSearch').zIndex = "0";

document.getElementById('p_2').checked=true;
}

    window.onload = function () {
        document.onkeydown = function (e) {
            return (e.which || e.keyCode) != 116;
        };
    }
window.onbeforeunload = function (e) {
    var e = e || window.event;

    // For IE and Firefox
    if (e) {
        e.returnValue = 'Leaving the page';
    }

    // For Safari
    return 'Leaving the page';
};


function shareHTML(flagToShare){

flagToShare=flagToShare;

//get qualitative database data to share as an HTML
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/shareHTML.php";
    //saveRecipe data on the client-side is sent to ajaxSaveRecipe.php PHP script on the server-side
var treatField=document.getElementById('treat').value;
if (document.getElementById('treat').value.charAt(document.getElementById('treat').value.length - 1) === ":") {document.getElementById('treat').value = document.getElementById('treat').value.slice(0, -1);}

text_area = document.getElementById("ingredients");
text_area.value += "\n"; // Append a new line
lines = text_area.value.split("\n");
accumulate_ingredients=''
for (i=0;i< lines.length;i++) {
accumulate_ingredients=accumulate_ingredients+'#'+lines[i]
}

text_area = document.getElementById("steps");
lines = text_area.value.split("\n");
accumulate_steps=''
for (i=0;i< lines.length;i++) {
accumulate_steps=accumulate_steps+'#'+lines[i]
}
accumulate_steps=accumulate_steps.replace(/##/g, "#")

    var fn =flagToShare+'|Reg.:'+document.getElementById('file').value+'|Main Food:'+document.getElementById('popFoodName').value+'|Group:'+document.getElementById('g').value+'|Subgroup:'+document.getElementById('sg').value+'|Preparation: '+document.getElementById('treat').value+'|Weight g:'+weight+'|Energy Kc:'+document.getElementById('kcal').value+'|Title:'+document.getElementById('title').value+'|Author (Country):'+document.getElementById('author').value+'|Image:'+document.getElementById('country').value+'|Url:'+document.getElementById('url').value+'|'+accumulate_ingredients+'|'+accumulate_steps;


//filter
filter=document.getElementById('file').value+document.getElementById('popFoodName').value+document.getElementById('g').value+document.getElementById('sg').value+document.getElementById('treat').value+document.getElementById('title').value+document.getElementById('author').value+document.getElementById('country').value+document.getElementById('url').value+accumulate_ingredients+accumulate_steps
searchWord = /[()|&]/;
result = searchWord.test(filter);

if (result == true){alert("Remove 'Step (your turn to continue ...)'. Check not allowed characters: ()&|");exit};

    	var vars = "group="+'\''+fn+'\'';
    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				var return_data = hr.responseText;
				//document.getElementById("saveMessage").innerHTML = '<i>On-the-fly sharing done.</i>';

			}

		}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);
alert('vars '+vars)
    //HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
    //document.getElementById("saveMessage").innerHTML = "processing...";

if (flagToShare == 'share'){
title=document.getElementById('title').value.replace(/ /g, "")
window.open(base_url+'/mesa/recipes/recipeFiles/'+document.getElementById('file').value+'_'+title+'.html')
}

      var xmlhttp;
      if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
      }
      else {
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      xmlhttp.onreadystatechange=function() {
        //alert (xmlhttp.status);
        if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		recipesImporting=xmlhttp.responseText
		recipesImporting=recipesImporting.split('|');

recipeFiles=recipesImporting[0];importing=recipesImporting[1];
inString='*.html'

if (importing.includes(inString) == true){
document.getElementById('importing').innerHTML='<span style="padding-left:10px;color:#D2691E;">The import file folder is empty.</span>';
document.getElementById('recipeFiles').innerHTML=recipeFiles;
}else{
document.getElementById('importing').innerHTML=importing;
document.getElementById('recipeFiles').innerHTML=recipeFiles;

}

        }
      }
      xmlhttp.open("GET","../importExport/importing/resources/recipeFilesJoinedImporting.txt",true);
      xmlhttp.send();


}

function search(){
//orderToScrSend='';orderToScrMinus='';orderToScrPlus='';
arr=['file','title','author','country','url','popFoodName','g','sg','treat','ingredients']

	for (i = 0; i < arr.length; i++) {
		theValue=document.getElementById(arr[i]).value
		if (theValue !== '') {
			searchValue=document.getElementById(arr[i]).value;
			fieldName=document.getElementById(arr[i]).id;
		break;
			}
	}
//got: fieldName, searchValue, pattern (true/false)
pattern=document.getElementById('p_2').style.checked
alert('fieldName: '+fieldName+' searchValue: '+searchValue+' pattern: '+pattern)
//exit
//why doesn't it works?


//alert('recipe search function to search PHP')
//locking filter
//if (vtarget == '' || vpatterns =='' || orderToScr ==''){alert('Not allowed. Reguired: Target and Pattern checked, and at least 1 value for searching.');exit;}
//alert(vtarget+', vpatterns: '+vpatterns+', orderToScr: '+orderToScr)
//get values of document.getElementById(?orderToSearch).value
//file,ingredients,steps es orderToScr
//alert('orderToScr 1 (bien): '+orderToScr)
//orderToScrMinus=orderToScr.substring(1)
//alert('orderToScrMinus 1 (bien): '+orderToScrMinus)

//orderToScrPlus=orderToScr;
//alert('orderToScrPlus 1 (bien): '+orderToScrPlus)
//orderToScrMinusPlus=orderToScrPlus.substring(1)
//alert('orderToScrMinusPlus 1 (bien): '+orderToScrMinusPlus)

//let splitOrderToScr=orderToScrMinus.split(',');
//alert('verifica split: '+splitOrderToScr[3]+' length: '+splitOrderToScr.length)

//let splitOrderToScrPlus=orderToScrMinusPlus.split(',');


//for(i=0;i<splitOrderToScr.length;i++){
	//alert('entra');
	//orderToScrSend=orderToScrSend+splitOrderToScrPlus[i]+','+document.getElementById(splitOrderToScr[i]).value+',';
//}
//alert('ordertoscrsend '+orderToScrSend.replace(/,$/, ''))
//alert('orderToScrSend: '+orderToScrSend.replace(/,$/, ''))
//orderToScrSend=orderToScrSend.replace(/,$/, '')




    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "scripts/search.php";
    //saveRecipe data on the client-side is sent to ajaxSaveRecipe.php PHP script on the server-side
    var fn = fieldName+'#'+searchValue+'#'+pattern;

    	var vars = "group="+'\''+fn+'\'';
//alert('ccccsend...: '+fn)
//alert('ok vars '+vars)
    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				var return_data = hr.responseText;
				document.getElementById("resultBash").innerHTML = return_data;

			}

		}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);
    //HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
    document.getElementById("resultBash").innerHTML = "processing...";

}
function banban(benben){
toImport()
//beben data sender function to banban.php operator for beben.scr data processor

    var hr = new XMLHttpRequest();
    var url = "scripts/banban.php"; // binbin,bonbon,bunbun,banban
    	var vars = "benben="+'\''+benben+'\'';

    hr.open("POST", url, true);
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				var ingJs=hr.responseText

	stepsM=ingJs.split('_');	//0,1,2

n=1;ingJsT='';searchWord = "Step";accumulate=''

//references
ref=stepsM[0].split('|')

	rVal=ref[0].split(':')
	document.getElementById('file').value=rVal[1]
	rVal=ref[7].split(':')
document.getElementById('title').value=rVal[1]
	rVal=ref[8].split(':')
document.getElementById('author').value=rVal[1]
	rVal=ref[9].split(':')
document.getElementById('country').value=rVal[1]
	rVal=ref[10].split(':')
document.getElementById('url').value=rVal[1]

//ingredients
//ing=stepsM[1].split('|')
	iVal=stepsM[1].split('#')
		document.getElementById('ingredients').value=iVal[0]

				for (i=0;i<iVal.length;i++){
				accumulate=accumulate+'\r\n'+iVal[i]


				}
document.getElementById('ingredients').value=accumulate.trim().replace(/^\s*[\r\n]/gm, '')

		stepsm=stepsM[2].split('|')

		for (j=0;j<stepsm.length;j++){
			stepsm_=stepsm[j].split('#')
			for (i=0;i<stepsm_.length;i++){
				myString = stepsm_[i];
				if (myString.includes(searchWord)) {
					ingJsT=ingJsT+'Step '+n+'\r\n'
				n=n+1;
				} else {
					ingJsT=ingJsT+''+stepsm_[i]+'\r\n\n'
				}
			}
		}

document.getElementById('steps').value=ingJsT.trim().replace(/\n+$/, '')
//miscelanea

rVal=ref[1].split(':')
document.getElementById('popFoodName').value=rVal[1]
rVal=ref[2].split(':')
document.getElementById('g').value=rVal[1]
rVal=ref[3].split(':')
document.getElementById('sg').value=rVal[1]
rVal=ref[4].split(':')
document.getElementById('treat').value=rVal[1]
rVal=ref[6].split(':')
document.getElementById('kcal').value=rVal[1]
			}
		}
    hr.send(vars);
//update()
}


function update(){
//javascript to load the new state of inOut_recipeFiles.txt and inOut_importing.txt. after shareHTML button being clicked. VIA PHP must run the piece of inOut.scr with (rm inOut_importing.txt;cd .. && etc., and returning to PHP without message must be executed the PHP script '$sendToAjax=exec("echo $(cat inOut_recipeFiles.txt)\|$(cat inOut_importing.txt);echo $sendToAjax;'
//
    var hr = new XMLHttpRequest();
    var url = "../importExport/importing/resources/update.php"; //update.scr
    	var vars = '';
//alert(vars)
    hr.open("POST", url, true);
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				var fileContents=hr.responseText
//alert(fileContents)
				fileList=fileContents.split('|')
//alert(fileList[0])
//alert(fileList[1])

				document.getElementById('recipeFiles').innerHTML=fileList[0]
				document.getElementById('importing').innerHTML=fileList[1]

			}
 		}
    hr.send(vars);


//the return to Ajax should be placed into the flex boxes any time after running sharehtml()=>shareHTML.scr
//a copy of the recipe (modified or not) went to 'recipeFiles', and the original was deleted from 'importing'
//It is only needed javascript replace the new states of the files inOut_recipeFiles.txt and inOut_importing.txt.
//It doesn't matter that this is done every time shareHTML() is called, regardless of what is triggering it.


}
</script>




</head>


<body onkeydown="return (event.keyCode != 116)"><!-- onload='alert("If you refresh the page frequently, Google might disable your Google Translate. Instead, you can use the buttons on the page.")'-->
<!--https://web.archive.org/web/20220702180437/https://crushmag-online.com/recipe-type/marinades-sauces-and-condiments/</span><br><br>-->
<div style='width:104.3%;font-family:satisfy;text-align:center;font-size:40px;text-shadow: 1px 1px 2px red, 0 0 1em white, 0 0 0.2em yellow' translate="no"><span style='color:#FFD1DC;text-shadow:1px 3px 2px gold;'><svg fill="#000000" height="30px" width="30px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512" xml:space="preserve" transform="scale(-1, 1)">
  <g>
    <g>
			<path d="M488.813,242.2h-11.947c-28.16,0-51.2,23.04-51.2,51.2c0,37.547-30.72,68.267-68.267,68.267h-93.867v-25.6h11.947h56.32
				c2.56,0,4.267-0.853,5.973-1.707c29.013-29.867,46.08-69.973,45.227-111.787c0-40.96-16.213-78.507-45.227-105.813
				c-1.707-1.707-3.413-2.56-5.973-2.56h-56.32h-37.547V71.533v-51.2c0-2.56-0.853-5.12-2.56-6.827
				c-17.92-13.653-44.373-13.653-62.293,0c-11.093,8.533-29.013,9.387-40.107,0c-2.56-1.707-6.827-2.56-9.387-0.853
				c-3.413,1.707-5.12,4.267-5.12,7.68v51.2c0,2.56,0.853,5.12,3.413,6.827c8.533,6.827,19.627,10.24,30.72,10.24
				c11.093,0,22.187-3.413,30.72-10.24c10.276-7.905,26.408-9.213,37.547-1.901V114.2h-21.333h-51.2h-38.4
				c-3.413,0-5.973,2.56-7.68,5.973S101.4,127,103.96,129.56c25.6,23.893,39.253,57.173,40.107,93.013
				c0.853,36.693-13.653,72.533-40.107,98.987c-2.56,2.56-2.56,5.973-1.707,9.387c0.853,3.413,4.267,5.12,7.68,5.12h39.253h51.2
				h11.947v25.6H80.067c-7.68,0-14.507-4.267-18.773-11.947c-5.973-11.093-13.653-19.627-13.653-19.627l-2.56-2.56H-1v110.933
				c0,37.547,30.72,68.267,68.267,68.267h324.267c52.053,0,93.867-41.813,93.867-93.867V306.2c0-2.56,1.707-4.267,4.267-4.267
				c11.947,0,21.333-9.387,21.333-21.333v-16.213C511,252.44,500.76,242.2,488.813,242.2z M365.933,222.573
				c0.853,35.84-12.8,70.827-37.547,96.427h-37.165c20.905-27.608,32.759-61.417,32.045-96.427
				c0-34.122-11.261-65.869-31.791-91.307h36.911C352.28,156.013,365.08,187.587,365.933,222.573z M268.653,131.267
				c23.893,24.747,36.693,56.32,37.547,91.307c0.853,35.84-12.8,70.827-37.547,96.427h-5.12h-23.511
				c18.939-25.011,30.438-55.114,31.903-86.587c0.023-0.464,0.046-0.928,0.064-1.392c0.016-0.439,0.03-0.878,0.042-1.318
				c0.082-2.659,0.1-5.321,0.035-7.983c0-33.28-11.093-64.853-31.573-90.453H268.653z M173.08,64.707
				c-10.24,8.533-26.453,9.387-37.547,2.56V34.84c15.36,5.12,34.987,2.56,47.787-7.68c10.24-8.533,26.453-9.387,37.547-2.56v32.427
				C205.507,51.907,185.88,54.467,173.08,64.707z M128.707,319c21.333-27.307,33.28-62.293,32.427-97.28
				c0-33.28-11.093-64.853-31.573-90.453h35.914c24.448,23.759,37.493,56.31,38.326,91.307
				c0.826,35.523-12.744,70.246-37.613,96.427H128.707z M188.44,319c21.333-27.307,33.28-62.293,32.427-97.28
				c0-33.28-11.093-64.853-31.573-90.453h27.38c15.047,14.622,25.778,32.572,31.995,52.377c0.009,0.028,0.018,0.055,0.026,0.083
				c0.308,0.984,0.605,1.974,0.891,2.967c0.016,0.055,0.032,0.109,0.048,0.164c0.278,0.97,0.544,1.945,0.801,2.923
				c0.02,0.075,0.04,0.15,0.06,0.225c0.25,0.957,0.487,1.919,0.717,2.884c0.023,0.096,0.047,0.192,0.07,0.289
				c0.22,0.936,0.428,1.875,0.629,2.817c0.027,0.129,0.057,0.257,0.084,0.386c0.189,0.898,0.366,1.8,0.537,2.703
				c0.034,0.177,0.07,0.353,0.102,0.531c0.156,0.843,0.301,1.691,0.443,2.539c0.04,0.24,0.083,0.478,0.122,0.719
				c0.123,0.764,0.235,1.531,0.346,2.299c0.047,0.328,0.099,0.654,0.144,0.983c0.09,0.657,0.169,1.318,0.251,1.978
				c0.054,0.439,0.113,0.877,0.163,1.317c0.059,0.52,0.108,1.043,0.162,1.565c0.059,0.578,0.123,1.155,0.175,1.735
				c0.032,0.351,0.056,0.704,0.085,1.055c0.062,0.745,0.126,1.489,0.176,2.237c0.008,0.115,0.012,0.23,0.02,0.344
				c0.134,2.05,0.23,4.112,0.281,6.187c0.826,35.523-12.744,70.246-37.613,96.427h-5.054H188.44z M229.4,336.067h17.067v25.6H229.4
				V336.067z M493.933,280.6c0,2.56-1.707,4.267-4.267,4.267c-11.947,0-21.333,9.387-21.333,21.333v106.667
				c0,42.667-34.133,76.8-76.8,76.8H67.267c-28.16,0-51.2-23.04-51.2-51.2V344.6H37.4c2.56,2.56,5.973,7.68,8.533,12.8
				c6.827,13.653,19.627,21.333,34.133,21.333h132.267h51.2H357.4c46.933,0,85.333-38.4,85.333-85.333
				c0-18.773,15.36-34.133,34.133-34.133h11.947c2.56,0,5.12,2.56,5.12,5.12V280.6z" stroke="white" fill="white"/>
			<path d="M129.56,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947S132.973,394.947,129.56,398.36z M101.4,450.413c-5.12,5.12-11.947,6.827-15.36,3.413
				c-1.707-1.707-1.707-4.267-1.707-5.973c0-2.56,1.707-5.973,4.267-9.387c2.56-2.56,5.973-4.267,9.387-4.267c0,0,0,0,0.853,0
				c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274c0.385,0.385,0.771,0.72,1.166,1.018
				c0.528,1.407,0.541,2.948,0.541,4.102C105.667,444.44,103.96,447.853,101.4,450.413z" stroke="yellow" fill="yellow"/>
			<path d="M300.227,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947C308.76,394.947,303.64,394.947,300.227,398.36z M272.067,450.413
				c-5.12,5.12-11.947,6.827-15.36,3.413C255,452.12,255,449.56,255,447.853c0-3.413,1.707-6.827,4.267-9.387
				s5.973-4.267,9.387-4.267c0,0,0,0,0.853,0c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274
				c0.385,0.385,0.771,0.72,1.166,1.018c0.528,1.407,0.541,2.948,0.541,4.102C276.333,444.44,274.627,447.853,272.067,450.413z" stroke="yellow" fill="yellow"/>
			<path d="M385.56,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947C394.093,394.947,388.973,394.947,385.56,398.36z M357.4,450.413
				c-5.12,5.12-11.947,6.827-15.36,3.413c-1.707-1.707-1.707-4.267-1.707-5.973c0-3.413,1.707-6.827,4.267-9.387
				s5.973-4.267,9.387-4.267c0,0,0,0,0.853,0c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274
				c0.385,0.385,0.771,0.72,1.166,1.018c0.528,1.407,0.541,2.948,0.541,4.102C361.667,444.44,359.96,447.853,357.4,450.413z" stroke="yellow" fill="yellow"/>
			<path d="M214.893,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947S218.307,394.947,214.893,398.36z M186.733,450.413c-5.12,5.12-11.947,6.827-15.36,3.413
				c-1.707-1.707-1.707-4.267-1.707-5.973c0-3.413,1.707-6.827,4.267-9.387s5.973-4.267,9.387-4.267c0,0,0,0,0.853,0
				c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274c0.385,0.385,0.771,0.72,1.166,1.018
				c0.528,1.407,0.541,2.948,0.541,4.102C191,444.44,189.293,447.853,186.733,450.413z" stroke="yellow" fill="yellow"/>
		</g>
	</g>
</g>
</svg></span> Drakkar Recipes <span style='color:#FFD1DC;text-shadow:1px 3px 2px gold;'><svg fill="#000000" height="30px" width="30px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512" xml:space="preserve" transform="scale(1, 1)">
  <g>
    <g>
			<path d="M488.813,242.2h-11.947c-28.16,0-51.2,23.04-51.2,51.2c0,37.547-30.72,68.267-68.267,68.267h-93.867v-25.6h11.947h56.32
				c2.56,0,4.267-0.853,5.973-1.707c29.013-29.867,46.08-69.973,45.227-111.787c0-40.96-16.213-78.507-45.227-105.813
				c-1.707-1.707-3.413-2.56-5.973-2.56h-56.32h-37.547V71.533v-51.2c0-2.56-0.853-5.12-2.56-6.827
				c-17.92-13.653-44.373-13.653-62.293,0c-11.093,8.533-29.013,9.387-40.107,0c-2.56-1.707-6.827-2.56-9.387-0.853
				c-3.413,1.707-5.12,4.267-5.12,7.68v51.2c0,2.56,0.853,5.12,3.413,6.827c8.533,6.827,19.627,10.24,30.72,10.24
				c11.093,0,22.187-3.413,30.72-10.24c10.276-7.905,26.408-9.213,37.547-1.901V114.2h-21.333h-51.2h-38.4
				c-3.413,0-5.973,2.56-7.68,5.973S101.4,127,103.96,129.56c25.6,23.893,39.253,57.173,40.107,93.013
				c0.853,36.693-13.653,72.533-40.107,98.987c-2.56,2.56-2.56,5.973-1.707,9.387c0.853,3.413,4.267,5.12,7.68,5.12h39.253h51.2
				h11.947v25.6H80.067c-7.68,0-14.507-4.267-18.773-11.947c-5.973-11.093-13.653-19.627-13.653-19.627l-2.56-2.56H-1v110.933
				c0,37.547,30.72,68.267,68.267,68.267h324.267c52.053,0,93.867-41.813,93.867-93.867V306.2c0-2.56,1.707-4.267,4.267-4.267
				c11.947,0,21.333-9.387,21.333-21.333v-16.213C511,252.44,500.76,242.2,488.813,242.2z M365.933,222.573
				c0.853,35.84-12.8,70.827-37.547,96.427h-37.165c20.905-27.608,32.759-61.417,32.045-96.427
				c0-34.122-11.261-65.869-31.791-91.307h36.911C352.28,156.013,365.08,187.587,365.933,222.573z M268.653,131.267
				c23.893,24.747,36.693,56.32,37.547,91.307c0.853,35.84-12.8,70.827-37.547,96.427h-5.12h-23.511
				c18.939-25.011,30.438-55.114,31.903-86.587c0.023-0.464,0.046-0.928,0.064-1.392c0.016-0.439,0.03-0.878,0.042-1.318
				c0.082-2.659,0.1-5.321,0.035-7.983c0-33.28-11.093-64.853-31.573-90.453H268.653z M173.08,64.707
				c-10.24,8.533-26.453,9.387-37.547,2.56V34.84c15.36,5.12,34.987,2.56,47.787-7.68c10.24-8.533,26.453-9.387,37.547-2.56v32.427
				C205.507,51.907,185.88,54.467,173.08,64.707z M128.707,319c21.333-27.307,33.28-62.293,32.427-97.28
				c0-33.28-11.093-64.853-31.573-90.453h35.914c24.448,23.759,37.493,56.31,38.326,91.307
				c0.826,35.523-12.744,70.246-37.613,96.427H128.707z M188.44,319c21.333-27.307,33.28-62.293,32.427-97.28
				c0-33.28-11.093-64.853-31.573-90.453h27.38c15.047,14.622,25.778,32.572,31.995,52.377c0.009,0.028,0.018,0.055,0.026,0.083
				c0.308,0.984,0.605,1.974,0.891,2.967c0.016,0.055,0.032,0.109,0.048,0.164c0.278,0.97,0.544,1.945,0.801,2.923
				c0.02,0.075,0.04,0.15,0.06,0.225c0.25,0.957,0.487,1.919,0.717,2.884c0.023,0.096,0.047,0.192,0.07,0.289
				c0.22,0.936,0.428,1.875,0.629,2.817c0.027,0.129,0.057,0.257,0.084,0.386c0.189,0.898,0.366,1.8,0.537,2.703
				c0.034,0.177,0.07,0.353,0.102,0.531c0.156,0.843,0.301,1.691,0.443,2.539c0.04,0.24,0.083,0.478,0.122,0.719
				c0.123,0.764,0.235,1.531,0.346,2.299c0.047,0.328,0.099,0.654,0.144,0.983c0.09,0.657,0.169,1.318,0.251,1.978
				c0.054,0.439,0.113,0.877,0.163,1.317c0.059,0.52,0.108,1.043,0.162,1.565c0.059,0.578,0.123,1.155,0.175,1.735
				c0.032,0.351,0.056,0.704,0.085,1.055c0.062,0.745,0.126,1.489,0.176,2.237c0.008,0.115,0.012,0.23,0.02,0.344
				c0.134,2.05,0.23,4.112,0.281,6.187c0.826,35.523-12.744,70.246-37.613,96.427h-5.054H188.44z M229.4,336.067h17.067v25.6H229.4
				V336.067z M493.933,280.6c0,2.56-1.707,4.267-4.267,4.267c-11.947,0-21.333,9.387-21.333,21.333v106.667
				c0,42.667-34.133,76.8-76.8,76.8H67.267c-28.16,0-51.2-23.04-51.2-51.2V344.6H37.4c2.56,2.56,5.973,7.68,8.533,12.8
				c6.827,13.653,19.627,21.333,34.133,21.333h132.267h51.2H357.4c46.933,0,85.333-38.4,85.333-85.333
				c0-18.773,15.36-34.133,34.133-34.133h11.947c2.56,0,5.12,2.56,5.12,5.12V280.6z" stroke="white" fill="white"/>
			<path d="M129.56,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947S132.973,394.947,129.56,398.36z M101.4,450.413c-5.12,5.12-11.947,6.827-15.36,3.413
				c-1.707-1.707-1.707-4.267-1.707-5.973c0-2.56,1.707-5.973,4.267-9.387c2.56-2.56,5.973-4.267,9.387-4.267c0,0,0,0,0.853,0
				c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274c0.385,0.385,0.771,0.72,1.166,1.018
				c0.528,1.407,0.541,2.948,0.541,4.102C105.667,444.44,103.96,447.853,101.4,450.413z" stroke="yellow" fill="yellow"/>
			<path d="M300.227,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947C308.76,394.947,303.64,394.947,300.227,398.36z M272.067,450.413
				c-5.12,5.12-11.947,6.827-15.36,3.413C255,452.12,255,449.56,255,447.853c0-3.413,1.707-6.827,4.267-9.387
				s5.973-4.267,9.387-4.267c0,0,0,0,0.853,0c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274
				c0.385,0.385,0.771,0.72,1.166,1.018c0.528,1.407,0.541,2.948,0.541,4.102C276.333,444.44,274.627,447.853,272.067,450.413z" stroke="yellow" fill="yellow"/>
			<path d="M385.56,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947C394.093,394.947,388.973,394.947,385.56,398.36z M357.4,450.413
				c-5.12,5.12-11.947,6.827-15.36,3.413c-1.707-1.707-1.707-4.267-1.707-5.973c0-3.413,1.707-6.827,4.267-9.387
				s5.973-4.267,9.387-4.267c0,0,0,0,0.853,0c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274
				c0.385,0.385,0.771,0.72,1.166,1.018c0.528,1.407,0.541,2.948,0.541,4.102C361.667,444.44,359.96,447.853,357.4,450.413z" stroke="yellow" fill="yellow"/>
			<path d="M214.893,398.36l-20.958,20.958c-3.921-1.919-8.382-2.717-13.176-2.184c-7.68,0.853-14.507,4.267-19.627,9.387
				c-5.12,5.973-8.533,12.8-9.387,19.627c-0.853,7.68,1.707,14.507,6.827,19.627c5.12,4.267,11.093,6.827,17.067,6.827
				c7.68,0,16.213-3.413,22.187-9.387c5.12-5.973,8.533-12.8,9.387-19.627c0.48-4.322-0.121-8.374-1.65-12.003l21.277-21.277
				c3.413-3.413,3.413-8.533,0-11.947S218.307,394.947,214.893,398.36z M186.733,450.413c-5.12,5.12-11.947,6.827-15.36,3.413
				c-1.707-1.707-1.707-4.267-1.707-5.973c0-3.413,1.707-6.827,4.267-9.387s5.973-4.267,9.387-4.267c0,0,0,0,0.853,0
				c1.353,0,2.706,0.007,4.059,0.432c0.307,0.444,0.658,0.872,1.061,1.274c0.385,0.385,0.771,0.72,1.166,1.018
				c0.528,1.407,0.541,2.948,0.541,4.102C191,444.44,189.293,447.853,186.733,450.413z" stroke="yellow" fill="yellow"/>
		</g>
	</g>
</g>
</svg></span> </div>
<div id='saveMessage' style='margin-bottom:5px'></div>

<div style='width:100%;text-align:center;margin-bottom:20px;color:yellow;'><b>Recipe Grid: </b>
<span id='gridMode' style='font-size:9px;color:white;'>Edit</span></div>
<div id='bonbon'></div>

<div class="box">
          <div class='one1'>References</div>
          <div class='two1'>9 Ingredients <span id='ingredients_'></span></div>
          <div id='stepsA' class='three1' style='visibility:visible'>Preparation <span id='steps_'></span></div>
          <div class='four1'>Do</div>
</div>
<div class="box">
	<div class='one'>
		1 Reg. No. <span id='file_'></span><br>
<input id='file' label='1' style='background-color:navy;color:white;' type='text' onclick='orderToSearch(this.id)' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;" value=''><br>

		2 Title <span id='title_'></span><br>
<input id='title' label='8' type='text' onclick='orderToSearch(this.id)' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;" value=''><br>
		3 Author <span id='author_'></span><br>
<input id='author' label='9' type='text' onclick='orderToSearch(this.id)' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;" value=''><br>
		4 Image <span id='country_'></span><br>
<input id='country' label='10' type='text' onclick='orderToSearch(this.id)' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;" value=''><br>
		5 Url <span id='url_'></span><br>
<input id='url' label='11' type='text' onclick='orderToSearch(this.id)' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;" value=''>
	</div>

	<div class='two'>
		<textarea id='ingredients' label='12' type='text' style='background-color:white;color:black;' onclick='orderToSearch(this.id)'></textarea>
	</div>
    <div id='stepsB' class='three' style='visibility:visible'>
		<textarea id='steps' type='text' onclick='orderToSearch(this.id)'>
Step 1
Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Step 2
Integer mi nisi, lobortis vitae ante vitae, sodales iaculis sapien...

Step (your turn to continue ...)
		</textarea>
	</div>

	<div class='four'>		<div class='divButton' name='down' onclick="shareHTML('share');">Export Recipe</div>



		<!--<div style='display:none;' class='divButton'><input style='display:none;' id='qualita' type='checkbox' onclick='changeDB()' checked><span style='display:none;' id='searchDB'> Qualitative DB</span></div><div class='divButton' style='display:none;' name='up' onclick='record();'>Save Recipe</div>
		<div style='display:block;' class='divButton'>
<input style='display:block;' id='replace' type='checkbox' onclick=''><span style='display:none;' id='Replace'> Force</span></div><div style='display:block' class='divButton' name='down' onclick='shareHTML();'>Save for Validation</div><div class='divButton' onclick='restart();'>Restart</div>-->
		<div style='margin-bottom:10px;' class='divButton' name='up' onclick='clearToSearch()'>Change Mode</div>


		<div class='divButton' onclick='search()'>Search Recipe</div>
	</div>
</div>
<div id='str' style="width:100%"></div>
<script>

function groupSub(pass){
prefix=''
str=pass+'.'+str
//document.getElementById('str').innerHTML=str

//if ( pass[0] == 'd' ){alert(pass)}

//alert(pass+', '+pass.length) //a1,2		a2,2	...	a9,2
//alert(pass.slice(1))		//1			2			9
if ( pass.length == '2' ){var prefix=pass.slice(0,-1)}else{var prefix=pass.slice(0,-2)}
//alert(prefix)			//prefix=pass[0]
//alert(pass.match(/d[1-9]/gi))
if ( pass == pass.match(/d[1-9].*/gi) ){for (i=1;i<10;i++){document.getElementById('b'+i).style.display='none'}
}

switch (prefix) {
				case 'a':
for (i=1;i<16;i++){document.getElementById('b'+i).style.display='none'}
					//alert('a display meat');
					document.getElementById('g').value='';
					document.getElementById('sg').value='';
					document.getElementById('treat').value='';

					document.getElementById('b'+pass.slice(1)).style.display='flex';
					document.getElementById('g').value=document.getElementById(pass).innerHTML.trim()

					g=document.getElementById('g').value
					document.getElementById('gT').innerHTML=g
					//click on first line=>close all last lines ('d'+i+'menu')i=1-48
					for (i=1;i<49;i++){
					document.getElementById('d'+i+'menu').style.display='none'
					}
				break;

				case 'd':
//alert('case d')
	//click on second line close all second lines ('b'+i) i=1-15
for (i=1;i<16;i++){document.getElementById('b'+i).style.display='none'}
					document.getElementById('sg').value=document.getElementById(pass).innerHTML.trim()
					sg=document.getElementById('sg').value
					document.getElementById('sgT').innerHTML=sg
						document.getElementById(pass+'menu').style.display='flex';
               break;

               default:

					document.getElementById('treat').value=document.getElementById(pass).innerHTML.replace('&lt;', '<').replace('&gt;', '>')
					treat=document.getElementById('treat').value
					document.getElementById('treatT').innerHTML=document.getElementById('treat').value.trim()
            }
}

</script>

<!--<div class='uno' id='quantitativedb' ><u>Quantitative DB</u> => Total g: Total Kc: Prot: Carb: Fat: satFat: Cholest: Salt: Vit C: Iron: Calcium: Potasium : filename</div>
<div class='dos' id='qualitativedb' ></div><br>-->
<br>
<div name='heads'><b>_Menu WWEIA_</b></div>

<div class='tres' >
	<table class='cuatro'>

		<tr>
			<td style='width:5%'>
				<span class='color'>Kc</span><br>
					<input class='tab' id='kcal' style='background-color:navy;color:white;' type='text'><br></td>
			<td style="width:29%;">
				<span  class='color' >6 Collection (.db) - F3 </span>
				<span style='color:white;'>(comma separated: Bread,Milk, ...) </span><span id='popFoodName_'></span><br>
					<input class='tab' id='popFoodName' label='2' onclick='orderToSearch(this.id)' type='text' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;"></td>
			<td style="width:15%;">
				<span  class='color'>7 Group - F2 </span><span id='g_'></span><br>
					<input class='tab' id='g' label='3' onclick='orderToSearch(this.id)' style='' type='text' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;">
			</td>
			<td style="width:20%;">
				<span  class='color'>8 Subgroup - F2 </span><span id='sg_' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;"></span><br>
					<input class='tab' id='sg' label='4' onclick='orderToSearch(this.id)' type='text'>
			</td>
			<td>
			<span  class='color'><b>10 Recipe Description - F10</b>: </span><span id='treat_'></span><br>
				<input class='tab' id='treat' label='5' onclick='orderToSearch(this.id)' type='text' oncontextmenu="javascript:document.getElementById(this.id).value='';return false;">
			</td>
		</tr>
		<tr style='color:white;'>
			<td style="width:5%;padding-left:7px;"></td>
			<td id='popFoodNameT' style="width:29%;padding-left:7px;"></td>
			<td id='gT' style="padding-left:7px;"></td>
			<td id='sgT' style="padding-left:7px;"></td>
			<td id='treatT' style="padding-left:12px;"></td>
		</tr>
	</table>
</div>
<div name='grandblock'>
	<div name='selectMessage'>To complete the WWEIA boxes it is not necessary to adhere to this list of options.</div>

<div class="menuA" > <!-- Flex container -->
  <div id='a1' class='optionA' onclick='groupSub(this.id)'>Protein</div><div class='colonsW'>:</div> <!-- Flex items -->
  <div id='a2' class='optionA' onclick='groupSub(this.id)'>Grain</div><div class='colonsW'>:</div>
  <div id='a3' class='optionA' onclick='groupSub(this.id)'>Milk-Dairy</div><div class='colonsW'>:</div>
  <div id='a4' class='optionA' onclick='groupSub(this.id)'>Snack-Sweet</div><div class='colonsW'>:</div>
  <div id='a5' class='optionA' onclick='groupSub(this.id)'>Dish</div><div class='colonsW'>:</div>
  <div id='a6' class='optionA' onclick='groupSub(this.id)'>Vegetable</div><div class='colonsW'>:</div>
  <div id='a7' class='optionA' onclick='groupSub(this.id)'>Fruit</div><div class='colonsW'>:</div>
  <div id='a8' class='optionA' onclick='groupSub(this.id)'>Beverage</div><div class='colonsW'>:</div>
  <div id='a9' class='optionA' onclick='groupSub(this.id)'>+Alcohol</div><div class='colonsW'>:</div>
  <div id='a10' class='optionA' onclick='groupSub(this.id)'>Water</div><div class='colonsW'>:</div>
  <div id='a11' class='optionA' onclick='groupSub(this.id)'>Fat-Oil</div><div class='colonsW'>:</div>
  <div id='a12' class='optionA' onclick='groupSub(this.id)'>Condiment-Sauce</div><div class='colonsW'>:</div>
  <div id='a13' class='optionA' onclick='groupSub(this.id)'>Sugar</div><div class='colonsW'>:</div>
  <div id='a14' class='optionA' onclick='groupSub(this.id)'>Formulas</div><div class='colonsW'>:</div>
  <div id='a15' class='optionA' onclick='groupSub(this.id)'>Other</div>

</div>
<!--/////////////////////////////////////////////////////////////////////////////////////-->
<div id='b1' class="menuB" translate="no"> <!-- Flex container A1-->
  <div id='d1' class='optionB' onclick='groupSub(this.id)'>Meat</div><div>:</div> <!-- Flex items -->
  <div id='d2' class='optionB' onclick='groupSub(this.id)'>Poultry</div><div>:</div>
  <div id='d3' class='optionB' onclick='groupSub(this.id)'>Seafood</div><div>:</div>
  <div id='d4' class='optionB' onclick='groupSub(this.id)'>Eggs</div><div>:</div>
  <div id='d5' class='optionB' onclick='groupSub(this.id)'>Cured Meats/Poultry</div><div>:</div>
  <div id='d6' class='optionB' onclick='groupSub(this.id)'>Plant based</div>
</div>
<div id='b2' class="menuB" translate="no"> <!-- Flex container A2-->
  <div id='d7' class='optionB' onclick='groupSub(this.id)'>Cooked</div><div>:</div> <!-- Flex items -->
  <div id='d8' class='optionB' onclick='groupSub(this.id)'>Breds, rolls, tortillas</div><div>:</div>
  <div id='d9' class='optionB' onclick='groupSub(this.id)'>Quick breads-Bread products</div><div>:</div>
  <div id='d10' class='optionB' onclick='groupSub(this.id)'>Ready-to-Eat Cereals</div><div>:</div>
  <div id='d11' class='optionB' onclick='groupSub(this.id)'>Cooked cereals</div><div>:</div>
</div>
<div id='b3' class="menuB" translate="no"> <!-- Flex container A3-->
  <div id='d12' class='optionB' onclick='groupSub(this.id)'>Milk</div><div>:</div> <!-- Flex items -->
  <div id='d13' class='optionB' onclick='groupSub(this.id)'>Flavored milk</div><div>:</div>
  <div id='d14' class='optionB' onclick='groupSub(this.id)'>Dairy drinks-Substitutes</div><div>:</div>
  <div id='d15' class='optionB' onclick='groupSub(this.id)'>Cheese</div><div>:</div>
  <div id='d16' class='optionB' onclick='groupSub(this.id)'>Yogurt</div></div>
</div>
<div id='b4' class='optionC' translate="no"> <!-- Flex container A4-->
  <div id='d17' class='optionB' onclick='groupSub(this.id)'>Savory Snacks</div><div>:</div> <!-- Flex items -->
  <div id='d18' class='optionB' onclick='groupSub(this.id)'>Crackers</div><div>:</div>
  <div id='d19' class='optionB' onclick='groupSub(this.id)'>Snack/Meal Bars</div><div>:</div>
  <div id='d20' class='optionB' onclick='groupSub(this.id)'>Sweet Bakery Products</div><div>:</div>
  <div id='d21' class='optionB' onclick='groupSub(this.id)'>Candy</div><div>:</div>
  <div id='d22' class='optionB' onclick='groupSub(this.id)'>Other Desserts</div>
</div>
<div id='b5' class='optionC' translate="no"> <!-- Flex container A5-->
  <div id='d23' class='optionB' onclick='groupSub(this.id)'>Meat, Poultry, Seafood</div><div>:</div>
  <div id='d24' class='optionB' onclick='groupSub(this.id)'>Bean/Vegetable-based</div><div>:</div>
  <div id='d25' class='optionB' onclick='groupSub(this.id)'>Grain-based</div><div>:</div>
  <div id='d26' class='optionB' onclick='groupSub(this.id)'>Asian</div><div>:</div>
  <div id='d27' class='optionB' onclick='groupSub(this.id)'>Mexican</div><div>:</div>
  <div id='d28' class='optionB' onclick='groupSub(this.id)'>Pizza</div><div>:</div>
  <div id='d29' class='optionB' onclick='groupSub(this.id)'>Sandwiches</div><div>:</div>
  <div id='d30' class='optionB' onclick='groupSub(this.id)'>Soups</div>
</div>
<div id='b6' class='optionC' translate="no"> <!-- Flex container A6-->
	<div id='d31' class='optionB' onclick='groupSub(this.id)'>Vegetables, excluding Potatoes</div><span> : </span> <!-- Flex items -->
	<div id='d32' class='optionB' onclick='groupSub(this.id)'>White Potatoes</div>
</div>
<div id='b7' class='optionC' translate="no"> <!-- Flex container A7-->
	<div id='d33' class='optionB' onclick='groupSub(this.id)'>Fruits</div>
</div>
<div id='b8' class='optionC' translate="no"> <!-- Flex container A8-->
	  <div id='d34' class='optionB' onclick='groupSub(this.id)'>100% Juice</div><span>:</span>
	  <div id='d35' class='optionB' onclick='groupSub(this.id)'>Diet Beverages</div><span>:</span>
	  <div id='d36' class='optionB' onclick='groupSub(this.id)'>Sweetened Beverages</div><span>:</span>
	  <div id='d37' class='optionB' onclick='groupSub(this.id)'>Coffee and Tea</div>
</div>
<div id='b9' class='optionC' translate="no"> <!-- Flex container A9-->
	  <div id='d38' class='optionB' onclick='groupSub(this.id)'>Alcoholic Beverages</div>
</div>
<div id='b10' class='optionC' translate="no"> <!-- Flex container A10-->
	  <div id='d39' class='optionB' onclick='groupSub(this.id)'>Plain Water</div><span>:</span>
	  <div id='d40' class='optionB' onclick='groupSub(this.id)'>Flavored or Enhanced Water</div>
</div>
<div id='b11' class='optionC' translate="no"> <!-- Flex container A11-->
	  <div id='d41' class='optionB' onclick='groupSub(this.id)'>Fats and Oils</div>
</div>
<div id='b12' class='optionC' translate="no"> <!-- Flex container A12-->
	  <div id='d42' class='optionB' onclick='groupSub(this.id)'>Condiments and Sauces</div>
</div>
<div id='b13' class='optionC' translate="no"> <!-- Flex container A13-->
	  <div id='d43' class='optionB' onclick='groupSub(this.id)'>Sugars</div>
</div>
<div id='b14' class='optionC' translate="no"> <!-- Flex container A14-->
	  <div id='d44' class='optionB' onclick='groupSub(this.id)'>Baby Foods</div><span>:</span>
	  <div id='d45' class='optionB' onclick='groupSub(this.id)'>Baby Beverages</div><span>:</span>
	  <div id='d46' class='optionB' onclick='groupSub(this.id)'>Infant Formulas</div><span>:</span>
	  <div id='d47' class='optionB' onclick='groupSub(this.id)'>Human Milk</div>
</div>
<div id='b15' class='optionC' translate="no"> <!-- Flex container A15-->
	  <div id='d48' class='optionB' onclick='groupSub(this.id)'>Other</div>
</div>
<!--//////////////////////////////////////////////   B1   ////////////////////////////////////////////////////////////////////-->
	<div  class='menuC' translate="no">

		<div id='d1menu' class='optionC'>
			<div id='d1menu1' class='optionD' onclick='groupSub(this.id)'>Beef (No ground)</div><div>:</div>
			<div id='d1menu2' class='optionD' onclick='groupSub(this.id)'>Ground beef</div><div>:</div>
			<div id='d1menu3' class='optionD' onclick='groupSub(this.id)'>Lamb, goat, game</div><div>:</div>
			<div id='d1menu4' class='optionD' onclick='groupSub(this.id)'>Liver-Organs</div>
		</div>
		<div id='d2menu' class='optionC'>
			<div id='d1menu5' class='optionD' onclick='groupSub(this.id)'>Chicken, whole pieces</div><div> : </div>
			<div id='d1menu6' class='optionD' onclick='groupSub(this.id)'>Chicken patties, nuggets and tenders</div><div> : </div>
			<div id='d1menu7' class='optionD' onclick='groupSub(this.id)'>Turkey, duck, other poultry</div>
		</div>
		<div id='d3menu' class='optionC'>
			<div id='d1menu8' class='optionD' onclick='groupSub(this.id)'>Fish</div><div> : </div>
			<div id='d1menu9' class='optionD' onclick='groupSub(this.id)'>Shellfish</div>
		</div>
		<div id='d4menu' class='optionC'>
			<div id='d1menu10' class='optionD' onclick='groupSub(this.id)'>Eggs and omelets</div>
		</div>
		<div id='d5menu' class='optionC'>
			<div id='d1menu11' class='optionD' onclick='groupSub(this.id)'>Cold cuts and cured meats</div><span>:</span>
			<div id='d1menu12' class='optionD' onclick='groupSub(this.id)'>Bacon</div><span>:</span>
			<div id='d1menu13' class='optionD' onclick='groupSub(this.id)'>Frankfurters</div><span>:</span>
			<div id='d1menu14' class='optionD' onclick='groupSub(this.id)'>Sausages</div>
		</div>
		<div id='d6menu' class='optionC'>
			<div id='d1menu15' class='optionD' onclick='groupSub(this.id)'>Beans, peas, legumes</div><div> : </div>
			<div id='d1menu16' class='optionD' onclick='groupSub(this.id)'>Nuts and seeds</div><div> : </div>
			<div id='d1menu17' class='optionD' onclick='groupSub(this.id)'>Processed soy products</div>
		</div>

<!--//////////////////////////////////////////////   B2   ////////////////////////////////////////////////////////////////////-->

		<div id='d7menu' class='optionC'>
			<div id='d2menu1' class='optionD' onclick='groupSub(this.id)'>Rice</div><div> : </div>
			<div id='d2menu2' class='optionD' onclick='groupSub(this.id)'>Pasta, noodles, cooked grains</div>
		</div>
		<div id='d8menu' class='optionC'>
			<div id='d2menu3' class='optionD' onclick='groupSub(this.id)'>Yeast breads</div><div> : </div>
			<div id='d2menu4' class='optionD' onclick='groupSub(this.id)'>Rolls and buns</div><div> : </div>
			<div id='d2menu5' class='optionD' onclick='groupSub(this.id)'>Bagels and English muffins</div><div> : </div>
			<div id='d2menu6' class='optionD' onclick='groupSub(this.id)'>Tortillas</div>
		</div>
		<div id='d9menu' class='optionC'>
			<div id='d2menu7' class='optionD' onclick='groupSub(this.id)'>Biscuits, muffins, quick breads</div><div> : </div>
			<div id='d2menu8' class='optionD' onclick='groupSub(this.id)'>Pancakes, waffles, French toast</div>
		</div>
		<div id='d10menu' class='optionC'>
			<div id='d2menu9' class='optionD' onclick='groupSub(this.id)'>Ready-to-eat cereal, higher sugar (>21.2g/100g)</div><div> : </div>
			<div id='d2menu10' class='optionD' onclick='groupSub(this.id)'>Ready-to-eat cereal, lower sugar (=<21.2g/100g)</div>
		</div>
		<div id='d11menu' class='optionC'>
			<div id='d2menu11' class='optionD' onclick='groupSub(this.id)'>Oatmeal</div><div> : </div>
			<div id='d2menu12' class='optionD' onclick='groupSub(this.id)'>Grits and other cooked cereals</div>
		</div>
<!--//////////////////////////////////////////////   B3   ////////////////////////////////////////////////////////////////////-->

		<div id='d12menu' class='optionC' style='margin-bottom:10px;display:none'>
			<span id='d3menu1' class='optionD' onclick='groupSub(this.id)'>Whole (3.5-3.9% fat)</span><span>:</span>
			<span id='d3menu2' class='optionD' onclick='groupSub(this.id)'>Reduced-fat (2-3%)</span><span>:</span>
			<span id='d3menu3' class='optionD' onclick='groupSub(this.id)'>Low-fat (1-2%)</span><span>:</span>
			<span id='d3menu4' class='optionD' onclick='groupSub(this.id)'>Nonfat</span>
		</div>
	</div>
		<div id='d13menu' class='optionC' style='margin-bottom:10px;display:none'>
			<span id='d3menu5' class='optionD' onclick='groupSub(this.id)'>Whole (3.5-3.9% fat)</span><span>:</span>
			<span id='d3menu6' class='optionD'' onclick='groupSub(this.id)'>Reduced-fat (2-3%)</span><span>:</span>
			<span id='d3menu7' class='optionD' onclick='groupSub(this.id)'>Low-fat (1-2%)</span><span>:</span>
			<span id='d3menu8' class='optionD' onclick='groupSub(this.id)'>Nonfat</span>
		</div>
	</div>
		<div id='d14menu' class='optionC'>
			<span id='d3menu1' class='optionD' onclick='groupSub(this.id)'>Milk shakes and other dairy drinks</span><span> : </span>
			<span id='d3menu2' class='optionD' onclick='groupSub(this.id)'>Milk substitutes</span>
		</div>
		<div id='d15menu' class='optionC'>
			<span id='d3menu3' class='optionD' onclick='groupSub(this.id)'>Cheese</span><span> : </span>
			<span id='d3menu12' class='optionD' onclick='groupSub(this.id)'>Cottage/ricotta cheese</span>
		</div>
		<div id='d16menu' class='optionC'>
			<span id='d3menu4' class='optionD' onclick='groupSub(this.id)'>Yogurt, regular</span><span> : </span>
			<span id='d3menu5' class='optionD' onclick='groupSub(this.id)'>Yogurt, Greek</span>
		</div>
<!--//////////////////////////////////////////////   B4   ////////////////////////////////////////////////////////////////////-->
		<div id='d17menu' class='optionC'>
			<span id='d4menu1' class='optionD' onclick='groupSub(this.id)'>Potato chips</span><span> : </span>
			<span id='d4menu2' class='optionD' onclick='groupSub(this.id)'>Tortilla, corn, other chips</span><span> : </span>
			<span id='d4menu3' class='optionD' onclick='groupSub(this.id)'>Popcorn</span><span> : </span>
			<span id='d4menu4' class='optionD' onclick='groupSub(this.id)'>Pretzels/snack mix</span>
		</div>
		<div id='d18menu' class='optionC'>
			<span id='d4menu5' class='optionD' onclick='groupSub(this.id)'>Crackers, excludes saltines</span><span> : </span>
			<span id='d4menu6' class='optionD' onclick='groupSub(this.id)'>Saltine crackers</span>
		</div>
		<div id='d19menu' class='optionC'>
			<span id='d4menu7 class='optionD' onclick='groupSub(this.id)'>Cereal bars</span><span> : </span>
			<span id='d4menu8' class='optionD' onclick='groupSub(this.id)'>Nutrition bars</span>
		</div>
		<div id='d20menu' class='optionC'>
			<span id='d4menu9' class='optionD' onclick='groupSub(this.id)'>Cakes and pies</span><span> : </span>
			<span id='d4menu10' class='optionD' onclick='groupSub(this.id)'>Cookies and brownies</span><span> : </span>
			<span id='d4menu11' class='optionD' onclick='groupSub(this.id)'>Doughnuts, sweet rolls, pastries</span>
		</div>
	<div id='d21menu' class='optionC'>
		<span id='d4menu12' class='optionD' onclick='groupSub(this.id)'>Candy containing chocolate</span><span> : </span>
		<span id='d4menu13' class='optionD' onclick='groupSub(this.id)'>Candy not containing chocolate</span>
	</div>
	<div id='d22menu' class='optionC'>
		<span id='d4menu14' class='optionD' onclick='groupSub(this.id)'>Ice cream and frozen dairy desserts</span><span> : </span>
		<span id='d4menu15' class='optionD' onclick='groupSub(this.id)'>Pudding</span><span> : </span>
		<span id='d4menu16' class='optionD' onclick='groupSub(this.id)'>Gelatins, ices, sorbets</span>
	</div>
<!--//////////////////////////////////////////////   B5   ////////////////////////////////////////////////////////////////////-->
	<div id='d23menu'  class='optionC'>
		<span id='d5menu1' class='optionB' onclick='groupSub(this.id)'>Meat mixed dishes</span><span>:</span>
		<span id='d5menu2' class='optionB' onclick='groupSub(this.id)'>Poultry mixed dishes</span><span>:</span>
		<span id='d5menu3' class='optionB' onclick='groupSub(this.id)'>Seafood mixed dishes</span>
	</div>
	<div id='d24menu' class='optionC'>
		<span id='d5menu4' class='optionB' onclick='groupSub(this.id)'>Bean, pea, legume dishes</span><span>:</span>
		<span id='d5menu5' class='optionB' onclick='groupSub(this.id)'>Vegetable dishes</span>
	</div>
	<div id='d25menu' class='optionC'>
		<span id='d5menu6' class='optionB' onclick='groupSub(this.id)'>Rice mixed dishes</span><span>:</span>
		<span id='d5menu7' class='optionB' onclick='groupSub(this.id)'>Pasta mixed dishes, excludes macaroni and cheese</span><span>:</span>
		<span id='d5menu8' class='optionB' onclick='groupSub(this.id)'>Macaroni and cheese</span><span>:</span>
		<span id='d5menu9' class='optionB' onclick='groupSub(this.id)'>Turnovers and other grain-based items</span>
	</div>
	<div id='d26menu' class='optionC'>
		<span id='d5menu10' class='optionB' onclick='groupSub(this.id)'>Fried rice and lo/chow mein</span><span>:</span>
		<span id='d5menu11' class='optionB' onclick='groupSub(this.id)'>Stir-fry and soy-based sauce mixtures</span><span>:</span>
		<span id='d5menu12' class='optionB' onclick='groupSub(this.id)'>Egg rolls, dumplings, sushi</span>
	</div>
	<div id='d27menu' class='optionC'>
		<span id='d5menu13' class='optionB' onclick='groupSub(this.id)'>Burritos and tacos</span><span>:</span>
		<span id='d5menu14' class='optionB' onclick='groupSub(this.id)'>Nachos</span><span>:</span>
		<span id='d5menu15' class='optionB' onclick='groupSub(this.id)'>Other Mexican mixed dishes</span>
	</div>
	<div id='d28menu' class="menuB">
		<span id='d5menu16' class='optionB' onclick='groupSub(this.id)'>Pizza</span>
	</div>
	<div id='d29menu' class='optionC'>
		<span id='d5menu17' class='optionB' onclick='groupSub(this.id)'>Burgers</span><span>:</span>
		<span id='d5menu18' class='optionB' onclick='groupSub(this.id)'>Frankfurter sandwiches</span><span>:</span>
		<span id='d5menu19' class='optionB' onclick='groupSub(this.id)'>Chicken fillet sandwiches</span><span>:</span>
		<span id='d5menu20' class='optionB' onclick='groupSub(this.id)'>Egg/breakfast sandwiches</span><span>:</span>
		<span id='d5menu21' class='optionB' onclick='groupSub(this.id)'>Cheese sandwiches</span><span>:</span>
		<span id='d5menu22' class='optionB' onclick='groupSub(this.id)'>Peanut butter and jelly sandwiches</span><span>:</span>
		<span id='d5menu23' class='optionB' onclick='groupSub(this.id)'>Seafood sandwiches</span><span>:</span>
		<span id='d5menu24' class='optionB' onclick='groupSub(this.id)'>Deli and cured meat sandwiches</span><span>:</span>
		<span id='d5menu25' class='optionB' onclick='groupSub(this.id)'>Meat and BBQ sandwiches</span><span>:</span>
		<span id='d5menu26' class='optionB' onclick='groupSub(this.id)'>Vegetable sandwiches/burgers</span>
	</div>
	<div id='d30menu' class='optionC'>
		<span id='d5menu27' class='optionB' onclick='groupSub(this.id)'>Soup</span>
	</div>

<!--//////////////////////////////////////////////   B6   ////////////////////////////////////////////////////////////////////-->
	<div id='d31menu' class='optionC'>
		<span id='d6menu1' class='optionB' onclick='groupSub(this.id)'>Tomatoes</span><span> : </span>
		<span id='d6menu2' class='optionB' onclick='groupSub(this.id)'>Carrots</span><span> : </span>
		<span id='d6menu3' class='optionB' onclick='groupSub(this.id)'>Other red and orange vegetables</span><span> : </span>
		<span id='d6menu4' class='optionB' onclick='groupSub(this.id)'>Broccoli</span><span> : </span>
		<span id='d6menu5' class='optionB' onclick='groupSub(this.id)'>Spinach</span><span> : </span>
		<span id='d6menu6' class='optionB' onclick='groupSub(this.id)'>Lettuce-salads</span><span> : </span>
		<span id='d6menu7' class='optionB' onclick='groupSub(this.id)'>Other dark green vegetables</span><span> : </span>
		<span id='d6menu8' class='optionB' onclick='groupSub(this.id)'>String beans</span><span> : </span>
		<span id='d6menu9' class='optionB' onclick='groupSub(this.id)'>Cabbage</span><span> : </span>
		<span id='d6menu10' class='optionB' onclick='groupSub(this.id)'>Onions</span><span> : </span>
		<span id='d6menu11' class='optionB' onclick='groupSub(this.id)'>Corn</span><span> : </span>
		<span id='d6menu12' class='optionB' onclick='groupSub(this.id)'>Other starchy vegetables</span><span> : </span>
		<span id='d6menu13' class='optionB' onclick='groupSub(this.id)'>Other vegetables and combinations</span><span> : </span>
		<span id='d6menu14' class='optionB' onclick='groupSub(this.id)'>Fried vegetables</span><span> : </span>
		<span id='d6menu15' class='optionB' onclick='groupSub(this.id)'>Coleslaw, non-lettuce salads</span><span> : </span>
		<span id='d6menu16' class='optionB' onclick='groupSub(this.id)'>Vegetables on a sandwich</span>
	</div>
	<div id='d32menu' class='optionC'>
		<span id='d6menu17' class='optionB' onclick='groupSub(this.id)'>White potatoes, baked or boiled</span><span> : </span>
		<span id='d6menu18' class='optionB' onclick='groupSub(this.id)'>French fries and other fried white potatoes</span><span> : </span>
		<span id='d6menu19' class='optionB' onclick='groupSub(this.id)'>Mashed potatoes and white potato mixtures</span>
	</div>
<!--//////////////////////////////////////////////   B7   ////////////////////////////////////////////////////////////////////-->
	<div id='d33menu' class='optionC'>
		<span id='d7menu1' class='optionB' onclick='groupSub(this.id)'>Apples</span><span>:</span>
		<span id='d7menu2' class='optionB' onclick='groupSub(this.id)'>Bananas</span><span>:</span>
		<span id='d7menu3' class='optionB' onclick='groupSub(this.id)'>Grapes</span><span>:</span>
		<span id='d7menu4' class='optionB' onclick='groupSub(this.id)'>Peaches and nectarines</span><span>:</span>
		<span id='d7menu5' class='optionB' onclick='groupSub(this.id)'>Strawberries</span><span>:</span>
		<span id='d7menu6' class='optionB' onclick='groupSub(this.id)'>Blueberries and other berries</span><span>:</span>
		<span id='d7menu7' class='optionB' onclick='groupSub(this.id)'>Citrus fruits</span><span>:</span>
		<span id='d7menu8' class='optionB' onclick='groupSub(this.id)'>Melons</span><span>:</span>
		<span id='d7menu9' class='optionB' onclick='groupSub(this.id)'>Dried fruits</span><span>:</span>
		<span id='d7menu10' class='optionB' onclick='groupSub(this.id)'>Other fruits and fruit salads</span><span>:</span>
		<span id='d7menu11' class='optionB' onclick='groupSub(this.id)'>Pears</span><span>:</span>
		<span id='d7menu12' class='optionB' onclick='groupSub(this.id)'>Pineapple</span><span>:</span>
		<span id='d7menu13' class='optionB' onclick='groupSub(this.id)'>Mango and papaya</span>
	</div>
<!--//////////////////////////////////////////////   B8   ////////////////////////////////////////////////////////////////////-->
	<div id='d34menu' class='optionC'>
		<span id='d8menu1' class='optionB' onclick='groupSub(this.id)'>Citrus juice</span><span>:</span>
		<span id='d8menu2' class='optionB' onclick='groupSub(this.id)'>Apple juice</span><span>:</span>
		<span id='d8menu3' class='optionB' onclick='groupSub(this.id)'>Other fruit juice</span><span>:</span>
		<span id='d8menu4' class='optionB' onclick='groupSub(this.id)'>Vegetable juice</span>
	</div>
	<div id='d35menu' class='optionC'>
		<span id='d8menu5' class='optionB' onclick='groupSub(this.id)'>Diet soft drinks</span><span>:</span>
		<span id='d8menu6' class='optionB' onclick='groupSub(this.id)'>Diet sport and energy drinks</span><span>:</span>
		<span id='d8menu7' class='optionB' onclick='groupSub(this.id)'>Other diet drinks</span>
	</div>
	<div id='d36menu' class='optionC'>
		<span id='d8menu8' class='optionB' onclick='groupSub(this.id)'>Soft drinks</span><span>:</span>
		<span id='d8menu9' class='optionB' onclick='groupSub(this.id)'>Fruit drinks</span><span>:</span>
		<span id='d8menu10' class='optionB' onclick='groupSub(this.id)'>Sport and energy drinks</span><span>:</span>
		<span id='d8menu11' class='optionB' onclick='groupSub(this.id)'>Nutritional beverages</span><span>:</span>
		<span id='d8menu12' class='optionB' onclick='groupSub(this.id)'>Smoothies and grain drinks</span>
	</div>
	<div id='d37menu' class='optionC'>
		<span id='d8menu13' class='optionB' onclick='groupSub(this.id)'>Coffee</span><span>:</span>
		<span id='d8menu14' class='optionB' onclick='groupSub(this.id)'>Tea</span>
	</div>
<!--//////////////////////////////////////////////   B9   ////////////////////////////////////////////////////////////////////-->
	<div id='d38menu' class="menuB">
		<span id='d9menu1' class='optionB' onclick='groupSub(this.id)'>Beer</span><span>:</span>
		<span id='d9menu2' class='optionB' onclick='groupSub(this.id)'>Wine</span><span>:</span>
		<span id='d9menu3' class='optionB' onclick='groupSub(this.id)'>Liquor and cocktails</span>
	</div>
<!--//////////////////////////////////////////////   B10   ////////////////////////////////////////////////////////////////////-->
	<div id='d39menu' class='optionC'>
		<span id='d10menu1' class='optionB' onclick='groupSub(this.id)'>Tap water</span><span>:</span>
		<span id='d10menu2' class='optionB' onclick='groupSub(this.id)'>Bottled water</span>
	</div>
	<div id='d40menu' class='optionC'>
		<span id='d10menu3' class='optionB' onclick='groupSub(this.id)'>Flavored or carbonated water</span><span>:</span>
		<span id='d10menu4' class='optionB' onclick='groupSub(this.id)'>Enhanced water</span>
	</div>
<!--//////////////////////////////////////////////   B11   ////////////////////////////////////////////////////////////////////-->
	<div id='d41menu' class='optionC'>
		<span id='d11menu1' class='optionB' onclick='groupSub(this.id)'>Butter and animal fats</span><span>:</span>
		<span id='d11menu2' class='optionB' onclick='groupSub(this.id)'>Margarine</span><span>:</span>
		<span id='d11menu3' class='optionB' onclick='groupSub(this.id)'>Cream cheese, sour cream, whipped cream</span><span>:</span>
		<span id='d11menu4' class='optionB' onclick='groupSub(this.id)'>Cream and cream substitutes</span><span>:</span>
		<span id='d11menu5' class='optionB' onclick='groupSub(this.id)'>Mayonnaise</span><span>:</span>
		<span id='d11menu6' class='optionB' onclick='groupSub(this.id)'>Salad dressings and vegetable oils</span>
	</div>
<!--//////////////////////////////////////////////   B12   ////////////////////////////////////////////////////////////////////-->
	<div id='d42menu' class='optionC'>
		<span id='d12menu1' class='optionB' onclick='groupSub(this.id)'>Tomato-based condiments</span><span>:</span>
		<span id='d12menu2' class='optionB' onclick='groupSub(this.id)'>Soy-based condiments</span><span>:</span>
		<span id='d12menu3' class='optionB' onclick='groupSub(this.id)'>Mustard and other condiments</span><span>:</span>
		<span id='d12menu4' class='optionB' onclick='groupSub(this.id)'>Olives, pickles, pickled vegetables</span><span>:</span>
		<span id='d12menu5' class='optionB' onclick='groupSub(this.id)'>Pasta sauces, tomato-based</span><span>:</span>
		<span id='d12menu6' class='optionB' onclick='groupSub(this.id)'>Dips, gravies, other sauces</span>
	</div>
<!--//////////////////////////////////////////////   B13   ////////////////////////////////////////////////////////////////////-->
	<div id='d43menu' class='optionC'>
		<span id='d13menu1' class='optionB' onclick='groupSub(this.id)'>Sugars and honey</span><span>:</span>
		<span id='d13menu2' class='optionB' onclick='groupSub(this.id)'>Sugar substitutes</span><span>:</span>
		<span id='d13menu3' class='optionB' onclick='groupSub(this.id)'>Jams, syrups, toppings</span>
	</div>
<!--//////////////////////////////////////////////   B14   ////////////////////////////////////////////////////////////////////-->
	<div id='d44menu' class='optionC'>
		<span id='d14menu1' class='optionB' onclick='groupSub(this.id)'>Baby food: cereals</span><span>:</span>
		<span id='d14menu2' class='optionB' onclick='groupSub(this.id)'>Baby food: fruit</span><span>:</span>
		<span id='d14menu3' class='optionB' onclick='groupSub(this.id)'>Baby food: vegetable</span><span>:</span>
		<span id='d14menu4' class='optionB' onclick='groupSub(this.id)'>Baby food: mixtures</span><span>:</span>
		<span id='d14menu5' class='optionB' onclick='groupSub(this.id)'>Baby food: meat and dinners</span><span>:</span>
		<span id='d14menu6' class='optionB' onclick='groupSub(this.id)'>Baby food: yogurt</span><span>:</span>
		<span id='d14menu7' class='optionB' onclick='groupSub(this.id)'>Baby food: snacks and sweets</span>
	</div>
	<div id='d45menu' class='optionC'>
		<span id='d14menu8' class='optionB' onclick='groupSub(this.id)'>Baby juice</span><span>:</span>
		<span id='d14menu9' class='optionB' onclick='groupSub(this.id)'>Baby water</span>
	</div>
	<div id='d46menu' class='optionC'>
		<span id='d14menu10' class='optionB' onclick='groupSub(this.id)'>Formula, ready-to-feed</span><span>:</span>
		<span id='d14menu11' class='optionB' onclick='groupSub(this.id)'>Formula, prepared from powder</span>
	</div>
	<div id='d47menu' class='optionC'>
		<span id='d14menu10' class='optionB' onclick='groupSub(this.id)'>Human milk</span>
	</div>
<!--//////////////////////////////////////////////   B15   ////////////////////////////////////////////////////////////////////-->
	<div id='d48menu' class='optionC'>
		<span id='d15menu1' class='optionB' onclick='groupSub(this.id)'>Protein and nutritional powders</span><span>:</span>
		<span id='d15menu2' class='optionB' onclick='groupSub(this.id)'>Not included in a food category</span>
	</div>

</div></div></div></div></div></div></div>

<!--
<table class='google'>
<tr>

<td><button type='button' onclick="txtLineByLine();"  translate="no">Show to Translate </button><span style='color:white'> => </span></td>
<td style='color:black;font-size:12px;'><div id="google_translate_element" > </div>
											<!--recipe for translating-->
												<!---<div id='recipeToTrans' style="width:50%;"></div>

											<!---Start Google trans --->
													<!---<script type="text/javascript">
													function googleTranslateElementInit() {
													  new google.translate.TranslateElement({pageLanguage: 'xx'}, 'google_translate_element');
													}
													</script>
											<!---Stop Google trans --->
<!---</td></tr>
</table>
-->
</div>
<br><br><div style='width:100%;text-align:center;font-size:12px;color:yellow;'><b>Recipes Lists</b></div>
<script>
function showSearchDisplay(){
	if (document.getElementById('description').style.visibility == 'hidden')
	{document.getElementById('description').style.visibility='visible'}
	else
	{document.getElementById('description').style.visibility='hidden'}

}

</script>


<script>
function toImport(){
//alert('Update Lists toImport')
    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "../importExport/importing/resources/importing.php";
    //data none
	var vars = '';

    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				//var return_data = hr.responseText;
				//document.getElementById("resultBash_").innerHTML = '';
//if (return_data == ''){alert('Vacío: '+return_data)}else{alert('No vacío: '+return_data)}
//alert(document.getElementById('ver').innerHTML)
update()
			}
		}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);
    //HTML folder to put the output provided by the server-side PHP script when 'status' 200 is reached
    //document.getElementById("resultBash").innerHTML = "processing...";
}

function deleteRecipe(){
	//look for checked recipes and take there Ids porque IdI_1=IdI_1.split('_')

const checkBoxNameColl = document.getElementsByName("recipeFile");
var idNameHref='';collect1='';collect2='';collectionOfFileNamesChecked=''
    for (let i = 0; i < checkBoxNameColl.length; i++) {
		if (checkBoxNameColl[i].checked == true) {
			idNameHref=checkBoxNameColl[i].id
//alert(idNameHref)
			idNameHrefParts=idNameHref.split('_')
			RecipeFileName=idNameHrefParts[0]+idNameHrefParts[1];

				if (idNameHrefParts[0] == 'IdR'){

					collect1=collect1+' ../../../recipes/recipeFiles/'+document.getElementById(RecipeFileName).innerHTML
					//alert('collect1 IdR '+collect1)
				}
				else
				{

					collect2=collect2+' ../'+document.getElementById(RecipeFileName).innerHTML
					//alert('collect2 IdI '+collect2)
				}//if

         }//if
    } //for
collect1=collect1.slice(1);
collect2=collect2.slice(1);
			collectionOfFileNamesChecked=collect1+'|'+collect2
//alert('It should send it to collectionOfFileNamesChecked: '+collectionOfFileNamesChecked)


    var hr = new XMLHttpRequest();
    //Variable containing the url to get to the server side php script
    var url = "../importExport/importing/resources/delete.php";
    //data none

    var fn = collect1;var ln = collect2;
    	var vars = "urlFileToDelete1="+fn+"&urlFileToDelete2="+ln;

    hr.open("POST", url, true);
    //Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		//Fire the onreadystatechange event for the XMLHttpRequest object and wait until 'state 200' is reached.
		hr.onreadystatechange = function() {
			if(hr.readyState == 4 && hr.status == 200) {
				//To be executed when the 'status 200' is reached
				var return_data = hr.responseText;
				alert(return_data);

update()
			}
		}
    //Execute the request adding the name_variable value pairs before 'status 200' is reached
    hr.send(vars);
}

</script>
<style>
.flex-container {
    display: flex;
}

.flex-child {
    flex: 1;
    border: 1px solid gold;
	background-color:maroon;
	padding-left:5px;
	padding-top:5px;
}

.flex-child:first-child {
    margin-right: 20px;
}
</style>
<div id='' style='display: inline-block;width:100px;text-align:center;margin-bottom:5px;padding:2px 0 2px 0;cursor:pointer;color:gold;border: 1px solid white;' onclick="toImport()">Update Lists </div> &nbsp <span id='' style='border: 1px solid white;display:inline-block;width:180px;text-align:center;margin-bottom:5px;padding:2px 0 2px 0;cursor:pointer;color:gold;' onclick='deleteRecipe()'>Delete from Lists (Checked) </span>
<div style='display: inline-block;width:96.8%;margin-bottom:5px;padding:0 0 0px 40px;color:gold;border: 1px solid white;'>
	<div style='color:white;padding-bottom:5px;padding-top:5px;'><span style='font-color:bold;color:gold;'>Relax!:</span> You are <span style='color:#FFB6C1'><i><b>not</b></i></span> dealing with your recipe database (<span style='font-color:bold;color:gold;'>Delete button:</span> Delete those checked in both boxes <span style='font-color:bold;color:gold;'>Display word:</span> Show recipe above).</div>
</div>

<div class="flex-container">

  <div class="flex-child magenta"><div style='width:100%;text-align:center;color:#FFC0CB;'>&#8224;&#8224; Safe Recipes</div>
	<div id="recipeFiles" style="padding-top:5px;">
		<?php

		$file_list = shell_exec("ls recipeFiles | grep -Ei '[0-9]+_[[:alnum:]]+.html$'");
		$file_array = explode("\n", trim($file_list));
		$IdR='1';
		foreach ($file_array as $file) {
			// Ignore empty strings (last element of the array)
			if ($file === '') {
				continue;
			}

			// Do something with $file
			echo '<input name="recipeFile" type="checkbox" id="IdR_'.$IdR.'" onclick="getStripVal(\'recipeFile\')"> <a id="IdR'.$IdR.'" style="color:yellow;margin-left:5px;" href="./recipeFiles/'.$file . '" target="blank">'.$file.'</a> '.$IdR.'<div style="display:inline-block;margin-bottom:4px;margin-right:5px;cursor:pointer;" onclick="banban(\''.$file.'\')">: Display</div><br>';
		$IdR=$IdR+1;
		}
		?>
	</div>
  </div>

  <div class="flex-child green"><div style='width:100%;text-align:center;color:yellow;'>Risky Recipes<br><span style="color:#DAA520"><i>mesa/importExport/importing</i></span></div>
	<div id="importing" style="padding-top:5px;">
		<span style='color:white;padding-left:10px;text-align:justify;word-break:break-word;'>
		The app does not work in Firefox; use Google Chrome instead.</span><br><br><span style='color:white;padding-left:10px;text-align:justify;word-break:break-word;' >Save recipe files only from people you trust. To import a recipe safely, place the files to import in the <span style='word-break:break-all;'>'mesa/importExport/importing'</span> folder, press the 'Update Lists' button ' and click display option next to any file name. In the 'Recipe Grid' you must 'Export Recipe' to complete the operation.</span><br><br><span style='color:white;padding-left:10px;text-align:justify;word-break:break-word;'>Read the Tutorial for more information (Delete from list, Include in the DB, etc.)</span>
	</div>
  </div>

</div> <!--div flex container -->


<div style='cursor:pointer;color:yellow;width:100%;text-align:center;margin-top:10px;font-weight:bold;' onclick="showSearchDisplay()"> Search Box<br><span style="color:white;font-size:10px;font-weight:normal">Show/Hide</span></div>


<style>

  .container {
    width: 100%;
    height: 250px;
position: relative;
	margin-bottom:380px;

  }
  .showRecipe {
    width: 100%;
	height: 250%;
    background-color:#696969;
position:absolute;
    top: 0px;
    left: 2px;
    z-index: 1;

  }
  .showSearch {
    width: 100%;
    height: 250%;
    background-color:#8B0000;
position:absolute;
    top: 0px;
    left: 2px;
    z-index: 0;
overflow-y : scroll;
overflow-x : scroll;
  }
</style>


<div class='container' style='margin-top:20px;'>
	<div style="visibility:visible" class='showRecipe' id='description'>
		Rules for searching:<br>
			<div style='color:white;'>
			1. The non-empty box with the lowest ordinal number will be used to submit the search data.<br>
			2. The Image and Url boxes allow only one <span style='color:yellow;'>STR</span> for searching, while the '<span style='color:yellow;'>@</span>' symbol will be part of the <span style='color:yellow;'>STR</span>, i.e. 'john@smith.com'<br>
			3. Do not use disruptive characters, <span style='color:yellow;'>' ^ " & $ | \ ! #</span>, more than one '<span style='color:yellow;'>@</span>' symbol, protocols, such as '<span style='color:yellow;'>http://</span>', ​​etc., or more than one <span style='color:yellow;'>Reg No</span>.<br>
			4. In the '<span style='color:yellow;'>Search Box</span>', the '<span style='color:yellow;'>Pattern</span>' option is checked by default to search '<span style='color:yellow;'>STR1 and STR2</span>', and not '<span style='color:yellow;'>STR1 or STR2</span>'.<br>
			5. In cases <span style='color:yellow;'>2, 3, 6, 7, 8</span> the search is carried out in <u>selected fields</u>. While in case 9, '<span style='color:yellow;'>Ingredients</span>', the search is carried out in <u>complete records</u>.<br>
			6. In the case of '<span style='color:yellow;'>Ingredients</span>', the '<span style='color:yellow;'>AND</span>' pattern option will return records matching <span style='color:yellow;'>STR1</span> in the '<span style='color:yellow;'>Ingredients</span>' DB file and <span style='color:yellow;'>STR2</span> in '<span style='color:yellow;'>Preparation</span>', both matches will be displayed excluding duplicate records. While the '<span style='color:yellow;'>OR</span>' pattern option is just a more restrictive alternative to '<span style='color:yellow;'>AND</span>'—It is not a logical symmetry—and will return records matching <span style='color:yellow;'>STR2</span> in '<span style='color:yellow;'>Preparation</span>' and matching <span style='color:yellow;'>STR1</span> in previous <span style='color:yellow;'>STR2</span> records.
			</div>
	</div>

<script>


var vtarget='';var vpatterns='';
//alert(document.getElementsByName(this.name)[0].value)

//function target(tId){
//for (i=1;i<3;i++){document.getElementById('t_'+i).checked=false;}
//document.getElementById(tId).checked=true;
//vtarget=tId;
//}
//It works if you apply 'style' in the 'if statement'
var vpatterns = '';

function patterns(pId) {
    var checkbox = document.getElementById('p_2');
//alert(checkbox.checked)
    // Use the 'checked' property directly, not 'style.checked'
    if (checkbox.style.checked === false) {
        checkbox.style.checked = true; // Assign true, not 'true'
        vpatterns = 'p_2';
    } else {
        checkbox.style.checked = false; // Assign false, not 'false'
        vpatterns = 'p_1';
    }

    //alert('pattern: ' + pId);
    alert('vpatterns: ' + vpatterns);
}


function showSearchLoad(regId){
//alert('showSearchLoad')
//alert('showSearchLoad function: '+regId)
dataId=regId.split('_')
//alert('dataId: '+dataId[2])
//alert(document.getElementById('found'+dataId[2]).innerHTML)

ingJs=document.getElementById('found'+dataId[2]).innerHTML
	stepsM=ingJs.split('_');	//0,1,2
//alert('stepsM[0]: '+stepsM[0])

n=1;ingJsT='';searchWord = "Step";accumulate=''

//references
ref=stepsM[0].split('|')

	rVal=ref[0].split(':')
	document.getElementById('file').value=dataId[0]
//alert('dataId[0]: '+dataId[0])

	rVal=ref[7].split(':')
//alert('ref[7]: '+ref[7])
document.getElementById('title').value=rVal[1]
//alert('rVal[1]: '+rVal[1])

	rVal=ref[8].split(':')
document.getElementById('author').value=rVal[1]
//exit
	rVal=ref[9].split(':')
document.getElementById('country').value=rVal[1]
//alert('dataId[0]: '+dataId[0])
//exit
	rVal=ref[10].split(':')
document.getElementById('url').value=rVal[1]
//alert('dataId[0]: '+dataId[0])


//ingredients
//ing=stepsM[1].split('|')
	iVal=stepsM[1].split('#')
		document.getElementById('ingredients').value=iVal[0]

				for (i=0;i<iVal.length;i++){
				accumulate=accumulate+'\r\n'+iVal[i]


				}
document.getElementById('ingredients').value=accumulate.trim().replace(/^\s*[\r\n]/gm, '')

		stepsm=stepsM[2].split('|')

		for (j=0;j<stepsm.length;j++){
			stepsm_=stepsm[j].split('#')
			for (i=0;i<stepsm_.length;i++){
				myString = stepsm_[i];
				if (myString.includes(searchWord)) {
					ingJsT=ingJsT+'Step '+n+'\r\n'
				n=n+1;
				} else {
					ingJsT=ingJsT+''+stepsm_[i]+'\r\n\n'
				}
			}
		}

document.getElementById('steps').value=ingJsT.trim().replace(/\n+$/, '')
//miscelanea

rVal=ref[1].split(':')
document.getElementById('popFoodName').value=rVal[1]
rVal=ref[2].split(':')
document.getElementById('g').value=rVal[1]
rVal=ref[3].split(':')
document.getElementById('sg').value=rVal[1]
rVal=ref[4].split(':')
document.getElementById('treat').value=rVal[1]
rVal=ref[6].split(':')
document.getElementById('kcal').value=rVal[1]
//exit
}

</script>

	<div style="display:block" class='showSearch' id='showSearch'>

<div style='display: inline-block;width:96.5%;margin:0px 0 0px 0;padding:5px 0 5px 40px;border: 1px solid white;'>
<span style='color:#FFC0CB;'>First 'Mark <span style='color:yellow;font-weight:bold;'><u>Recipes</u> above</span><span style='font-size:20px;'>&#x2191;</span>' </span>:
<input type='Button' style='margin: 0 10px 10px 0px;' value='Include in the DB' onclick="pendings('Importable')">

<span style='color:gold;'>Adding</span>:<input type='checkbox' name='addReplace' id='AddReg' onclick="alternateAddRpl(this.id)" checked>  <span style='color:gold;'>Replacing</span>:<input type='checkbox' name='addReplace' id='RplReg' style='margin-right:25%;' onclick="alternateAddRpl(this.id)">
<span style='color:#FFC0CB;'>First <u>search</u> and then 'Mark <span style='color:yellow;font-weight:bold;'><u>Records</u> below</span><span style='font-size:20px;'>&#x2193;</span>'</span>:
<input type='button' style='margin: 0 10px 0px 0px;' value='Delete from DB' onclick="pendings('found')"><br>
<span style='color:yellow'>~ Messages: </span><span id='msgChef' style='color:white;'></span></div>


<table style='width:100%;background-color:lightgray;color:black;font-weight:bold;'>
	<tr>
<td style='color:blue;width:50%;'><!-- Target:
<input id='t_1' type='checkbox' name='target' onclick='target(this.id)' checked> Registers <input style='display:none;' id='t_2' type='checkbox' name='target' onclick='target(this.id)' checked>-->
<span style='color:blue;padding-left:10px;width:3%;'>Pattern:</span>
	<!--<td style='color:maroon;'> AND=&xcap;/OR=&xcup;<input id='p_1' type='checkbox' onclick='patterns(this.id)' checked> 1-->
	<input id='p_2' type='checkbox' style='margin-left:5px;' onclick="patterns('p_2')" checked>1 AND 2
	<!--<input id='p_3' type='checkbox' style='margin-left:15px' onclick='patterns(this.id)'>1&xcap;2&xcap;3
	<input id='p_4' type='checkbox' style='margin-left:15px' onclick='patterns(this.id)'>1&xcap;2&xcap;3&xcap;4
	<input id='p_5' type='checkbox' style='margin-left:15px' onclick='patterns(this.id)'>1&xcup;2
	<input id='p_6' type='checkbox' style='margin-left:15px' onclick='patterns(this.id)'>(1&xcup;2)&xcap;3
	<input id='p_7' type='checkbox' style='margin-left:15px' onclick='patterns(this.id)'>(1&xcup;2)&xcap;3&xcap;4
	<input id='p_8' type='checkbox' style='margin-left:15px' onclick='patterns(this.id)'>(1&xcup;2&xcup;3)&xcap;4-->
	<span style='margin-left:10px;' class='divButton' name='up' onclick='search()'>Search Recipe</span></td></tr>
</table>

<div style='margin:5px 0 5px 5px;width:100%;text-align:center;color:#FFC0CB;'>&#8224; Database Recipe Strips</div>
<div id='resultBash'>
<div style='margin-left:20px;text-align:justify;'>
&nbsp;The Searching method:<br>
<span style='display: inline-block;width:96.5%;padding:5px 0 0px 5px;text-align:justify;'>Step 1: <span style='color:yellow'>In the recipe display grid</span>, right-click inside the input boxes and type what you want to search for.</span><br>
<span style='display: inline-block;width:96.5%;padding:5px 0 0px 5px;text-align:justify;'>Step 2: Click on 'Clear to Search' button to set the '<span style='color:yellow;'>search mode</span>'.</span><br>
<span style='display: inline-block;width:96.5%;padding:5px 0 0px 5px;text-align:justify;'>Step 3: Left click inside the input boxes to programmatically set the '<span style='color:yellow;'>ordinal numbers</span>'.</span>
<div style='text-align:justify;padding:10px 100px 10px 50px;'>
	Each title in the 'Recipe Grid' has a 'title number' on the left and a selection 'ordinal number' will be placed on the right after a left mouse click inside the input box (right mouse click to type). The selection order follows the ascending scale of the number of titles. A 'title number' cannot be <u>followed</u> by a lower one, i.e. 'title number' <b>2</b> with the 'ordinal number' <b>{1</b> cannot be followed by a 'title number' <b>1</b> and 'ordinal number' <b>{2</b>, but may be followed by the title number: 3, 4 - 8, 9, 10 or 11.
</div>

<span style='display: inline-block;width:96.5%;padding:5px 0 0px 5px;text-align:justify;'>Step 4:<span style='color:yellow'> In this current 'Search Box'</span>, check the 'Target' box as well as select the pattern you want to search for.</span><br>
<span style='display: inline-block;width:96.5%;padding:5px 0 0px 5px;text-align:justify;'>Step 5: Click the 'Search Recipe' button in yellow (the recipe display grid has another one).</span><br><br>


</div></div></div>
</div>



<div style='color:#ABBED3;margin-bottom:20px;' translate="no">The database (Norwegian Food Composition Database 2022) is courtesy of the  Norwegian Food Safety Authority.
www.matvaretabellen.no
</div>

<span style='font-size:12px;color:yellow;cursor:pointer;' onclick='showHide()'>⇅ Show/Hide the Tutorial</span>

<div style='display:none;' id='instrucciones'><b><span style='text-align:justify;cursor:pointer;color:yellow;display:none;'>Manual de Instrucciones para que la aplicación funcione y usted pueda sacarle provecho</b></span><br>

<span style='color:#D3ABBD;font-weight:bold;'>Su utilidad (Utility):</span><br>
La Tecnología Google permite traducir de una lengua a cualquier otra si usted instala la extensión «Google Traslate» (barra de google y botón Traducir) en su navegador. Para instalar esa extensión puede pulsar, por ejemplo, este enlace: <a style='color:black' href='https://chrome.google.com/webstore/detail/google-translate/aapbdbdomjkkjkaonfhkkikfgjllcleb?hl=es' target='blank_'>Extensión del traductor de Google</a><br><br>
<span style='color:#ABBED3;' translate="no"><i>Google Technology allows you to translate from one language to any other if you install the “Google Translate” extension (google bar and Translate button) in your browser. To install that extension you can click, for example, this link: <a style='color:black' href='https://chrome.google.com/webstore/detail/google-translate/aapbdbdomjkkjkaonfhkkikfgjllcleb?hl=es' target='blank_'>Google Translator Extension</a></i></span><br><br>

<span style='color:#D3ABBD;font-weight:bold;'>Cómo traducir (HowTo):</span><br>
La aplicación muestra, de ejemplo, una receta por defecto en inglés, el resto  está mayormente en español. Los datos presentes en las cajitas del cuestionario y algunas otras palabras de la página en español no son traducidas. Pruebe a traducir seleccionando su lengua nativa u otra lengua en el menú de google bajo el título <span translate="no">«Traducir»</span>. Por ejemplo, seleccione «francés» para mostrar 3 lenguas, y no haga nada más, sólo observe los cambios producidos. <br><br>

<span style='color:#ABBED3;' translate="no"><i>The application shows, for example, a default recipe in English, the rest is mostly in Spanish. The data present in the boxes of the questionnaire and some other words on the page in Spanish are not translated. Try translating by selecting your native language or another language in the google menu under the heading "Traducir". For example, select "French" to show 3 languages, and do nothing else, just watch the changes.</i></span><br><br>

<span >Aparece la barra de Google Translate bajo la barra del navegador. A la izquierda dice 'Traducido al: francés' e inmediatamente a su derecha un botón que dice 'Mostrar texto original'.  En el extremo derecho presenta el menú 'Opciones', con éste de desactiva la traducción de la página, mientras que no se desactiva recargando la página ni refrescando. Pulse sobre ese menú para 'Desactivar la traducción de este sitio'.</span><br><br>

<span style='color:#ABBED3;' translate="no">The Google Translate bar appears under the browser bar. On the left it says 'Translated to: French' and immediately to its right a button that says 'Show Original Text'. On the far right it presents the 'Options' menu, with this one you deactivate the translation of the page, while it is not deactivated by reloading the page or refreshing it. Click on that menu to 'Turn off translation for this site'. The page returns entirely to the initial conditions.</span><br><br>

<span style='color:#D3ABBD;font-weight:bold;'>Traducir y guardar el contenido de la receta:</span><br>
<span >Al pulsar sobre 1. <span translate="no">'Mostrar Receta'</span>, 2. <span translate="no">'Seleccionar Idioma'</span>, y 3. <span translate="no">'Guardar Receta'</span>, la receta traducida puede ser guardada. Puede seguir seleccionando otras lenguas, y seguir guardando varias traducciones. Se recomienda añadir al nombre de archivo el idioma en el que ha sido traducida. Por ejemplo, si la aplicación ofreciera MineralWater_1672926452528.html, usted podría modificar el nombre a MineralWater_ingles_1672926452528.html, MineralWater_frances_1672926452528.html, etc.</span><br><br>
<span style='color:#ABBED3;' translate="no">By clicking on 1. 'Mostrar Receta', 2. 'Seleccionar Idioma', and 3. 'Guardar Receta', the translated recipe can be saved. You can continue to select other languages, and continue to save multiple translations. It is recommended to add the language in which it has been translated to the file name. For example, if the application offered MineralWater_1672926452528.html, you could modify the name to MineralWater_ingles_1672926452528.html, MineralWater_frances_1672926452528.html, etc.</span><br><br>

<span >Se puede volver a ver el texto original usando el menú <span style='color:#ABBED3;' translate="no">'Mostrar texto original'</span> en el lado izquierdo de la barra de Google Translate pero mejor es usar el menú del extremo derecho y pulsar <span style='color:#ABBED3;' translate="no">'Desactivar la traducción de este sitio'</span>.</span><br><br>
<span style='color:#ABBED3;' translate="no">You can see the original text again using the 'Mostrar texto original' menu on the left side of the Google Translate bar but it is better to use the menu on the far right and click 'Desactivar la traducción de este sitio'.</span><br><br>

O1f1	02f2	O3f3							O10f4		O12f22	O13f7 G	O14f8 SatFat		O16-17f13		O18f9 Chol	O22f6 HC				O23f12 Fib	O24f5 P	O25f10 Sal	O26f11 Alcoh	O27f14			O30f17	031f18	O32-37f15						O38f16	O39f19	040f20		O42f21



<span>La Base de Datos</span><br><br>
<span>La Base Datos total es un archivo CSV que es manejado por un script Bash. Por ejemplo, mesa/scrips/ajaxMadeOf.scr toma el registro que el usuario busca en el archivo mesa/bd/work.csv Este registro tiene 48 campos (celdas en Hoja de Cálculo) de los cuales la App sólo usa los 24 que están en las celdas 1,2,3,10,12,13,14,16-17,18,19,23,24,25,26,27,30,31,32-37,38,39,40,42, añadiendo 2 que no existen en work.csv: 'Cantidad total de nutriente' y 'Total de Kc'. Después de sumar los Acidos grasos Omega (16-17) y el complejo de vitaminas B (32-37) los envía a la página donde Javascript asigna el origin (Onºcelda) a su campo de cuestionario correspondiente (fnºcampo) de la siguiente forma:<br><br>

O1f1 (Reg. No.), 02f2 (grupo:subgrupo), O3f3 (made of), O10f4 (descripción), O12f22 (Kc%), O13f7 (Grasa total), O14f8 (grasa saturadas), O16-17f13 (Acidos grasos Omegas), O18f9 (Colesterol), O22f6 (Azucar), O23f12 (Fibras), O24f5 (Proteinas), O25f10 (Sal), O26f11 (Alcohol), O27f14 (Vit A), O30f17 (Vit D), 031f18 (Vit E), O32-37f15 (Complejo Vit B), O38f16 (Vit C), O39f19 (Calcio), 040f20 (Hierro), O42f21 (Potasio), f23 (gramos de nutriente), f24 (Kc de los gramos de nutriente)<br><br>

Cuando tenga que guardar un registro modificado o nuevo se realiza el recorrido inverso, es decir, javascript entrega esta última serie a PHP, que ejecuta el bash script entregándole los datos. El script bash lo añade a las celdas correspondientes en work.csv; los campos calculados no se añaden. Bash también se ocupa de verificar si ya existe lo que se va a añadir a work.csv verificando el campo de nº de registro, al ser éste un 'timestamp' y, por lo tanto, no puede repetirse. Si no se repite lo añade al final del archivo y si se repite envía un mensaje al javascript para informar al usuari. Por seguridad, bajo plena consciencia del usuario, se añade un botón específico 'Replace Reg' para reescribir un registro.</span>
<br><br>
tras el script scr recibir el set de la App (tiene que llegar en este orden: f1,f2,f3,f4,f22,f7,f8,f13,f9,f6,f12,f5,f10,f11,f14,f17,f18,ff15,f16,f19,f20,f21) mediante el $1 de PHP crea el array<br><br>
regArray=('reg01F1' 'gSgO2F2' 'madeOfO3F3 'descriptionO10F4' 'kc%O12F22' 'fat013F7' 'satFatO14F8' 'omegaO16-17F13' 'cholO18F9' 'hcO22F6' 'fibO23F12' 'protO24F5' 'saltO25F10' 'alcohO26F11' 'vitaO27F14' 'vitdO30F17' 'viteO31F18' 'vitbO32-37F15' 'vitcO38F16' 'caO39F19' 'feO40F20' 'potO42F21')
<br><br>
y sustituye los valores del set cargados en el array creando el reg en la variable $regToSave
regToSave=${regArray[0]}'|'${regArray[1]}'|'${regArray[2]}'|'${regArray[3]}'||||||||'${regArray[4]}'|'${regArray[5]}'|'${regArray[6]}'||'${regArray[7]}'||'<br>${regArray[8]}'||||'${regArray[9]}'|'${regArray[10]}'|'${regArray[11]}'|'${regArray[12]}'|'${regArray[13]}'|'${regArray[14]}'|||'${regArray[15]}'|'${regArray[16]}'|'<br>${regArray[17]}'||||||'${regArray[18]}'|'${regArray[19]}'|'${regArray[20]}'||'${regArray[21]}
<span >Sustituir Reg. No. por timestamp comenzando por x=date -d '01/01/2010' +"%s" y añadiendo 1 segundo cada vez.</span><br><br>
<span style='color:#ABBED3;' translate="no"></span><br><br>


<br><br><br><br><br>
fileName='tmp';	#work.csv<br>
searchString='1262304001';	#set given by the App | cut -d'|' -f1<br><br>

Add.scr<br>
if match RegMatchedLine=$(grep $searchString $fileName) => exist =>  message to 'Replace Reg' button<br>
else<br>
	Add $regToSave to the end of work.csv >><br><br>

Replace.scr<br>
	match	=> Sí exist	=>	Catch nº linea<br>
								N=$(grep -P $searchString $fileName | wc -l);<br>
							Use	newLine given by the App<br>
								new line 'Given by the App => $regToSave<br>
							Replace line Nº by newLine<br>
								sed -i ${N}"s/.*/$regToSave/" "$fileName"<br><br>

Falta el search<br>
varA='1:cheese';varB='goat';varC='white';grep -i "^.*|$varA|$varB|.*$varC*.|" work.csv<br><br>

. Matches any single character<br>
* Matches the previous element zero or more times<br>
+ One or more (grep needs to scape \+<br>
.* empty, any char, any char more than one<br>

reg='^[0-9]\+';varA='.*';varB='.*';varC='.*';<br>
reg='^[0-9]\+';varA='.*';varB='.*';varC='.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv 									#No permitido<br>
reg='^1262304001\+';varA='.*';varB='.*';varC='.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv | tee /dev/tty | wc -l 		#Específico total<br>
reg='^[0-9]\+';varA='.*cheese.*|';varB='.*';varC='.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv | tee /dev/tty | wc -l	#Sólo grupo<br>
reg='^[0-9]\+';varA='.*';varB='.*goat.*';varC='.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv | tee /dev/tty | wc -l		#Sólo madeOf<br>
reg='^[0-9]\+';varA='.*';varB='.*';varC='.*white.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv | tee /dev/tty | wc -l	#Sólo descripción<br>
reg='^[0-9]\+';varA='.*cheese.*';varB='.*';varC='.*white.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv | tee /dev/tty | wc -l #grupo y descripción<br>
reg='^[0-9]\+';varA='.*';varB='.*goat.*';varC='.*white.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv | tee /dev/tty | wc -l 	#madeOf y descripcion<br>
reg='^[0-9]\+';varA='.*cheese.*';varB='.*goat.*';varC='.*white.*';grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv | tee /dev/tty | wc -l	#todos<br>

el nº de matches lo hace wc -l
reg='^.*';varA='.*';varB='goat';varC='.*white.*';lines=$(grep -i "$reg|$varA|$varB|.*|.*|.*|.*|.*|.*$varC*.|" work.csv > tmp);totalLines=$(cat tmp | wc -l);
cat tmp;			=> formatear para exponer en página
echo totalLines; 	=> añadir para recuperar con javascript el total de líneas => si más de 15 líneas debe 'especificar' más la búsqueda o hacerlo manual.

</div><br>
<!--Don't delete. Needed for recording translated recipe data -->
<div style='color:#696969;' id='referencesPage'></div>
<div style='color:#696969;' id="ingredientes"></div>
<div style='color:#696969;' id="stepes"></div>
<!-- ........................................................ -->


<br><br>
1. Converting 100 mililiters to grams for an ingredient with a density of 1.39 g/ml (Volume x Density = Weight).<br>
100 ml × 1.39 g/ml (g/cm³) = 139 g<br><br>
Ask to ChatGPT: which is the density of jam?<br>
The density of jam can vary depending on the type of fruit used and the amount of sugar and pectin added during the cooking process. Typically, the density of jam ranges from 1.22 to 1.56 g/cm³.<br> => 1,39&#177;0.17 g/ml (The deviation from the central value is not much)<br><br>
Ask to ChatGPT: which is the density of honey?<br>
The density of honey can vary depending on the type of honey and its water content, but typically it ranges from 1.36 to 1.44 g/cm³ at room temperature.<br>
=> 1,4&#177;0,04 (again, it 's not much)<br><br>

<table border="1" width='60%' style='background-color:black;'>
<tr style='color:gold;font-weight:bold;text-align:center;'><td>Ethanol</td><td>Olive oil</td><td>Water</td><td>Wines</td><td>Lemon juice</td><td>Beers</td><td>Jam</td><td>Honey</td></tr>
<tr style='color:gray;'><td>≤0.789 g/ml</td><td>0.91-0.93 g/ml</td><td>1 g/ml</td><td>0.99-1.02 g/ml</td><td>1.03 g/ml</td><td>1.01-1.1 g/ml</td><td>1.22-1.56 g/ml</td><td>1.36-1.44 g/ml</td></tr>
<tr style='font-weight:bold;text-align:center;'><td>≤0.789 g/ml</td><td>0.92 g/ml</td><td style='color:gold;'>1 g/ml</td><td>1.005 g/ml</td><td>1.03 g/ml</td><td>1.055 g/ml</td><td>1.39 g/ml</td><td>1.4</td></tr>
<tr style='font-weight:bold;text-align:center;'><td>Whipped cream</td><td>Nut butter, Lard</td><td style='color:gold;'>1 g/ml</td><td>Cream cheese</td><td>Milk, Yolk, Yogurt</td><td>Heavy cream</td><td>Egg white</td><td>Syrup</td></tr>
<tr style='font-weight:bold;text-align:center;'><td colspan='2'>Whiskeys</td><td style='color:gold;'>1 g/ml</td><td>Cottage, Ricotta</td><td colspan='2'>Most fruits&vegetables</td><td colspan='2'>Whole grains, legumes, nuts and seeds</td></tr>
</table>Density is defined as mass per unit volume. It has the SI unit kg m-3 or kg/m3 and is an absolute quantity. Specific gravity is the ratio of a material's density with that of water at 4 °C (where it is most dense and is taken to have the value 999.974 kg/m³).<br>density=g/ml (36 g/3 mL=12 g/mL)<br>specific gravity=density/water density (1 g/mL) => 12/1=12 (12 times greater than water)<br>Table of food gravity ... https://www.foodstandards.gov.au/industry/npc/Pages/specific-gravities.aspx<br><br><br>
The use of the Metric System facilitates universal communication.
<table border="1" width='50%' style='background-color:black;'>
<tr style='color:gold;font-weight:bold;text-align:center;'><td style='width:15%;text-align:left;'>density g/ml <input style='width:40%;text-align:center;'type='input' value='1'></td><td style='width:15%;text-align:left;'>ml (1 ml)</td><td style='width:15%;text-align:left;'>grams (1 g)</td><td style='width:15%;text-align:left;'>US fl. ounce (0.035 oz)</td></tr>
<tr><td>1 Tbsp (EU)</td><td style='background-color:white;color:black;' contenteditable>15</td><td style='background-color:white;color:black;' contenteditable>15 ml x density</td><td style='background-color:white;color:black;' contenteditable>0.52</td></tr>
<tr><td>1 Tsp (EU)</td><td style='background-color:white;color:black;' contenteditable>5</td><td style='background-color:white;color:black;' contenteditable>5 ml x density</td><td style='background-color:white;color:black;' contenteditable>0.17</td></tr>
<tr><td>1 Coffe Cup (EU)</td><td style='background-color:white;color:black;' contenteditable>120</td><td style='background-color:white;color:black;' contenteditable>120 ml x density</td><td style='background-color:white;color:black;' contenteditable>5</td></tr>
<tr style='background-color:black;color:white;'><td>1 Coffe spoon (csp) => </td><td>2 saltspoon (ssp) => </td><td>1/2 tsp</td><td>1/4 desertspoon</td></tr>
<tr><td>1 Cup (EU)</td><td style='background-color:white;color:black;' contenteditable>250</td><td style='background-color:white;color:black;' contenteditable>250 ml x density</td><td style='background-color:white;color:black;' contenteditable>250 X 0.035 (8)</td></tr>
</table>
https://en.wikipedia.org/wiki/Cup_(unit)<br>
https://en.wikipedia.org/wiki/Cooking_weights_and_measures<br>
https://www.aqua-calc.com/calculate/food-volume-to-weight<br>
<br><br><br><br>
<div id='abc' oncontextmenu="javascript:document.getElementById('ddd').innerHTML='';return false;">Lorem Ipsum</div>
<div id='ddd'>sdfg</div>
	<div id='hook'>
		<?php echo exec("echo $(cat db/fileLoad | cut -d'@' -f1)"); ?>
	</div>
<script>
window.document.title="Recipes";

				   fileSent=document.getElementById('hook').innerHTML
					//get db/fileload file
					alert('This file must be splitted and displayed on the page: \n\n'+fileSent)

//93|1:cheese|sheep|Cheese, Halloumi|22.3(f5 P)|0.9(f6 HC)|21.9(f7 G)|14.9(f8 satfat)|71(f9 cho)|4.2(f10 sal)|0(f11 alcoh)|0(f12 fib)|.74(f13 Om)|192(f14 A)|3.01(f15 B)|0(f16 C)|0.2(f17 D)|0.5(f18 E)|633(f19 Ca)|0.2(f20 Fe)|74(f21 K)|290(f22 kC 100)|111(f23 Q)|321.9(f24 kc T)
					//fileLoad content is splitted by #
					fileSplit=fileSent.split('#');
						totals=fileSplit[2].split('|')



					head=fileSplit[0].split('|') //base buttermilk.1706887807550768256|milk aaa#
					reg=head[0].split('.')  //base buttermilk.1706887807550768256|
					document.getElementById('file').value=reg[1].replace(/ /g, ""); //.1706887807550768256

					document.getElementById('popFoodName').value=head[1] //milk aaa
					//document.getElementById('popFoodNameT').innerHTML=document.getElementById('popFoodName').value+'control'

					//headToTitle=head[0].split('.')   //base buttermilk.1706887807550768256|
					document.getElementById('title').value= reg[0].trim()


					Qdata=fileSplit[1].split('#');
						Qingredient=Qdata[0].split('_')

				//alert(Qingredient.length)
				ingredientsT=''
					for(var j = 0;j < Qingredient.length;j++){
				//alert(Qingredient[j])
							Qfood=Qingredient[j].split('|')
								ingredientsT=ingredientsT+Qfood[22]+' g: '+Qfood[23]+' Kc: '+Qfood[3]+': Ref. '+Qfood[0]+''+'\n';
					}
					//reg. to be saved to db


reg=reg[1];/* g */;/* sg*/;
mainfoods=document.getElementById('popFoodName').value;weight=totals[23];kc=totals[24];prot=totals[5];carbs=totals[6];fat=totals[7];satfat=totals[8];
chol=totals[9];salt=totals[10];alcoh=totals[11];fib=totals[12];omeg=totals[13];vitc=totals[16];ca=totals[19];fe=totals[20];k=totals[21];filename='';

saveReg='Reg.:'+reg+'|Main Food:'+document.getElementById('popFoodName').value+'|Group:'+g+'|Subgroup:'+sg+'|Preparation: '+document.getElementById('treat').value+'|Weight g:'+weight+'|Energy Kc:'+kc+'|Prot g:'+prot+'|Carbs g:'+carbs+'|Fat g:'+fat+'|satFat g:'+satfat+'|Chol g:'+chol+'|Salt g:'+salt+'|Alcoh g:'+alcoh+'|Fib g:'+fib+'|Omeg g:'+omeg+'|Vit C mg:'+vitc+'|Ca mg:'+ca+'|Fe mg:'+fe+'|K mg:'+k

document.getElementById('kcal').value=kc

/*document.getElementById('quantitativedb').innerHTML='<u>Quantitative DB</u>: <span style="color:yellow">Reg.</span> '+reg+': </span><span style="color:yellow">Main food</span> '+mainfoods+': </span><span style="color:yellow">Weight</span> '+totals[23]+' g: <span style="color:yellow">Energy </span> '+totals[24]+' Kc: <span style="color:yellow">Prot</span> '+totals[5]+' g: <span style="color:yellow">Carbs</span> '+totals[6]+' g: <span style="color:yellow">Fat</span> '+totals[7]+' g: <span style="color:yellow">satFat</span> '+totals[8]+' g: <span style="color:yellow">Chol</span> '+totals[9]+' g: <span style="color:yellow">Salt</span> '+totals[10]+' g: <span style="color:yellow">Alcoh</span> '+totals[11]+' g: <span style="color:yellow">Fib</span> '+totals[12]+' g: <span style="color:yellow">Omeg</span> '+totals[13]+' g: <span style="color:yellow">Vit C</span> '+totals[16]+' mg: <span style="color:yellow">Ca</span> '+totals[19]+' mg: <span style="color:yellow">Fe</span> '+totals[20]+' mg: <span style="color:yellow">K</span> '+totals[21]+' mg:'

qualitativedb='<u>Qualitative DB</u>: Reg.:'+document.getElementById('file').value+'|Main Food:'+document.getElementById('popFoodName').value+'|Group:'+document.getElementById('g').value+'|Subgroup:'+document.getElementById('sg').value+'|Preparation: '+document.getElementById('treat').value+'|Weight g:'+weight+'|Energy Kc:'+kc+'|Title:'+document.getElementById('title').value+'|Author (Country):'+document.getElementById('author').value+'|Image:'+document.getElementById('country').value+'|Url:'+document.getElementById('url').value

document.getElementById('qualitativedb').innerHTML=qualitativedb*/

document.getElementById('ingredients').value=ingredientsT




</script>
</body>
</html>
<script>
//alert(document.getElementById('hook').innerHTML)
var ids = [];gotName='';
function getStripVal(gotName) {
//alert('getStripVal: '+gotName)
ids = [];

gotaName=gotName.split('_')
  var checkedBoxes = document.querySelectorAll('input[type="checkbox"][name="' + gotaName[0] + '"]:checked');
	  for (var i = 0; i < checkedBoxes.length; i++) {
		var idVal = checkedBoxes[i].id;
	//alert('var '+idVal)
		idValArr=idVal.split('_');
	//alert('arr split '+idValArr[0]+', '+idValArr[1])
		idVal=idValArr[0]+idValArr[1]
		ids.push(idVal);
	//alert('push '+ids[0])
  }
}

var checkedFlag = '';var getVal = '';var getFlag = '';var risk='';var alterFlag=''
function pendings(getFlag){
checkedFlag = '';getVal = '';
getCheckedCheckbox()
alterFlag=getFlag;
getCheckedCheckbox()
if (getFlag === 'found'){getVal = 'delete';}else{getVal = getFlag}
//alert('getFlag: '+getFlag+' getVal: '+getVal)

var regNumT='';var regNum='';
switch (getFlag) {
  case "Importable":
			getStripVal('recipeFile')
			for (var i = 0; i < ids.length; i++){
				if ( ids[i].includes('IdR') ) {
				//do the job
				regNum=document.getElementById(ids[i]).innerHTML	//.split('_')
				regNumT=regNumT+','+regNum	//[0]
				}
			}

			regNumT=regNumT.replace(/^./, "")
			flagBell='validate'
			dataDeal=checkedFlag+'|'+regNumT
			getFlag='&#8224; <u>Database Recipe Strips</u> ___flagBell='+flagBell+' dataDeal='+dataDeal;

    break;
  case "found":
			//alert('case found => ids[0]: '+ids[0])
			getStripVal('found')
			//alert('pasa ids.length')
			for (var i = 0; i < ids.length; i++){
				if ( ids[i].includes('found') ) {
				//do the job
				regNum=document.getElementById(ids[i]).innerHTML
				regNum=regNum.split('|')
				regNum=regNum[0].split(':')
			//alert('includes found: '+regNum[1])
				regNumT=regNumT+','+regNum[1]
				}
			}
//alert('regNum: '+regNum)
			regNumT=regNumT.replace(/^./, "")
			checkedFlag=''
			flagBell='delete'
			dataDeal=checkedFlag+'|'+regNumT
			getFlag='&#8224; <u>Database Recipe Strips</u> ___flagBell='+flagBell+' dataDeal='+dataDeal;
			//alert('getFlag: '+getFlag)
    break;
  default:
		alert("error")
    break;
}

if ( regNumT !== '' ) {
	if ( risk === '' ) {
alert('regNum: '+regNum+' risk: '+risk)
		document.getElementById('msgChef').innerHTML=' '+regNumT+"<span style='border: 1px solid white;display:inline-block;width:180px;text-align:center;margin:0 0 0 20px;padding:2px 0 2px 0;cursor:pointer;color:yellow;font-weight:bold;' onclick=\"pendings(alterFlag)\"> Click to confirm</span>"
	risk='0'
	}else{
	//exec("echo $(./pendingRecipesALGORITHM.scr ".$_POST['flagBell']." ".$_POST['dataDeal'].")");
	var dataToBeSent="flagBell="+flagBell+"&dataDeal='"+dataDeal+"'"; //(URL-encoded format)
//alert('dataToBeSent:v'+dataToBeSent)
//exit
	phpToRun='../chef/scripts/pendingRecipes.php'
	alert(phpToRun+'...'+dataToBeSent)
			const xhr = new XMLHttpRequest();
			xhr.open("POST", phpToRun, true);
			xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				xhr.onreadystatechange = function ()
					{
					if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {var text=xhr.responseText;
	document.getElementById('resultBash').innerHTML=text
					}
				};
			xhr.send(dataToBeSent);
	risk='';
	}
}
else
{
	document.getElementById('msgChef').innerHTML=regNumT+"<span>No checked recipe found.</span>"
	exit
}
}


function alternateAddRpl(thisAoR){
	if (document.getElementById(thisAoR).checked == true) {
	document.getElementById('AddReg').checked = false;
	document.getElementById('RplReg').checked = false;
	document.getElementById(thisAoR).checked = true;}
	else
	{
	document.getElementById('AddReg').checked = true;
	document.getElementById('RplReg').checked = false;

	}
}


function getCheckedCheckbox() {
checkedFlag=""
	var checkboxes = document.getElementsByName("addReplace");
	if (document.getElementsByName("addReplace")[0].checked === true){checkedFlag = 'add';}
	if (document.getElementsByName("addReplace")[1].checked === true){checkedFlag = 'replac';}
}

</script>
<script>

var string = document.getElementById('ingredients').value;
if ( string.match('undefined') ) {
document.getElementById('ingredients').value=''
}


el.addEventListener('contextmenu', function(ev) {
    ev.preventDefault();
    alert('success ok!');
    return false;
}, false);

</script>
