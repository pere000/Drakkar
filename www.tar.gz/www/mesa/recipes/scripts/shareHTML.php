<?php

exec("echo $(./shareHTML.scr " . $_POST['group'] . ")");
exec("echo $(cd ../../importExport/importing/resources;./update.scr)");
?>
