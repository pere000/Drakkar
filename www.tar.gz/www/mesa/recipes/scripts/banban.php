<?php
//recipes.php: data carrier banban.php from banban(benben) data sender jsfunction to beben.scr data processor
	$bonbon=exec("echo $(./benben.scr " . $_POST['benben'] . ")");

	echo $bonbon;	#recipe database register to be returned to Ajax
?>
