<?php
//$dataBash = 'mierdaaaaaaa';
//exec("echo $(echo 'mierda' > mierda.txt)");
//exec("echo $(echo " . $_POST['group'] . " > mierda.txt)");
exec("echo $(./saveRecipe.scr " . $_POST['group'] . ")");

//$dataBash = exec("echo $(cd ..;cat bd/menu/tmp)");

echo 'Thank you Mr. ' . $_POST['group'] . '';
//echo $dataBash;
//exec("echo $(echo 'ok' > texto.txt)";
//exec("echo $(echo '|" . $_POST['group']"' >> texto.txt)");
//exit
//$dataBash = exec("echo $(cat texto.txt)");
//file_put_contents("texto.txt", "|" . $_POST['firstname'] . " " . $_POST['lastname'], FILE_APPEND);
//$dataBash = file_get_contents('texto.txt');
//echo 'Thank you Mr. '. $_POST['firstname'] . ' ' . $_POST['lastname'] . '. The content of the texto.txt file is "' . $dataBash . '".';

?>
