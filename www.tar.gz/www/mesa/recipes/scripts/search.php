<?php
//from recipes.php search()
exec("echo $(./search.scr " . $_POST['group'] . ")");


echo exec("echo $(cat tmp_borrame.search)");
?>
