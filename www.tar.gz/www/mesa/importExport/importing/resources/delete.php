<?php
//recipes.php deleteRecipe(deletingFlag)
exec("echo $(rm " . $_POST['urlFileToDelete1'] . ")");
exec("echo $(rm " . $_POST['urlFileToDelete2'] . ")");

	echo ' something was removed.';	#recipe database register to be returned to Ajax
?>
