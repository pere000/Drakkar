<?php
exec("echo $(./inOut.scr)");
//$messageToAjax=exec("echo $(cat inOut_recipeFiles.txt)\|$(cat inOut_importing.txt)");

//echo $messageToAjax;

?>
