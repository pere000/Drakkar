<?php
//recipes.php: data carrier banban.php from banban(benben) data sender jsfunction to beben.scr data processor
	$fileContents=exec("echo $(./update.scr)");

	echo $fileContents;		#file lists to be returned to Ajax and update flex boxes
?>
