# List of files to process
files=("tmp" "tmp.txt" "tmp0.txt" "filenam")

# Define a function to process each file
process_file() {
    file="$1"
    echo "Processing $file..."
    gzip "$file"
    echo "Done processing $file"
}

# Export the function so it's available to parallel
export -f process_file

# Use parallel to process files concurrently
parallel process_file ::: "${files[@]}"
