#!/bin/bash
#number of lines in a file
	#ln=$(wc -l < workcsv2021.csv)
#number of columns in a file when they are constant
	#nc=$(head -1 workcsv2021.csv | tr "|" "\n" | wc -l)
	#nc=head -1 workcsv2021.csv | awk -F "|" '{print NF}'

#busca 'Plus-words' new sobre old (match yes => guarda en yes.bor) (no muestra 'plus-words) (match 'no' => guarda en no.bor muestra plus-words y nutrients de su new sobre old) Trabajo: ver razón de no-match, los errores mínimos en plus-wrods corregirlos y las enteramente nuevas conviene incluirlas.
echo 'lo'
>yes.bor
>no.bor

numline=1;
echo
    while IFS= read -r linea; do	#the new workcsv2021.csv
		lineA=$(echo $linea | cut -d'|' -f2)
		#lineB=$(tail -n $numline work.txt | head -1 | cut -d'|' -f10)
		if [[ $(grep -i "$lineA" work.txt) ]];then
		echo $numline':'$linea >> 'yes.bor'
		else
			echo $numline':'$lineA >> 'no.bor'
				lineaNutrients=$(echo $linea | cut -d'|' -f3-)
					lineaNutrients=$(echo $lineaNutrients | sed 's/,/./g')
						echo 'busca: '$lineaNutrients >> 'no.bor'
							grep -i "$lineaNutrients" work.txt >> 'no.bor'
			echo >> 'no.bor'
		fi

numline=$(($numline+1))
    done < "workcsv2021.csv"
















echo 'ok'

exit
: '
	n=0
    while IFS= read -r linea; do
        echo "$((1262304001+$n))||||||||$linea"
        n=$(($n+1))
    done < "workcsv2021.csv"

'

#words=("Crème Fraîche" "Creme Fraiche" "Crème Chérie" "Creme-Cherie" "chantarelle" "Chanterelle" "and brisket" "abrisket" "and chicken" "achicken" "Strandaskinke" "Stranda skinke" "Schär" "Schør" "and rice" "arice" "Crüsli" "Crøsli" "blåbær" "blåbør" "Blåbærmüsli" "Blåbørmøsli");for ((i=0; i<${#words[@]}; i+=2)); do sed -i "s/${words[i+1]}/${words[i]}/g" work.txt;done
: '
numline=1;
echo
    while IFS= read -r linea; do
       lineA=$(echo $linea | cut -d'|' -f2)
       lineB=$(tail -n+$numline work.txt | head -1 | cut -d'|' -f10)
	 if [[ "$lineA" == "$lineB" ]];then
		echo $numline':'$lineA >> yes.bor
	else
		echo $numline':'$lineA >> no.bor
		echo $numline':'$lineB >> no.bor
		echo >> no.bor
	fi
numline=$(($numline+1))
    done < "workcsv2021.csv"
'







|The Norwegian Food Composition Table 2021||||||
|||||||
FoodID|Food Item|Edible part|Ref|Water|Ref|Kilojoules|Ref
|Abbreviations: M = Missing value. Ref = Reference|%||g||kJ|
|||||||
1|Milk and milk products||||||
1.1|Milk and milk based beverages||||||
01.197|Cocoa, prepared from instant powder and low-fat milk|100|0|85|MI0142|268|MI0114
01.196|Cocoa, prepared with low-fat milk|100|0|82|MI0142|338|MI0114
01.008|Milk beverage, chocolate flavour|100|0|86|MI0142|261|MI0114

set=$(awk -F '|' '
{
    for (i = 1; i <= NF; i++) {
        if ($i == "10") {
            columnNumbers = (columnNumbers == "" ? i : columnNumbers "," i)
        }
    }
}
END {
    print columnNumbers
}
' test.csv)

set=$(awk -F '|' '
{
    for (i = 1; i <= NF; i++) {
        if ($i == "10") {
            columnNumbers = (columnNumbers == "" ? i : columnNumbers " " i)
        }
    }
}
END {
    print columnNumbers
}
' test.csv)

sorted_set=$(echo "$set" | tr ' ' '\n' | sort -n -r | tr '\n' ' ')
arrSet=($sorted_set)
echo ${arrSet[*]}

awk -F '|' '
{
    $8 = ""
    $6 = ""
    $4 = ""
    $2 = ""
    gsub(/[|]{2,}/, "|", $0)
    gsub(/[|]$/, "", $0)
    print
}
' OFS='|' test.csv > updated.csv


In this code:
var='8'
awk -F '|' '{
    $8 = ""
    gsub(/[|]{2,}/, "|", $0)
    gsub(/[|]$/, "", $0)
    print
}
How to use the variable var='8' to substitute the awk $8?



for bogus in "${arrSet[@]}"; do
awk -F '|' -v column="$bogus" '{
    $column = ""
    gsub(/[|]{2,}/, "|", $0)
    gsub(/[|]$/, "", $0)
    print
}' OFS='|' updated.csv > tmp;mv tmp updated.csv
done

awk -F '|' -v deleteCols="${arrSet[*]}" 'BEGIN {
    n = split(deleteCols, deleteArr, " ")
}
{
    outputLine = ""
    for (i = 1; i <= NF; i++) {
        skip = 0
        for (j = 1; j <= n; j++) {
            if (i == deleteArr[j]) {
                skip = 1
                break
            }
        }
        if (!skip) {
            outputLine = (outputLine == "" ? $i : outputLine "|" $i)
        }
    }
    print outputLine
}
' OFS='|' test.csv > updated.csv
